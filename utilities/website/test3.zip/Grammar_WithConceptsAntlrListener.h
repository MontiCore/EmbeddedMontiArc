
// Generated from Grammar_WithConceptsAntlr.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "Grammar_WithConceptsAntlrParser.h"


/**
 * This interface defines an abstract listener for a parse tree produced by Grammar_WithConceptsAntlrParser.
 */
class  Grammar_WithConceptsAntlrListener : public antlr4::tree::ParseTreeListener {
public:

  virtual void enterConceptAntlr_eof(Grammar_WithConceptsAntlrParser::ConceptAntlr_eofContext *ctx) = 0;
  virtual void exitConceptAntlr_eof(Grammar_WithConceptsAntlrParser::ConceptAntlr_eofContext *ctx) = 0;

  virtual void enterConceptAntlr(Grammar_WithConceptsAntlrParser::ConceptAntlrContext *ctx) = 0;
  virtual void exitConceptAntlr(Grammar_WithConceptsAntlrParser::ConceptAntlrContext *ctx) = 0;

  virtual void enterAntlrParserAction_eof(Grammar_WithConceptsAntlrParser::AntlrParserAction_eofContext *ctx) = 0;
  virtual void exitAntlrParserAction_eof(Grammar_WithConceptsAntlrParser::AntlrParserAction_eofContext *ctx) = 0;

  virtual void enterAntlrParserAction(Grammar_WithConceptsAntlrParser::AntlrParserActionContext *ctx) = 0;
  virtual void exitAntlrParserAction(Grammar_WithConceptsAntlrParser::AntlrParserActionContext *ctx) = 0;

  virtual void enterAntlrLexerAction_eof(Grammar_WithConceptsAntlrParser::AntlrLexerAction_eofContext *ctx) = 0;
  virtual void exitAntlrLexerAction_eof(Grammar_WithConceptsAntlrParser::AntlrLexerAction_eofContext *ctx) = 0;

  virtual void enterAntlrLexerAction(Grammar_WithConceptsAntlrParser::AntlrLexerActionContext *ctx) = 0;
  virtual void exitAntlrLexerAction(Grammar_WithConceptsAntlrParser::AntlrLexerActionContext *ctx) = 0;

  virtual void enterJavaCode_eof(Grammar_WithConceptsAntlrParser::JavaCode_eofContext *ctx) = 0;
  virtual void exitJavaCode_eof(Grammar_WithConceptsAntlrParser::JavaCode_eofContext *ctx) = 0;

  virtual void enterJavaCode(Grammar_WithConceptsAntlrParser::JavaCodeContext *ctx) = 0;
  virtual void exitJavaCode(Grammar_WithConceptsAntlrParser::JavaCodeContext *ctx) = 0;

  virtual void enterNullLiteral_eof(Grammar_WithConceptsAntlrParser::NullLiteral_eofContext *ctx) = 0;
  virtual void exitNullLiteral_eof(Grammar_WithConceptsAntlrParser::NullLiteral_eofContext *ctx) = 0;

  virtual void enterNullLiteral(Grammar_WithConceptsAntlrParser::NullLiteralContext *ctx) = 0;
  virtual void exitNullLiteral(Grammar_WithConceptsAntlrParser::NullLiteralContext *ctx) = 0;

  virtual void enterBooleanLiteral_eof(Grammar_WithConceptsAntlrParser::BooleanLiteral_eofContext *ctx) = 0;
  virtual void exitBooleanLiteral_eof(Grammar_WithConceptsAntlrParser::BooleanLiteral_eofContext *ctx) = 0;

  virtual void enterBooleanLiteral(Grammar_WithConceptsAntlrParser::BooleanLiteralContext *ctx) = 0;
  virtual void exitBooleanLiteral(Grammar_WithConceptsAntlrParser::BooleanLiteralContext *ctx) = 0;

  virtual void enterCharLiteral_eof(Grammar_WithConceptsAntlrParser::CharLiteral_eofContext *ctx) = 0;
  virtual void exitCharLiteral_eof(Grammar_WithConceptsAntlrParser::CharLiteral_eofContext *ctx) = 0;

  virtual void enterCharLiteral(Grammar_WithConceptsAntlrParser::CharLiteralContext *ctx) = 0;
  virtual void exitCharLiteral(Grammar_WithConceptsAntlrParser::CharLiteralContext *ctx) = 0;

  virtual void enterStringLiteral_eof(Grammar_WithConceptsAntlrParser::StringLiteral_eofContext *ctx) = 0;
  virtual void exitStringLiteral_eof(Grammar_WithConceptsAntlrParser::StringLiteral_eofContext *ctx) = 0;

  virtual void enterStringLiteral(Grammar_WithConceptsAntlrParser::StringLiteralContext *ctx) = 0;
  virtual void exitStringLiteral(Grammar_WithConceptsAntlrParser::StringLiteralContext *ctx) = 0;

  virtual void enterIntLiteral_eof(Grammar_WithConceptsAntlrParser::IntLiteral_eofContext *ctx) = 0;
  virtual void exitIntLiteral_eof(Grammar_WithConceptsAntlrParser::IntLiteral_eofContext *ctx) = 0;

  virtual void enterIntLiteral(Grammar_WithConceptsAntlrParser::IntLiteralContext *ctx) = 0;
  virtual void exitIntLiteral(Grammar_WithConceptsAntlrParser::IntLiteralContext *ctx) = 0;

  virtual void enterSignedIntLiteral_eof(Grammar_WithConceptsAntlrParser::SignedIntLiteral_eofContext *ctx) = 0;
  virtual void exitSignedIntLiteral_eof(Grammar_WithConceptsAntlrParser::SignedIntLiteral_eofContext *ctx) = 0;

  virtual void enterSignedIntLiteral(Grammar_WithConceptsAntlrParser::SignedIntLiteralContext *ctx) = 0;
  virtual void exitSignedIntLiteral(Grammar_WithConceptsAntlrParser::SignedIntLiteralContext *ctx) = 0;

  virtual void enterLongLiteral_eof(Grammar_WithConceptsAntlrParser::LongLiteral_eofContext *ctx) = 0;
  virtual void exitLongLiteral_eof(Grammar_WithConceptsAntlrParser::LongLiteral_eofContext *ctx) = 0;

  virtual void enterLongLiteral(Grammar_WithConceptsAntlrParser::LongLiteralContext *ctx) = 0;
  virtual void exitLongLiteral(Grammar_WithConceptsAntlrParser::LongLiteralContext *ctx) = 0;

  virtual void enterSignedLongLiteral_eof(Grammar_WithConceptsAntlrParser::SignedLongLiteral_eofContext *ctx) = 0;
  virtual void exitSignedLongLiteral_eof(Grammar_WithConceptsAntlrParser::SignedLongLiteral_eofContext *ctx) = 0;

  virtual void enterSignedLongLiteral(Grammar_WithConceptsAntlrParser::SignedLongLiteralContext *ctx) = 0;
  virtual void exitSignedLongLiteral(Grammar_WithConceptsAntlrParser::SignedLongLiteralContext *ctx) = 0;

  virtual void enterFloatLiteral_eof(Grammar_WithConceptsAntlrParser::FloatLiteral_eofContext *ctx) = 0;
  virtual void exitFloatLiteral_eof(Grammar_WithConceptsAntlrParser::FloatLiteral_eofContext *ctx) = 0;

  virtual void enterFloatLiteral(Grammar_WithConceptsAntlrParser::FloatLiteralContext *ctx) = 0;
  virtual void exitFloatLiteral(Grammar_WithConceptsAntlrParser::FloatLiteralContext *ctx) = 0;

  virtual void enterSignedFloatLiteral_eof(Grammar_WithConceptsAntlrParser::SignedFloatLiteral_eofContext *ctx) = 0;
  virtual void exitSignedFloatLiteral_eof(Grammar_WithConceptsAntlrParser::SignedFloatLiteral_eofContext *ctx) = 0;

  virtual void enterSignedFloatLiteral(Grammar_WithConceptsAntlrParser::SignedFloatLiteralContext *ctx) = 0;
  virtual void exitSignedFloatLiteral(Grammar_WithConceptsAntlrParser::SignedFloatLiteralContext *ctx) = 0;

  virtual void enterDoubleLiteral_eof(Grammar_WithConceptsAntlrParser::DoubleLiteral_eofContext *ctx) = 0;
  virtual void exitDoubleLiteral_eof(Grammar_WithConceptsAntlrParser::DoubleLiteral_eofContext *ctx) = 0;

  virtual void enterDoubleLiteral(Grammar_WithConceptsAntlrParser::DoubleLiteralContext *ctx) = 0;
  virtual void exitDoubleLiteral(Grammar_WithConceptsAntlrParser::DoubleLiteralContext *ctx) = 0;

  virtual void enterSignedDoubleLiteral_eof(Grammar_WithConceptsAntlrParser::SignedDoubleLiteral_eofContext *ctx) = 0;
  virtual void exitSignedDoubleLiteral_eof(Grammar_WithConceptsAntlrParser::SignedDoubleLiteral_eofContext *ctx) = 0;

  virtual void enterSignedDoubleLiteral(Grammar_WithConceptsAntlrParser::SignedDoubleLiteralContext *ctx) = 0;
  virtual void exitSignedDoubleLiteral(Grammar_WithConceptsAntlrParser::SignedDoubleLiteralContext *ctx) = 0;

  virtual void enterQualifiedName_eof(Grammar_WithConceptsAntlrParser::QualifiedName_eofContext *ctx) = 0;
  virtual void exitQualifiedName_eof(Grammar_WithConceptsAntlrParser::QualifiedName_eofContext *ctx) = 0;

  virtual void enterQualifiedName(Grammar_WithConceptsAntlrParser::QualifiedNameContext *ctx) = 0;
  virtual void exitQualifiedName(Grammar_WithConceptsAntlrParser::QualifiedNameContext *ctx) = 0;

  virtual void enterComplexArrayType_eof(Grammar_WithConceptsAntlrParser::ComplexArrayType_eofContext *ctx) = 0;
  virtual void exitComplexArrayType_eof(Grammar_WithConceptsAntlrParser::ComplexArrayType_eofContext *ctx) = 0;

  virtual void enterComplexArrayType(Grammar_WithConceptsAntlrParser::ComplexArrayTypeContext *ctx) = 0;
  virtual void exitComplexArrayType(Grammar_WithConceptsAntlrParser::ComplexArrayTypeContext *ctx) = 0;

  virtual void enterPrimitiveArrayType_eof(Grammar_WithConceptsAntlrParser::PrimitiveArrayType_eofContext *ctx) = 0;
  virtual void exitPrimitiveArrayType_eof(Grammar_WithConceptsAntlrParser::PrimitiveArrayType_eofContext *ctx) = 0;

  virtual void enterPrimitiveArrayType(Grammar_WithConceptsAntlrParser::PrimitiveArrayTypeContext *ctx) = 0;
  virtual void exitPrimitiveArrayType(Grammar_WithConceptsAntlrParser::PrimitiveArrayTypeContext *ctx) = 0;

  virtual void enterVoidType_eof(Grammar_WithConceptsAntlrParser::VoidType_eofContext *ctx) = 0;
  virtual void exitVoidType_eof(Grammar_WithConceptsAntlrParser::VoidType_eofContext *ctx) = 0;

  virtual void enterVoidType(Grammar_WithConceptsAntlrParser::VoidTypeContext *ctx) = 0;
  virtual void exitVoidType(Grammar_WithConceptsAntlrParser::VoidTypeContext *ctx) = 0;

  virtual void enterPrimitiveType_eof(Grammar_WithConceptsAntlrParser::PrimitiveType_eofContext *ctx) = 0;
  virtual void exitPrimitiveType_eof(Grammar_WithConceptsAntlrParser::PrimitiveType_eofContext *ctx) = 0;

  virtual void enterPrimitiveType(Grammar_WithConceptsAntlrParser::PrimitiveTypeContext *ctx) = 0;
  virtual void exitPrimitiveType(Grammar_WithConceptsAntlrParser::PrimitiveTypeContext *ctx) = 0;

  virtual void enterSimpleReferenceType_eof(Grammar_WithConceptsAntlrParser::SimpleReferenceType_eofContext *ctx) = 0;
  virtual void exitSimpleReferenceType_eof(Grammar_WithConceptsAntlrParser::SimpleReferenceType_eofContext *ctx) = 0;

  virtual void enterSimpleReferenceType(Grammar_WithConceptsAntlrParser::SimpleReferenceTypeContext *ctx) = 0;
  virtual void exitSimpleReferenceType(Grammar_WithConceptsAntlrParser::SimpleReferenceTypeContext *ctx) = 0;

  virtual void enterComplexReferenceType_eof(Grammar_WithConceptsAntlrParser::ComplexReferenceType_eofContext *ctx) = 0;
  virtual void exitComplexReferenceType_eof(Grammar_WithConceptsAntlrParser::ComplexReferenceType_eofContext *ctx) = 0;

  virtual void enterComplexReferenceType(Grammar_WithConceptsAntlrParser::ComplexReferenceTypeContext *ctx) = 0;
  virtual void exitComplexReferenceType(Grammar_WithConceptsAntlrParser::ComplexReferenceTypeContext *ctx) = 0;

  virtual void enterTypeArguments_eof(Grammar_WithConceptsAntlrParser::TypeArguments_eofContext *ctx) = 0;
  virtual void exitTypeArguments_eof(Grammar_WithConceptsAntlrParser::TypeArguments_eofContext *ctx) = 0;

  virtual void enterTypeArguments(Grammar_WithConceptsAntlrParser::TypeArgumentsContext *ctx) = 0;
  virtual void exitTypeArguments(Grammar_WithConceptsAntlrParser::TypeArgumentsContext *ctx) = 0;

  virtual void enterWildcardType_eof(Grammar_WithConceptsAntlrParser::WildcardType_eofContext *ctx) = 0;
  virtual void exitWildcardType_eof(Grammar_WithConceptsAntlrParser::WildcardType_eofContext *ctx) = 0;

  virtual void enterWildcardType(Grammar_WithConceptsAntlrParser::WildcardTypeContext *ctx) = 0;
  virtual void exitWildcardType(Grammar_WithConceptsAntlrParser::WildcardTypeContext *ctx) = 0;

  virtual void enterTypeParameters_eof(Grammar_WithConceptsAntlrParser::TypeParameters_eofContext *ctx) = 0;
  virtual void exitTypeParameters_eof(Grammar_WithConceptsAntlrParser::TypeParameters_eofContext *ctx) = 0;

  virtual void enterTypeParameters(Grammar_WithConceptsAntlrParser::TypeParametersContext *ctx) = 0;
  virtual void exitTypeParameters(Grammar_WithConceptsAntlrParser::TypeParametersContext *ctx) = 0;

  virtual void enterTypeVariableDeclaration_eof(Grammar_WithConceptsAntlrParser::TypeVariableDeclaration_eofContext *ctx) = 0;
  virtual void exitTypeVariableDeclaration_eof(Grammar_WithConceptsAntlrParser::TypeVariableDeclaration_eofContext *ctx) = 0;

  virtual void enterTypeVariableDeclaration(Grammar_WithConceptsAntlrParser::TypeVariableDeclarationContext *ctx) = 0;
  virtual void exitTypeVariableDeclaration(Grammar_WithConceptsAntlrParser::TypeVariableDeclarationContext *ctx) = 0;

  virtual void enterImportStatement_eof(Grammar_WithConceptsAntlrParser::ImportStatement_eofContext *ctx) = 0;
  virtual void exitImportStatement_eof(Grammar_WithConceptsAntlrParser::ImportStatement_eofContext *ctx) = 0;

  virtual void enterImportStatement(Grammar_WithConceptsAntlrParser::ImportStatementContext *ctx) = 0;
  virtual void exitImportStatement(Grammar_WithConceptsAntlrParser::ImportStatementContext *ctx) = 0;

  virtual void enterTypeCastExpression_eof(Grammar_WithConceptsAntlrParser::TypeCastExpression_eofContext *ctx) = 0;
  virtual void exitTypeCastExpression_eof(Grammar_WithConceptsAntlrParser::TypeCastExpression_eofContext *ctx) = 0;

  virtual void enterTypeCastExpression(Grammar_WithConceptsAntlrParser::TypeCastExpressionContext *ctx) = 0;
  virtual void exitTypeCastExpression(Grammar_WithConceptsAntlrParser::TypeCastExpressionContext *ctx) = 0;

  virtual void enterPrefixExpression_eof(Grammar_WithConceptsAntlrParser::PrefixExpression_eofContext *ctx) = 0;
  virtual void exitPrefixExpression_eof(Grammar_WithConceptsAntlrParser::PrefixExpression_eofContext *ctx) = 0;

  virtual void enterPrefixExpression(Grammar_WithConceptsAntlrParser::PrefixExpressionContext *ctx) = 0;
  virtual void exitPrefixExpression(Grammar_WithConceptsAntlrParser::PrefixExpressionContext *ctx) = 0;

  virtual void enterBooleanNotExpression_eof(Grammar_WithConceptsAntlrParser::BooleanNotExpression_eofContext *ctx) = 0;
  virtual void exitBooleanNotExpression_eof(Grammar_WithConceptsAntlrParser::BooleanNotExpression_eofContext *ctx) = 0;

  virtual void enterBooleanNotExpression(Grammar_WithConceptsAntlrParser::BooleanNotExpressionContext *ctx) = 0;
  virtual void exitBooleanNotExpression(Grammar_WithConceptsAntlrParser::BooleanNotExpressionContext *ctx) = 0;

  virtual void enterLogicalNotExpression_eof(Grammar_WithConceptsAntlrParser::LogicalNotExpression_eofContext *ctx) = 0;
  virtual void exitLogicalNotExpression_eof(Grammar_WithConceptsAntlrParser::LogicalNotExpression_eofContext *ctx) = 0;

  virtual void enterLogicalNotExpression(Grammar_WithConceptsAntlrParser::LogicalNotExpressionContext *ctx) = 0;
  virtual void exitLogicalNotExpression(Grammar_WithConceptsAntlrParser::LogicalNotExpressionContext *ctx) = 0;

  virtual void enterBracketExpression_eof(Grammar_WithConceptsAntlrParser::BracketExpression_eofContext *ctx) = 0;
  virtual void exitBracketExpression_eof(Grammar_WithConceptsAntlrParser::BracketExpression_eofContext *ctx) = 0;

  virtual void enterBracketExpression(Grammar_WithConceptsAntlrParser::BracketExpressionContext *ctx) = 0;
  virtual void exitBracketExpression(Grammar_WithConceptsAntlrParser::BracketExpressionContext *ctx) = 0;

  virtual void enterPrimaryThisExpression_eof(Grammar_WithConceptsAntlrParser::PrimaryThisExpression_eofContext *ctx) = 0;
  virtual void exitPrimaryThisExpression_eof(Grammar_WithConceptsAntlrParser::PrimaryThisExpression_eofContext *ctx) = 0;

  virtual void enterPrimaryThisExpression(Grammar_WithConceptsAntlrParser::PrimaryThisExpressionContext *ctx) = 0;
  virtual void exitPrimaryThisExpression(Grammar_WithConceptsAntlrParser::PrimaryThisExpressionContext *ctx) = 0;

  virtual void enterPrimarySuperExpression_eof(Grammar_WithConceptsAntlrParser::PrimarySuperExpression_eofContext *ctx) = 0;
  virtual void exitPrimarySuperExpression_eof(Grammar_WithConceptsAntlrParser::PrimarySuperExpression_eofContext *ctx) = 0;

  virtual void enterPrimarySuperExpression(Grammar_WithConceptsAntlrParser::PrimarySuperExpressionContext *ctx) = 0;
  virtual void exitPrimarySuperExpression(Grammar_WithConceptsAntlrParser::PrimarySuperExpressionContext *ctx) = 0;

  virtual void enterLiteralExpression_eof(Grammar_WithConceptsAntlrParser::LiteralExpression_eofContext *ctx) = 0;
  virtual void exitLiteralExpression_eof(Grammar_WithConceptsAntlrParser::LiteralExpression_eofContext *ctx) = 0;

  virtual void enterLiteralExpression(Grammar_WithConceptsAntlrParser::LiteralExpressionContext *ctx) = 0;
  virtual void exitLiteralExpression(Grammar_WithConceptsAntlrParser::LiteralExpressionContext *ctx) = 0;

  virtual void enterNameExpression_eof(Grammar_WithConceptsAntlrParser::NameExpression_eofContext *ctx) = 0;
  virtual void exitNameExpression_eof(Grammar_WithConceptsAntlrParser::NameExpression_eofContext *ctx) = 0;

  virtual void enterNameExpression(Grammar_WithConceptsAntlrParser::NameExpressionContext *ctx) = 0;
  virtual void exitNameExpression(Grammar_WithConceptsAntlrParser::NameExpressionContext *ctx) = 0;

  virtual void enterClassExpression_eof(Grammar_WithConceptsAntlrParser::ClassExpression_eofContext *ctx) = 0;
  virtual void exitClassExpression_eof(Grammar_WithConceptsAntlrParser::ClassExpression_eofContext *ctx) = 0;

  virtual void enterClassExpression(Grammar_WithConceptsAntlrParser::ClassExpressionContext *ctx) = 0;
  virtual void exitClassExpression(Grammar_WithConceptsAntlrParser::ClassExpressionContext *ctx) = 0;

  virtual void enterPrimaryGenericInvocationExpression_eof(Grammar_WithConceptsAntlrParser::PrimaryGenericInvocationExpression_eofContext *ctx) = 0;
  virtual void exitPrimaryGenericInvocationExpression_eof(Grammar_WithConceptsAntlrParser::PrimaryGenericInvocationExpression_eofContext *ctx) = 0;

  virtual void enterPrimaryGenericInvocationExpression(Grammar_WithConceptsAntlrParser::PrimaryGenericInvocationExpressionContext *ctx) = 0;
  virtual void exitPrimaryGenericInvocationExpression(Grammar_WithConceptsAntlrParser::PrimaryGenericInvocationExpressionContext *ctx) = 0;

  virtual void enterGenericInvocationSuffix_eof(Grammar_WithConceptsAntlrParser::GenericInvocationSuffix_eofContext *ctx) = 0;
  virtual void exitGenericInvocationSuffix_eof(Grammar_WithConceptsAntlrParser::GenericInvocationSuffix_eofContext *ctx) = 0;

  virtual void enterGenericInvocationSuffix(Grammar_WithConceptsAntlrParser::GenericInvocationSuffixContext *ctx) = 0;
  virtual void exitGenericInvocationSuffix(Grammar_WithConceptsAntlrParser::GenericInvocationSuffixContext *ctx) = 0;

  virtual void enterSuperSuffix_eof(Grammar_WithConceptsAntlrParser::SuperSuffix_eofContext *ctx) = 0;
  virtual void exitSuperSuffix_eof(Grammar_WithConceptsAntlrParser::SuperSuffix_eofContext *ctx) = 0;

  virtual void enterSuperSuffix(Grammar_WithConceptsAntlrParser::SuperSuffixContext *ctx) = 0;
  virtual void exitSuperSuffix(Grammar_WithConceptsAntlrParser::SuperSuffixContext *ctx) = 0;

  virtual void enterArguments_eof(Grammar_WithConceptsAntlrParser::Arguments_eofContext *ctx) = 0;
  virtual void exitArguments_eof(Grammar_WithConceptsAntlrParser::Arguments_eofContext *ctx) = 0;

  virtual void enterArguments(Grammar_WithConceptsAntlrParser::ArgumentsContext *ctx) = 0;
  virtual void exitArguments(Grammar_WithConceptsAntlrParser::ArgumentsContext *ctx) = 0;

  virtual void enterCompilationUnit_eof(Grammar_WithConceptsAntlrParser::CompilationUnit_eofContext *ctx) = 0;
  virtual void exitCompilationUnit_eof(Grammar_WithConceptsAntlrParser::CompilationUnit_eofContext *ctx) = 0;

  virtual void enterCompilationUnit(Grammar_WithConceptsAntlrParser::CompilationUnitContext *ctx) = 0;
  virtual void exitCompilationUnit(Grammar_WithConceptsAntlrParser::CompilationUnitContext *ctx) = 0;

  virtual void enterPackageDeclaration_eof(Grammar_WithConceptsAntlrParser::PackageDeclaration_eofContext *ctx) = 0;
  virtual void exitPackageDeclaration_eof(Grammar_WithConceptsAntlrParser::PackageDeclaration_eofContext *ctx) = 0;

  virtual void enterPackageDeclaration(Grammar_WithConceptsAntlrParser::PackageDeclarationContext *ctx) = 0;
  virtual void exitPackageDeclaration(Grammar_WithConceptsAntlrParser::PackageDeclarationContext *ctx) = 0;

  virtual void enterImportDeclaration_eof(Grammar_WithConceptsAntlrParser::ImportDeclaration_eofContext *ctx) = 0;
  virtual void exitImportDeclaration_eof(Grammar_WithConceptsAntlrParser::ImportDeclaration_eofContext *ctx) = 0;

  virtual void enterImportDeclaration(Grammar_WithConceptsAntlrParser::ImportDeclarationContext *ctx) = 0;
  virtual void exitImportDeclaration(Grammar_WithConceptsAntlrParser::ImportDeclarationContext *ctx) = 0;

  virtual void enterPrimitiveModifier_eof(Grammar_WithConceptsAntlrParser::PrimitiveModifier_eofContext *ctx) = 0;
  virtual void exitPrimitiveModifier_eof(Grammar_WithConceptsAntlrParser::PrimitiveModifier_eofContext *ctx) = 0;

  virtual void enterPrimitiveModifier(Grammar_WithConceptsAntlrParser::PrimitiveModifierContext *ctx) = 0;
  virtual void exitPrimitiveModifier(Grammar_WithConceptsAntlrParser::PrimitiveModifierContext *ctx) = 0;

  virtual void enterEmptyDeclaration_eof(Grammar_WithConceptsAntlrParser::EmptyDeclaration_eofContext *ctx) = 0;
  virtual void exitEmptyDeclaration_eof(Grammar_WithConceptsAntlrParser::EmptyDeclaration_eofContext *ctx) = 0;

  virtual void enterEmptyDeclaration(Grammar_WithConceptsAntlrParser::EmptyDeclarationContext *ctx) = 0;
  virtual void exitEmptyDeclaration(Grammar_WithConceptsAntlrParser::EmptyDeclarationContext *ctx) = 0;

  virtual void enterClassDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassDeclaration_eofContext *ctx) = 0;
  virtual void exitClassDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassDeclaration_eofContext *ctx) = 0;

  virtual void enterClassDeclaration(Grammar_WithConceptsAntlrParser::ClassDeclarationContext *ctx) = 0;
  virtual void exitClassDeclaration(Grammar_WithConceptsAntlrParser::ClassDeclarationContext *ctx) = 0;

  virtual void enterClassBody_eof(Grammar_WithConceptsAntlrParser::ClassBody_eofContext *ctx) = 0;
  virtual void exitClassBody_eof(Grammar_WithConceptsAntlrParser::ClassBody_eofContext *ctx) = 0;

  virtual void enterClassBody(Grammar_WithConceptsAntlrParser::ClassBodyContext *ctx) = 0;
  virtual void exitClassBody(Grammar_WithConceptsAntlrParser::ClassBodyContext *ctx) = 0;

  virtual void enterInterfaceDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceDeclaration_eofContext *ctx) = 0;
  virtual void exitInterfaceDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceDeclaration_eofContext *ctx) = 0;

  virtual void enterInterfaceDeclaration(Grammar_WithConceptsAntlrParser::InterfaceDeclarationContext *ctx) = 0;
  virtual void exitInterfaceDeclaration(Grammar_WithConceptsAntlrParser::InterfaceDeclarationContext *ctx) = 0;

  virtual void enterInterfaceBody_eof(Grammar_WithConceptsAntlrParser::InterfaceBody_eofContext *ctx) = 0;
  virtual void exitInterfaceBody_eof(Grammar_WithConceptsAntlrParser::InterfaceBody_eofContext *ctx) = 0;

  virtual void enterInterfaceBody(Grammar_WithConceptsAntlrParser::InterfaceBodyContext *ctx) = 0;
  virtual void exitInterfaceBody(Grammar_WithConceptsAntlrParser::InterfaceBodyContext *ctx) = 0;

  virtual void enterEnumDeclaration_eof(Grammar_WithConceptsAntlrParser::EnumDeclaration_eofContext *ctx) = 0;
  virtual void exitEnumDeclaration_eof(Grammar_WithConceptsAntlrParser::EnumDeclaration_eofContext *ctx) = 0;

  virtual void enterEnumDeclaration(Grammar_WithConceptsAntlrParser::EnumDeclarationContext *ctx) = 0;
  virtual void exitEnumDeclaration(Grammar_WithConceptsAntlrParser::EnumDeclarationContext *ctx) = 0;

  virtual void enterEnumConstantDeclaration_eof(Grammar_WithConceptsAntlrParser::EnumConstantDeclaration_eofContext *ctx) = 0;
  virtual void exitEnumConstantDeclaration_eof(Grammar_WithConceptsAntlrParser::EnumConstantDeclaration_eofContext *ctx) = 0;

  virtual void enterEnumConstantDeclaration(Grammar_WithConceptsAntlrParser::EnumConstantDeclarationContext *ctx) = 0;
  virtual void exitEnumConstantDeclaration(Grammar_WithConceptsAntlrParser::EnumConstantDeclarationContext *ctx) = 0;

  virtual void enterEnumBody_eof(Grammar_WithConceptsAntlrParser::EnumBody_eofContext *ctx) = 0;
  virtual void exitEnumBody_eof(Grammar_WithConceptsAntlrParser::EnumBody_eofContext *ctx) = 0;

  virtual void enterEnumBody(Grammar_WithConceptsAntlrParser::EnumBodyContext *ctx) = 0;
  virtual void exitEnumBody(Grammar_WithConceptsAntlrParser::EnumBodyContext *ctx) = 0;

  virtual void enterClassBlock_eof(Grammar_WithConceptsAntlrParser::ClassBlock_eofContext *ctx) = 0;
  virtual void exitClassBlock_eof(Grammar_WithConceptsAntlrParser::ClassBlock_eofContext *ctx) = 0;

  virtual void enterClassBlock(Grammar_WithConceptsAntlrParser::ClassBlockContext *ctx) = 0;
  virtual void exitClassBlock(Grammar_WithConceptsAntlrParser::ClassBlockContext *ctx) = 0;

  virtual void enterMethodDeclaration_eof(Grammar_WithConceptsAntlrParser::MethodDeclaration_eofContext *ctx) = 0;
  virtual void exitMethodDeclaration_eof(Grammar_WithConceptsAntlrParser::MethodDeclaration_eofContext *ctx) = 0;

  virtual void enterMethodDeclaration(Grammar_WithConceptsAntlrParser::MethodDeclarationContext *ctx) = 0;
  virtual void exitMethodDeclaration(Grammar_WithConceptsAntlrParser::MethodDeclarationContext *ctx) = 0;

  virtual void enterConstructorDeclaration_eof(Grammar_WithConceptsAntlrParser::ConstructorDeclaration_eofContext *ctx) = 0;
  virtual void exitConstructorDeclaration_eof(Grammar_WithConceptsAntlrParser::ConstructorDeclaration_eofContext *ctx) = 0;

  virtual void enterConstructorDeclaration(Grammar_WithConceptsAntlrParser::ConstructorDeclarationContext *ctx) = 0;
  virtual void exitConstructorDeclaration(Grammar_WithConceptsAntlrParser::ConstructorDeclarationContext *ctx) = 0;

  virtual void enterFieldDeclaration_eof(Grammar_WithConceptsAntlrParser::FieldDeclaration_eofContext *ctx) = 0;
  virtual void exitFieldDeclaration_eof(Grammar_WithConceptsAntlrParser::FieldDeclaration_eofContext *ctx) = 0;

  virtual void enterFieldDeclaration(Grammar_WithConceptsAntlrParser::FieldDeclarationContext *ctx) = 0;
  virtual void exitFieldDeclaration(Grammar_WithConceptsAntlrParser::FieldDeclarationContext *ctx) = 0;

  virtual void enterConstDeclaration_eof(Grammar_WithConceptsAntlrParser::ConstDeclaration_eofContext *ctx) = 0;
  virtual void exitConstDeclaration_eof(Grammar_WithConceptsAntlrParser::ConstDeclaration_eofContext *ctx) = 0;

  virtual void enterConstDeclaration(Grammar_WithConceptsAntlrParser::ConstDeclarationContext *ctx) = 0;
  virtual void exitConstDeclaration(Grammar_WithConceptsAntlrParser::ConstDeclarationContext *ctx) = 0;

  virtual void enterConstantDeclarator_eof(Grammar_WithConceptsAntlrParser::ConstantDeclarator_eofContext *ctx) = 0;
  virtual void exitConstantDeclarator_eof(Grammar_WithConceptsAntlrParser::ConstantDeclarator_eofContext *ctx) = 0;

  virtual void enterConstantDeclarator(Grammar_WithConceptsAntlrParser::ConstantDeclaratorContext *ctx) = 0;
  virtual void exitConstantDeclarator(Grammar_WithConceptsAntlrParser::ConstantDeclaratorContext *ctx) = 0;

  virtual void enterInterfaceMethodDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceMethodDeclaration_eofContext *ctx) = 0;
  virtual void exitInterfaceMethodDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceMethodDeclaration_eofContext *ctx) = 0;

  virtual void enterInterfaceMethodDeclaration(Grammar_WithConceptsAntlrParser::InterfaceMethodDeclarationContext *ctx) = 0;
  virtual void exitInterfaceMethodDeclaration(Grammar_WithConceptsAntlrParser::InterfaceMethodDeclarationContext *ctx) = 0;

  virtual void enterMethodSignature_eof(Grammar_WithConceptsAntlrParser::MethodSignature_eofContext *ctx) = 0;
  virtual void exitMethodSignature_eof(Grammar_WithConceptsAntlrParser::MethodSignature_eofContext *ctx) = 0;

  virtual void enterMethodSignature(Grammar_WithConceptsAntlrParser::MethodSignatureContext *ctx) = 0;
  virtual void exitMethodSignature(Grammar_WithConceptsAntlrParser::MethodSignatureContext *ctx) = 0;

  virtual void enterR__throws_eof(Grammar_WithConceptsAntlrParser::R__throws_eofContext *ctx) = 0;
  virtual void exitR__throws_eof(Grammar_WithConceptsAntlrParser::R__throws_eofContext *ctx) = 0;

  virtual void enterR__throws(Grammar_WithConceptsAntlrParser::R__throwsContext *ctx) = 0;
  virtual void exitR__throws(Grammar_WithConceptsAntlrParser::R__throwsContext *ctx) = 0;

  virtual void enterVariableDeclarator_eof(Grammar_WithConceptsAntlrParser::VariableDeclarator_eofContext *ctx) = 0;
  virtual void exitVariableDeclarator_eof(Grammar_WithConceptsAntlrParser::VariableDeclarator_eofContext *ctx) = 0;

  virtual void enterVariableDeclarator(Grammar_WithConceptsAntlrParser::VariableDeclaratorContext *ctx) = 0;
  virtual void exitVariableDeclarator(Grammar_WithConceptsAntlrParser::VariableDeclaratorContext *ctx) = 0;

  virtual void enterDeclaratorId_eof(Grammar_WithConceptsAntlrParser::DeclaratorId_eofContext *ctx) = 0;
  virtual void exitDeclaratorId_eof(Grammar_WithConceptsAntlrParser::DeclaratorId_eofContext *ctx) = 0;

  virtual void enterDeclaratorId(Grammar_WithConceptsAntlrParser::DeclaratorIdContext *ctx) = 0;
  virtual void exitDeclaratorId(Grammar_WithConceptsAntlrParser::DeclaratorIdContext *ctx) = 0;

  virtual void enterVariableInititializerOrExpression_eof(Grammar_WithConceptsAntlrParser::VariableInititializerOrExpression_eofContext *ctx) = 0;
  virtual void exitVariableInititializerOrExpression_eof(Grammar_WithConceptsAntlrParser::VariableInititializerOrExpression_eofContext *ctx) = 0;

  virtual void enterVariableInititializerOrExpression(Grammar_WithConceptsAntlrParser::VariableInititializerOrExpressionContext *ctx) = 0;
  virtual void exitVariableInititializerOrExpression(Grammar_WithConceptsAntlrParser::VariableInititializerOrExpressionContext *ctx) = 0;

  virtual void enterArrayInitializer_eof(Grammar_WithConceptsAntlrParser::ArrayInitializer_eofContext *ctx) = 0;
  virtual void exitArrayInitializer_eof(Grammar_WithConceptsAntlrParser::ArrayInitializer_eofContext *ctx) = 0;

  virtual void enterArrayInitializer(Grammar_WithConceptsAntlrParser::ArrayInitializerContext *ctx) = 0;
  virtual void exitArrayInitializer(Grammar_WithConceptsAntlrParser::ArrayInitializerContext *ctx) = 0;

  virtual void enterFormalParameters_eof(Grammar_WithConceptsAntlrParser::FormalParameters_eofContext *ctx) = 0;
  virtual void exitFormalParameters_eof(Grammar_WithConceptsAntlrParser::FormalParameters_eofContext *ctx) = 0;

  virtual void enterFormalParameters(Grammar_WithConceptsAntlrParser::FormalParametersContext *ctx) = 0;
  virtual void exitFormalParameters(Grammar_WithConceptsAntlrParser::FormalParametersContext *ctx) = 0;

  virtual void enterFormalParameterListing_eof(Grammar_WithConceptsAntlrParser::FormalParameterListing_eofContext *ctx) = 0;
  virtual void exitFormalParameterListing_eof(Grammar_WithConceptsAntlrParser::FormalParameterListing_eofContext *ctx) = 0;

  virtual void enterFormalParameterListing(Grammar_WithConceptsAntlrParser::FormalParameterListingContext *ctx) = 0;
  virtual void exitFormalParameterListing(Grammar_WithConceptsAntlrParser::FormalParameterListingContext *ctx) = 0;

  virtual void enterFormalParameter_eof(Grammar_WithConceptsAntlrParser::FormalParameter_eofContext *ctx) = 0;
  virtual void exitFormalParameter_eof(Grammar_WithConceptsAntlrParser::FormalParameter_eofContext *ctx) = 0;

  virtual void enterFormalParameter(Grammar_WithConceptsAntlrParser::FormalParameterContext *ctx) = 0;
  virtual void exitFormalParameter(Grammar_WithConceptsAntlrParser::FormalParameterContext *ctx) = 0;

  virtual void enterLastFormalParameter_eof(Grammar_WithConceptsAntlrParser::LastFormalParameter_eofContext *ctx) = 0;
  virtual void exitLastFormalParameter_eof(Grammar_WithConceptsAntlrParser::LastFormalParameter_eofContext *ctx) = 0;

  virtual void enterLastFormalParameter(Grammar_WithConceptsAntlrParser::LastFormalParameterContext *ctx) = 0;
  virtual void exitLastFormalParameter(Grammar_WithConceptsAntlrParser::LastFormalParameterContext *ctx) = 0;

  virtual void enterAnnotation_eof(Grammar_WithConceptsAntlrParser::Annotation_eofContext *ctx) = 0;
  virtual void exitAnnotation_eof(Grammar_WithConceptsAntlrParser::Annotation_eofContext *ctx) = 0;

  virtual void enterAnnotation(Grammar_WithConceptsAntlrParser::AnnotationContext *ctx) = 0;
  virtual void exitAnnotation(Grammar_WithConceptsAntlrParser::AnnotationContext *ctx) = 0;

  virtual void enterAnnotationPairArguments_eof(Grammar_WithConceptsAntlrParser::AnnotationPairArguments_eofContext *ctx) = 0;
  virtual void exitAnnotationPairArguments_eof(Grammar_WithConceptsAntlrParser::AnnotationPairArguments_eofContext *ctx) = 0;

  virtual void enterAnnotationPairArguments(Grammar_WithConceptsAntlrParser::AnnotationPairArgumentsContext *ctx) = 0;
  virtual void exitAnnotationPairArguments(Grammar_WithConceptsAntlrParser::AnnotationPairArgumentsContext *ctx) = 0;

  virtual void enterElementValuePair_eof(Grammar_WithConceptsAntlrParser::ElementValuePair_eofContext *ctx) = 0;
  virtual void exitElementValuePair_eof(Grammar_WithConceptsAntlrParser::ElementValuePair_eofContext *ctx) = 0;

  virtual void enterElementValuePair(Grammar_WithConceptsAntlrParser::ElementValuePairContext *ctx) = 0;
  virtual void exitElementValuePair(Grammar_WithConceptsAntlrParser::ElementValuePairContext *ctx) = 0;

  virtual void enterElementValueOrExpr_eof(Grammar_WithConceptsAntlrParser::ElementValueOrExpr_eofContext *ctx) = 0;
  virtual void exitElementValueOrExpr_eof(Grammar_WithConceptsAntlrParser::ElementValueOrExpr_eofContext *ctx) = 0;

  virtual void enterElementValueOrExpr(Grammar_WithConceptsAntlrParser::ElementValueOrExprContext *ctx) = 0;
  virtual void exitElementValueOrExpr(Grammar_WithConceptsAntlrParser::ElementValueOrExprContext *ctx) = 0;

  virtual void enterElementValueArrayInitializer_eof(Grammar_WithConceptsAntlrParser::ElementValueArrayInitializer_eofContext *ctx) = 0;
  virtual void exitElementValueArrayInitializer_eof(Grammar_WithConceptsAntlrParser::ElementValueArrayInitializer_eofContext *ctx) = 0;

  virtual void enterElementValueArrayInitializer(Grammar_WithConceptsAntlrParser::ElementValueArrayInitializerContext *ctx) = 0;
  virtual void exitElementValueArrayInitializer(Grammar_WithConceptsAntlrParser::ElementValueArrayInitializerContext *ctx) = 0;

  virtual void enterAnnotationTypeDeclaration_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeDeclaration_eofContext *ctx) = 0;
  virtual void exitAnnotationTypeDeclaration_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeDeclaration_eofContext *ctx) = 0;

  virtual void enterAnnotationTypeDeclaration(Grammar_WithConceptsAntlrParser::AnnotationTypeDeclarationContext *ctx) = 0;
  virtual void exitAnnotationTypeDeclaration(Grammar_WithConceptsAntlrParser::AnnotationTypeDeclarationContext *ctx) = 0;

  virtual void enterAnnotationTypeBody_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeBody_eofContext *ctx) = 0;
  virtual void exitAnnotationTypeBody_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeBody_eofContext *ctx) = 0;

  virtual void enterAnnotationTypeBody(Grammar_WithConceptsAntlrParser::AnnotationTypeBodyContext *ctx) = 0;
  virtual void exitAnnotationTypeBody(Grammar_WithConceptsAntlrParser::AnnotationTypeBodyContext *ctx) = 0;

  virtual void enterAnnotationMethod_eof(Grammar_WithConceptsAntlrParser::AnnotationMethod_eofContext *ctx) = 0;
  virtual void exitAnnotationMethod_eof(Grammar_WithConceptsAntlrParser::AnnotationMethod_eofContext *ctx) = 0;

  virtual void enterAnnotationMethod(Grammar_WithConceptsAntlrParser::AnnotationMethodContext *ctx) = 0;
  virtual void exitAnnotationMethod(Grammar_WithConceptsAntlrParser::AnnotationMethodContext *ctx) = 0;

  virtual void enterAnnotationConstant_eof(Grammar_WithConceptsAntlrParser::AnnotationConstant_eofContext *ctx) = 0;
  virtual void exitAnnotationConstant_eof(Grammar_WithConceptsAntlrParser::AnnotationConstant_eofContext *ctx) = 0;

  virtual void enterAnnotationConstant(Grammar_WithConceptsAntlrParser::AnnotationConstantContext *ctx) = 0;
  virtual void exitAnnotationConstant(Grammar_WithConceptsAntlrParser::AnnotationConstantContext *ctx) = 0;

  virtual void enterDefaultValue_eof(Grammar_WithConceptsAntlrParser::DefaultValue_eofContext *ctx) = 0;
  virtual void exitDefaultValue_eof(Grammar_WithConceptsAntlrParser::DefaultValue_eofContext *ctx) = 0;

  virtual void enterDefaultValue(Grammar_WithConceptsAntlrParser::DefaultValueContext *ctx) = 0;
  virtual void exitDefaultValue(Grammar_WithConceptsAntlrParser::DefaultValueContext *ctx) = 0;

  virtual void enterLocalVariableDeclarationStatement_eof(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationStatement_eofContext *ctx) = 0;
  virtual void exitLocalVariableDeclarationStatement_eof(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationStatement_eofContext *ctx) = 0;

  virtual void enterLocalVariableDeclarationStatement(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationStatementContext *ctx) = 0;
  virtual void exitLocalVariableDeclarationStatement(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationStatementContext *ctx) = 0;

  virtual void enterLocalVariableDeclaration_eof(Grammar_WithConceptsAntlrParser::LocalVariableDeclaration_eofContext *ctx) = 0;
  virtual void exitLocalVariableDeclaration_eof(Grammar_WithConceptsAntlrParser::LocalVariableDeclaration_eofContext *ctx) = 0;

  virtual void enterLocalVariableDeclaration(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationContext *ctx) = 0;
  virtual void exitLocalVariableDeclaration(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationContext *ctx) = 0;

  virtual void enterJavaBlock_eof(Grammar_WithConceptsAntlrParser::JavaBlock_eofContext *ctx) = 0;
  virtual void exitJavaBlock_eof(Grammar_WithConceptsAntlrParser::JavaBlock_eofContext *ctx) = 0;

  virtual void enterJavaBlock(Grammar_WithConceptsAntlrParser::JavaBlockContext *ctx) = 0;
  virtual void exitJavaBlock(Grammar_WithConceptsAntlrParser::JavaBlockContext *ctx) = 0;

  virtual void enterAssertStatement_eof(Grammar_WithConceptsAntlrParser::AssertStatement_eofContext *ctx) = 0;
  virtual void exitAssertStatement_eof(Grammar_WithConceptsAntlrParser::AssertStatement_eofContext *ctx) = 0;

  virtual void enterAssertStatement(Grammar_WithConceptsAntlrParser::AssertStatementContext *ctx) = 0;
  virtual void exitAssertStatement(Grammar_WithConceptsAntlrParser::AssertStatementContext *ctx) = 0;

  virtual void enterIfStatement_eof(Grammar_WithConceptsAntlrParser::IfStatement_eofContext *ctx) = 0;
  virtual void exitIfStatement_eof(Grammar_WithConceptsAntlrParser::IfStatement_eofContext *ctx) = 0;

  virtual void enterIfStatement(Grammar_WithConceptsAntlrParser::IfStatementContext *ctx) = 0;
  virtual void exitIfStatement(Grammar_WithConceptsAntlrParser::IfStatementContext *ctx) = 0;

  virtual void enterForStatement_eof(Grammar_WithConceptsAntlrParser::ForStatement_eofContext *ctx) = 0;
  virtual void exitForStatement_eof(Grammar_WithConceptsAntlrParser::ForStatement_eofContext *ctx) = 0;

  virtual void enterForStatement(Grammar_WithConceptsAntlrParser::ForStatementContext *ctx) = 0;
  virtual void exitForStatement(Grammar_WithConceptsAntlrParser::ForStatementContext *ctx) = 0;

  virtual void enterCommonForControl_eof(Grammar_WithConceptsAntlrParser::CommonForControl_eofContext *ctx) = 0;
  virtual void exitCommonForControl_eof(Grammar_WithConceptsAntlrParser::CommonForControl_eofContext *ctx) = 0;

  virtual void enterCommonForControl(Grammar_WithConceptsAntlrParser::CommonForControlContext *ctx) = 0;
  virtual void exitCommonForControl(Grammar_WithConceptsAntlrParser::CommonForControlContext *ctx) = 0;

  virtual void enterForInitByExpressions_eof(Grammar_WithConceptsAntlrParser::ForInitByExpressions_eofContext *ctx) = 0;
  virtual void exitForInitByExpressions_eof(Grammar_WithConceptsAntlrParser::ForInitByExpressions_eofContext *ctx) = 0;

  virtual void enterForInitByExpressions(Grammar_WithConceptsAntlrParser::ForInitByExpressionsContext *ctx) = 0;
  virtual void exitForInitByExpressions(Grammar_WithConceptsAntlrParser::ForInitByExpressionsContext *ctx) = 0;

  virtual void enterEnhancedForControl_eof(Grammar_WithConceptsAntlrParser::EnhancedForControl_eofContext *ctx) = 0;
  virtual void exitEnhancedForControl_eof(Grammar_WithConceptsAntlrParser::EnhancedForControl_eofContext *ctx) = 0;

  virtual void enterEnhancedForControl(Grammar_WithConceptsAntlrParser::EnhancedForControlContext *ctx) = 0;
  virtual void exitEnhancedForControl(Grammar_WithConceptsAntlrParser::EnhancedForControlContext *ctx) = 0;

  virtual void enterWhileStatement_eof(Grammar_WithConceptsAntlrParser::WhileStatement_eofContext *ctx) = 0;
  virtual void exitWhileStatement_eof(Grammar_WithConceptsAntlrParser::WhileStatement_eofContext *ctx) = 0;

  virtual void enterWhileStatement(Grammar_WithConceptsAntlrParser::WhileStatementContext *ctx) = 0;
  virtual void exitWhileStatement(Grammar_WithConceptsAntlrParser::WhileStatementContext *ctx) = 0;

  virtual void enterDoWhileStatement_eof(Grammar_WithConceptsAntlrParser::DoWhileStatement_eofContext *ctx) = 0;
  virtual void exitDoWhileStatement_eof(Grammar_WithConceptsAntlrParser::DoWhileStatement_eofContext *ctx) = 0;

  virtual void enterDoWhileStatement(Grammar_WithConceptsAntlrParser::DoWhileStatementContext *ctx) = 0;
  virtual void exitDoWhileStatement(Grammar_WithConceptsAntlrParser::DoWhileStatementContext *ctx) = 0;

  virtual void enterTryStatement_eof(Grammar_WithConceptsAntlrParser::TryStatement_eofContext *ctx) = 0;
  virtual void exitTryStatement_eof(Grammar_WithConceptsAntlrParser::TryStatement_eofContext *ctx) = 0;

  virtual void enterTryStatement(Grammar_WithConceptsAntlrParser::TryStatementContext *ctx) = 0;
  virtual void exitTryStatement(Grammar_WithConceptsAntlrParser::TryStatementContext *ctx) = 0;

  virtual void enterCatchExceptionsHandler_eof(Grammar_WithConceptsAntlrParser::CatchExceptionsHandler_eofContext *ctx) = 0;
  virtual void exitCatchExceptionsHandler_eof(Grammar_WithConceptsAntlrParser::CatchExceptionsHandler_eofContext *ctx) = 0;

  virtual void enterCatchExceptionsHandler(Grammar_WithConceptsAntlrParser::CatchExceptionsHandlerContext *ctx) = 0;
  virtual void exitCatchExceptionsHandler(Grammar_WithConceptsAntlrParser::CatchExceptionsHandlerContext *ctx) = 0;

  virtual void enterFinallyBlockOnlyHandler_eof(Grammar_WithConceptsAntlrParser::FinallyBlockOnlyHandler_eofContext *ctx) = 0;
  virtual void exitFinallyBlockOnlyHandler_eof(Grammar_WithConceptsAntlrParser::FinallyBlockOnlyHandler_eofContext *ctx) = 0;

  virtual void enterFinallyBlockOnlyHandler(Grammar_WithConceptsAntlrParser::FinallyBlockOnlyHandlerContext *ctx) = 0;
  virtual void exitFinallyBlockOnlyHandler(Grammar_WithConceptsAntlrParser::FinallyBlockOnlyHandlerContext *ctx) = 0;

  virtual void enterTryStatementWithResources_eof(Grammar_WithConceptsAntlrParser::TryStatementWithResources_eofContext *ctx) = 0;
  virtual void exitTryStatementWithResources_eof(Grammar_WithConceptsAntlrParser::TryStatementWithResources_eofContext *ctx) = 0;

  virtual void enterTryStatementWithResources(Grammar_WithConceptsAntlrParser::TryStatementWithResourcesContext *ctx) = 0;
  virtual void exitTryStatementWithResources(Grammar_WithConceptsAntlrParser::TryStatementWithResourcesContext *ctx) = 0;

  virtual void enterResource_eof(Grammar_WithConceptsAntlrParser::Resource_eofContext *ctx) = 0;
  virtual void exitResource_eof(Grammar_WithConceptsAntlrParser::Resource_eofContext *ctx) = 0;

  virtual void enterResource(Grammar_WithConceptsAntlrParser::ResourceContext *ctx) = 0;
  virtual void exitResource(Grammar_WithConceptsAntlrParser::ResourceContext *ctx) = 0;

  virtual void enterIdentifierAndTypeArgument_eof(Grammar_WithConceptsAntlrParser::IdentifierAndTypeArgument_eofContext *ctx) = 0;
  virtual void exitIdentifierAndTypeArgument_eof(Grammar_WithConceptsAntlrParser::IdentifierAndTypeArgument_eofContext *ctx) = 0;

  virtual void enterIdentifierAndTypeArgument(Grammar_WithConceptsAntlrParser::IdentifierAndTypeArgumentContext *ctx) = 0;
  virtual void exitIdentifierAndTypeArgument(Grammar_WithConceptsAntlrParser::IdentifierAndTypeArgumentContext *ctx) = 0;

  virtual void enterCatchClause_eof(Grammar_WithConceptsAntlrParser::CatchClause_eofContext *ctx) = 0;
  virtual void exitCatchClause_eof(Grammar_WithConceptsAntlrParser::CatchClause_eofContext *ctx) = 0;

  virtual void enterCatchClause(Grammar_WithConceptsAntlrParser::CatchClauseContext *ctx) = 0;
  virtual void exitCatchClause(Grammar_WithConceptsAntlrParser::CatchClauseContext *ctx) = 0;

  virtual void enterCatchType_eof(Grammar_WithConceptsAntlrParser::CatchType_eofContext *ctx) = 0;
  virtual void exitCatchType_eof(Grammar_WithConceptsAntlrParser::CatchType_eofContext *ctx) = 0;

  virtual void enterCatchType(Grammar_WithConceptsAntlrParser::CatchTypeContext *ctx) = 0;
  virtual void exitCatchType(Grammar_WithConceptsAntlrParser::CatchTypeContext *ctx) = 0;

  virtual void enterSwitchStatement_eof(Grammar_WithConceptsAntlrParser::SwitchStatement_eofContext *ctx) = 0;
  virtual void exitSwitchStatement_eof(Grammar_WithConceptsAntlrParser::SwitchStatement_eofContext *ctx) = 0;

  virtual void enterSwitchStatement(Grammar_WithConceptsAntlrParser::SwitchStatementContext *ctx) = 0;
  virtual void exitSwitchStatement(Grammar_WithConceptsAntlrParser::SwitchStatementContext *ctx) = 0;

  virtual void enterSynchronizedStatement_eof(Grammar_WithConceptsAntlrParser::SynchronizedStatement_eofContext *ctx) = 0;
  virtual void exitSynchronizedStatement_eof(Grammar_WithConceptsAntlrParser::SynchronizedStatement_eofContext *ctx) = 0;

  virtual void enterSynchronizedStatement(Grammar_WithConceptsAntlrParser::SynchronizedStatementContext *ctx) = 0;
  virtual void exitSynchronizedStatement(Grammar_WithConceptsAntlrParser::SynchronizedStatementContext *ctx) = 0;

  virtual void enterReturnStatement_eof(Grammar_WithConceptsAntlrParser::ReturnStatement_eofContext *ctx) = 0;
  virtual void exitReturnStatement_eof(Grammar_WithConceptsAntlrParser::ReturnStatement_eofContext *ctx) = 0;

  virtual void enterReturnStatement(Grammar_WithConceptsAntlrParser::ReturnStatementContext *ctx) = 0;
  virtual void exitReturnStatement(Grammar_WithConceptsAntlrParser::ReturnStatementContext *ctx) = 0;

  virtual void enterThrowStatement_eof(Grammar_WithConceptsAntlrParser::ThrowStatement_eofContext *ctx) = 0;
  virtual void exitThrowStatement_eof(Grammar_WithConceptsAntlrParser::ThrowStatement_eofContext *ctx) = 0;

  virtual void enterThrowStatement(Grammar_WithConceptsAntlrParser::ThrowStatementContext *ctx) = 0;
  virtual void exitThrowStatement(Grammar_WithConceptsAntlrParser::ThrowStatementContext *ctx) = 0;

  virtual void enterBreakStatement_eof(Grammar_WithConceptsAntlrParser::BreakStatement_eofContext *ctx) = 0;
  virtual void exitBreakStatement_eof(Grammar_WithConceptsAntlrParser::BreakStatement_eofContext *ctx) = 0;

  virtual void enterBreakStatement(Grammar_WithConceptsAntlrParser::BreakStatementContext *ctx) = 0;
  virtual void exitBreakStatement(Grammar_WithConceptsAntlrParser::BreakStatementContext *ctx) = 0;

  virtual void enterContinueStatement_eof(Grammar_WithConceptsAntlrParser::ContinueStatement_eofContext *ctx) = 0;
  virtual void exitContinueStatement_eof(Grammar_WithConceptsAntlrParser::ContinueStatement_eofContext *ctx) = 0;

  virtual void enterContinueStatement(Grammar_WithConceptsAntlrParser::ContinueStatementContext *ctx) = 0;
  virtual void exitContinueStatement(Grammar_WithConceptsAntlrParser::ContinueStatementContext *ctx) = 0;

  virtual void enterEmptyStatement_eof(Grammar_WithConceptsAntlrParser::EmptyStatement_eofContext *ctx) = 0;
  virtual void exitEmptyStatement_eof(Grammar_WithConceptsAntlrParser::EmptyStatement_eofContext *ctx) = 0;

  virtual void enterEmptyStatement(Grammar_WithConceptsAntlrParser::EmptyStatementContext *ctx) = 0;
  virtual void exitEmptyStatement(Grammar_WithConceptsAntlrParser::EmptyStatementContext *ctx) = 0;

  virtual void enterExpressionStatement_eof(Grammar_WithConceptsAntlrParser::ExpressionStatement_eofContext *ctx) = 0;
  virtual void exitExpressionStatement_eof(Grammar_WithConceptsAntlrParser::ExpressionStatement_eofContext *ctx) = 0;

  virtual void enterExpressionStatement(Grammar_WithConceptsAntlrParser::ExpressionStatementContext *ctx) = 0;
  virtual void exitExpressionStatement(Grammar_WithConceptsAntlrParser::ExpressionStatementContext *ctx) = 0;

  virtual void enterASTStatement_eof(Grammar_WithConceptsAntlrParser::ASTStatement_eofContext *ctx) = 0;
  virtual void exitASTStatement_eof(Grammar_WithConceptsAntlrParser::ASTStatement_eofContext *ctx) = 0;

  virtual void enterASTStatement(Grammar_WithConceptsAntlrParser::ASTStatementContext *ctx) = 0;
  virtual void exitASTStatement(Grammar_WithConceptsAntlrParser::ASTStatementContext *ctx) = 0;

  virtual void enterLabeledStatement_eof(Grammar_WithConceptsAntlrParser::LabeledStatement_eofContext *ctx) = 0;
  virtual void exitLabeledStatement_eof(Grammar_WithConceptsAntlrParser::LabeledStatement_eofContext *ctx) = 0;

  virtual void enterLabeledStatement(Grammar_WithConceptsAntlrParser::LabeledStatementContext *ctx) = 0;
  virtual void exitLabeledStatement(Grammar_WithConceptsAntlrParser::LabeledStatementContext *ctx) = 0;

  virtual void enterSwitchBlockStatementGroup_eof(Grammar_WithConceptsAntlrParser::SwitchBlockStatementGroup_eofContext *ctx) = 0;
  virtual void exitSwitchBlockStatementGroup_eof(Grammar_WithConceptsAntlrParser::SwitchBlockStatementGroup_eofContext *ctx) = 0;

  virtual void enterSwitchBlockStatementGroup(Grammar_WithConceptsAntlrParser::SwitchBlockStatementGroupContext *ctx) = 0;
  virtual void exitSwitchBlockStatementGroup(Grammar_WithConceptsAntlrParser::SwitchBlockStatementGroupContext *ctx) = 0;

  virtual void enterConstantExpressionSwitchLabel_eof(Grammar_WithConceptsAntlrParser::ConstantExpressionSwitchLabel_eofContext *ctx) = 0;
  virtual void exitConstantExpressionSwitchLabel_eof(Grammar_WithConceptsAntlrParser::ConstantExpressionSwitchLabel_eofContext *ctx) = 0;

  virtual void enterConstantExpressionSwitchLabel(Grammar_WithConceptsAntlrParser::ConstantExpressionSwitchLabelContext *ctx) = 0;
  virtual void exitConstantExpressionSwitchLabel(Grammar_WithConceptsAntlrParser::ConstantExpressionSwitchLabelContext *ctx) = 0;

  virtual void enterEnumConstantSwitchLabel_eof(Grammar_WithConceptsAntlrParser::EnumConstantSwitchLabel_eofContext *ctx) = 0;
  virtual void exitEnumConstantSwitchLabel_eof(Grammar_WithConceptsAntlrParser::EnumConstantSwitchLabel_eofContext *ctx) = 0;

  virtual void enterEnumConstantSwitchLabel(Grammar_WithConceptsAntlrParser::EnumConstantSwitchLabelContext *ctx) = 0;
  virtual void exitEnumConstantSwitchLabel(Grammar_WithConceptsAntlrParser::EnumConstantSwitchLabelContext *ctx) = 0;

  virtual void enterDefaultSwitchLabel_eof(Grammar_WithConceptsAntlrParser::DefaultSwitchLabel_eofContext *ctx) = 0;
  virtual void exitDefaultSwitchLabel_eof(Grammar_WithConceptsAntlrParser::DefaultSwitchLabel_eofContext *ctx) = 0;

  virtual void enterDefaultSwitchLabel(Grammar_WithConceptsAntlrParser::DefaultSwitchLabelContext *ctx) = 0;
  virtual void exitDefaultSwitchLabel(Grammar_WithConceptsAntlrParser::DefaultSwitchLabelContext *ctx) = 0;

  virtual void enterCreatorExpression_eof(Grammar_WithConceptsAntlrParser::CreatorExpression_eofContext *ctx) = 0;
  virtual void exitCreatorExpression_eof(Grammar_WithConceptsAntlrParser::CreatorExpression_eofContext *ctx) = 0;

  virtual void enterCreatorExpression(Grammar_WithConceptsAntlrParser::CreatorExpressionContext *ctx) = 0;
  virtual void exitCreatorExpression(Grammar_WithConceptsAntlrParser::CreatorExpressionContext *ctx) = 0;

  virtual void enterAnonymousClass_eof(Grammar_WithConceptsAntlrParser::AnonymousClass_eofContext *ctx) = 0;
  virtual void exitAnonymousClass_eof(Grammar_WithConceptsAntlrParser::AnonymousClass_eofContext *ctx) = 0;

  virtual void enterAnonymousClass(Grammar_WithConceptsAntlrParser::AnonymousClassContext *ctx) = 0;
  virtual void exitAnonymousClass(Grammar_WithConceptsAntlrParser::AnonymousClassContext *ctx) = 0;

  virtual void enterArrayCreator_eof(Grammar_WithConceptsAntlrParser::ArrayCreator_eofContext *ctx) = 0;
  virtual void exitArrayCreator_eof(Grammar_WithConceptsAntlrParser::ArrayCreator_eofContext *ctx) = 0;

  virtual void enterArrayCreator(Grammar_WithConceptsAntlrParser::ArrayCreatorContext *ctx) = 0;
  virtual void exitArrayCreator(Grammar_WithConceptsAntlrParser::ArrayCreatorContext *ctx) = 0;

  virtual void enterArrayDimensionByInitializer_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionByInitializer_eofContext *ctx) = 0;
  virtual void exitArrayDimensionByInitializer_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionByInitializer_eofContext *ctx) = 0;

  virtual void enterArrayDimensionByInitializer(Grammar_WithConceptsAntlrParser::ArrayDimensionByInitializerContext *ctx) = 0;
  virtual void exitArrayDimensionByInitializer(Grammar_WithConceptsAntlrParser::ArrayDimensionByInitializerContext *ctx) = 0;

  virtual void enterArrayDimensionByExpression_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionByExpression_eofContext *ctx) = 0;
  virtual void exitArrayDimensionByExpression_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionByExpression_eofContext *ctx) = 0;

  virtual void enterArrayDimensionByExpression(Grammar_WithConceptsAntlrParser::ArrayDimensionByExpressionContext *ctx) = 0;
  virtual void exitArrayDimensionByExpression(Grammar_WithConceptsAntlrParser::ArrayDimensionByExpressionContext *ctx) = 0;

  virtual void enterCreatedName_eof(Grammar_WithConceptsAntlrParser::CreatedName_eofContext *ctx) = 0;
  virtual void exitCreatedName_eof(Grammar_WithConceptsAntlrParser::CreatedName_eofContext *ctx) = 0;

  virtual void enterCreatedName(Grammar_WithConceptsAntlrParser::CreatedNameContext *ctx) = 0;
  virtual void exitCreatedName(Grammar_WithConceptsAntlrParser::CreatedNameContext *ctx) = 0;

  virtual void enterInnerCreator_eof(Grammar_WithConceptsAntlrParser::InnerCreator_eofContext *ctx) = 0;
  virtual void exitInnerCreator_eof(Grammar_WithConceptsAntlrParser::InnerCreator_eofContext *ctx) = 0;

  virtual void enterInnerCreator(Grammar_WithConceptsAntlrParser::InnerCreatorContext *ctx) = 0;
  virtual void exitInnerCreator(Grammar_WithConceptsAntlrParser::InnerCreatorContext *ctx) = 0;

  virtual void enterClassCreatorRest_eof(Grammar_WithConceptsAntlrParser::ClassCreatorRest_eofContext *ctx) = 0;
  virtual void exitClassCreatorRest_eof(Grammar_WithConceptsAntlrParser::ClassCreatorRest_eofContext *ctx) = 0;

  virtual void enterClassCreatorRest(Grammar_WithConceptsAntlrParser::ClassCreatorRestContext *ctx) = 0;
  virtual void exitClassCreatorRest(Grammar_WithConceptsAntlrParser::ClassCreatorRestContext *ctx) = 0;

  virtual void enterMCGrammar_eof(Grammar_WithConceptsAntlrParser::MCGrammar_eofContext *ctx) = 0;
  virtual void exitMCGrammar_eof(Grammar_WithConceptsAntlrParser::MCGrammar_eofContext *ctx) = 0;

  virtual void enterMCGrammar(Grammar_WithConceptsAntlrParser::MCGrammarContext *ctx) = 0;
  virtual void exitMCGrammar(Grammar_WithConceptsAntlrParser::MCGrammarContext *ctx) = 0;

  virtual void enterMCImportStatement_eof(Grammar_WithConceptsAntlrParser::MCImportStatement_eofContext *ctx) = 0;
  virtual void exitMCImportStatement_eof(Grammar_WithConceptsAntlrParser::MCImportStatement_eofContext *ctx) = 0;

  virtual void enterMCImportStatement(Grammar_WithConceptsAntlrParser::MCImportStatementContext *ctx) = 0;
  virtual void exitMCImportStatement(Grammar_WithConceptsAntlrParser::MCImportStatementContext *ctx) = 0;

  virtual void enterGrammarReference_eof(Grammar_WithConceptsAntlrParser::GrammarReference_eofContext *ctx) = 0;
  virtual void exitGrammarReference_eof(Grammar_WithConceptsAntlrParser::GrammarReference_eofContext *ctx) = 0;

  virtual void enterGrammarReference(Grammar_WithConceptsAntlrParser::GrammarReferenceContext *ctx) = 0;
  virtual void exitGrammarReference(Grammar_WithConceptsAntlrParser::GrammarReferenceContext *ctx) = 0;

  virtual void enterGrammarOption_eof(Grammar_WithConceptsAntlrParser::GrammarOption_eofContext *ctx) = 0;
  virtual void exitGrammarOption_eof(Grammar_WithConceptsAntlrParser::GrammarOption_eofContext *ctx) = 0;

  virtual void enterGrammarOption(Grammar_WithConceptsAntlrParser::GrammarOptionContext *ctx) = 0;
  virtual void exitGrammarOption(Grammar_WithConceptsAntlrParser::GrammarOptionContext *ctx) = 0;

  virtual void enterFollowOption_eof(Grammar_WithConceptsAntlrParser::FollowOption_eofContext *ctx) = 0;
  virtual void exitFollowOption_eof(Grammar_WithConceptsAntlrParser::FollowOption_eofContext *ctx) = 0;

  virtual void enterFollowOption(Grammar_WithConceptsAntlrParser::FollowOptionContext *ctx) = 0;
  virtual void exitFollowOption(Grammar_WithConceptsAntlrParser::FollowOptionContext *ctx) = 0;

  virtual void enterAntlrOption_eof(Grammar_WithConceptsAntlrParser::AntlrOption_eofContext *ctx) = 0;
  virtual void exitAntlrOption_eof(Grammar_WithConceptsAntlrParser::AntlrOption_eofContext *ctx) = 0;

  virtual void enterAntlrOption(Grammar_WithConceptsAntlrParser::AntlrOptionContext *ctx) = 0;
  virtual void exitAntlrOption(Grammar_WithConceptsAntlrParser::AntlrOptionContext *ctx) = 0;

  virtual void enterStartRule_eof(Grammar_WithConceptsAntlrParser::StartRule_eofContext *ctx) = 0;
  virtual void exitStartRule_eof(Grammar_WithConceptsAntlrParser::StartRule_eofContext *ctx) = 0;

  virtual void enterStartRule(Grammar_WithConceptsAntlrParser::StartRuleContext *ctx) = 0;
  virtual void exitStartRule(Grammar_WithConceptsAntlrParser::StartRuleContext *ctx) = 0;

  virtual void enterLexProd_eof(Grammar_WithConceptsAntlrParser::LexProd_eofContext *ctx) = 0;
  virtual void exitLexProd_eof(Grammar_WithConceptsAntlrParser::LexProd_eofContext *ctx) = 0;

  virtual void enterLexProd(Grammar_WithConceptsAntlrParser::LexProdContext *ctx) = 0;
  virtual void exitLexProd(Grammar_WithConceptsAntlrParser::LexProdContext *ctx) = 0;

  virtual void enterEnumProd_eof(Grammar_WithConceptsAntlrParser::EnumProd_eofContext *ctx) = 0;
  virtual void exitEnumProd_eof(Grammar_WithConceptsAntlrParser::EnumProd_eofContext *ctx) = 0;

  virtual void enterEnumProd(Grammar_WithConceptsAntlrParser::EnumProdContext *ctx) = 0;
  virtual void exitEnumProd(Grammar_WithConceptsAntlrParser::EnumProdContext *ctx) = 0;

  virtual void enterExternalProd_eof(Grammar_WithConceptsAntlrParser::ExternalProd_eofContext *ctx) = 0;
  virtual void exitExternalProd_eof(Grammar_WithConceptsAntlrParser::ExternalProd_eofContext *ctx) = 0;

  virtual void enterExternalProd(Grammar_WithConceptsAntlrParser::ExternalProdContext *ctx) = 0;
  virtual void exitExternalProd(Grammar_WithConceptsAntlrParser::ExternalProdContext *ctx) = 0;

  virtual void enterInterfaceProd_eof(Grammar_WithConceptsAntlrParser::InterfaceProd_eofContext *ctx) = 0;
  virtual void exitInterfaceProd_eof(Grammar_WithConceptsAntlrParser::InterfaceProd_eofContext *ctx) = 0;

  virtual void enterInterfaceProd(Grammar_WithConceptsAntlrParser::InterfaceProdContext *ctx) = 0;
  virtual void exitInterfaceProd(Grammar_WithConceptsAntlrParser::InterfaceProdContext *ctx) = 0;

  virtual void enterAbstractProd_eof(Grammar_WithConceptsAntlrParser::AbstractProd_eofContext *ctx) = 0;
  virtual void exitAbstractProd_eof(Grammar_WithConceptsAntlrParser::AbstractProd_eofContext *ctx) = 0;

  virtual void enterAbstractProd(Grammar_WithConceptsAntlrParser::AbstractProdContext *ctx) = 0;
  virtual void exitAbstractProd(Grammar_WithConceptsAntlrParser::AbstractProdContext *ctx) = 0;

  virtual void enterClassProd_eof(Grammar_WithConceptsAntlrParser::ClassProd_eofContext *ctx) = 0;
  virtual void exitClassProd_eof(Grammar_WithConceptsAntlrParser::ClassProd_eofContext *ctx) = 0;

  virtual void enterClassProd(Grammar_WithConceptsAntlrParser::ClassProdContext *ctx) = 0;
  virtual void exitClassProd(Grammar_WithConceptsAntlrParser::ClassProdContext *ctx) = 0;

  virtual void enterCard_eof(Grammar_WithConceptsAntlrParser::Card_eofContext *ctx) = 0;
  virtual void exitCard_eof(Grammar_WithConceptsAntlrParser::Card_eofContext *ctx) = 0;

  virtual void enterCard(Grammar_WithConceptsAntlrParser::CardContext *ctx) = 0;
  virtual void exitCard(Grammar_WithConceptsAntlrParser::CardContext *ctx) = 0;

  virtual void enterRuleReference_eof(Grammar_WithConceptsAntlrParser::RuleReference_eofContext *ctx) = 0;
  virtual void exitRuleReference_eof(Grammar_WithConceptsAntlrParser::RuleReference_eofContext *ctx) = 0;

  virtual void enterRuleReference(Grammar_WithConceptsAntlrParser::RuleReferenceContext *ctx) = 0;
  virtual void exitRuleReference(Grammar_WithConceptsAntlrParser::RuleReferenceContext *ctx) = 0;

  virtual void enterAlt_eof(Grammar_WithConceptsAntlrParser::Alt_eofContext *ctx) = 0;
  virtual void exitAlt_eof(Grammar_WithConceptsAntlrParser::Alt_eofContext *ctx) = 0;

  virtual void enterAlt(Grammar_WithConceptsAntlrParser::AltContext *ctx) = 0;
  virtual void exitAlt(Grammar_WithConceptsAntlrParser::AltContext *ctx) = 0;

  virtual void enterNonTerminalSeparator_eof(Grammar_WithConceptsAntlrParser::NonTerminalSeparator_eofContext *ctx) = 0;
  virtual void exitNonTerminalSeparator_eof(Grammar_WithConceptsAntlrParser::NonTerminalSeparator_eofContext *ctx) = 0;

  virtual void enterNonTerminalSeparator(Grammar_WithConceptsAntlrParser::NonTerminalSeparatorContext *ctx) = 0;
  virtual void exitNonTerminalSeparator(Grammar_WithConceptsAntlrParser::NonTerminalSeparatorContext *ctx) = 0;

  virtual void enterBlock_eof(Grammar_WithConceptsAntlrParser::Block_eofContext *ctx) = 0;
  virtual void exitBlock_eof(Grammar_WithConceptsAntlrParser::Block_eofContext *ctx) = 0;

  virtual void enterBlock(Grammar_WithConceptsAntlrParser::BlockContext *ctx) = 0;
  virtual void exitBlock(Grammar_WithConceptsAntlrParser::BlockContext *ctx) = 0;

  virtual void enterOption_eof(Grammar_WithConceptsAntlrParser::Option_eofContext *ctx) = 0;
  virtual void exitOption_eof(Grammar_WithConceptsAntlrParser::Option_eofContext *ctx) = 0;

  virtual void enterOption(Grammar_WithConceptsAntlrParser::OptionContext *ctx) = 0;
  virtual void exitOption(Grammar_WithConceptsAntlrParser::OptionContext *ctx) = 0;

  virtual void enterOptionValue_eof(Grammar_WithConceptsAntlrParser::OptionValue_eofContext *ctx) = 0;
  virtual void exitOptionValue_eof(Grammar_WithConceptsAntlrParser::OptionValue_eofContext *ctx) = 0;

  virtual void enterOptionValue(Grammar_WithConceptsAntlrParser::OptionValueContext *ctx) = 0;
  virtual void exitOptionValue(Grammar_WithConceptsAntlrParser::OptionValueContext *ctx) = 0;

  virtual void enterNonTerminal_eof(Grammar_WithConceptsAntlrParser::NonTerminal_eofContext *ctx) = 0;
  virtual void exitNonTerminal_eof(Grammar_WithConceptsAntlrParser::NonTerminal_eofContext *ctx) = 0;

  virtual void enterNonTerminal(Grammar_WithConceptsAntlrParser::NonTerminalContext *ctx) = 0;
  virtual void exitNonTerminal(Grammar_WithConceptsAntlrParser::NonTerminalContext *ctx) = 0;

  virtual void enterTerminal_eof(Grammar_WithConceptsAntlrParser::Terminal_eofContext *ctx) = 0;
  virtual void exitTerminal_eof(Grammar_WithConceptsAntlrParser::Terminal_eofContext *ctx) = 0;

  virtual void enterTerminal(Grammar_WithConceptsAntlrParser::TerminalContext *ctx) = 0;
  virtual void exitTerminal(Grammar_WithConceptsAntlrParser::TerminalContext *ctx) = 0;

  virtual void enterConstant_eof(Grammar_WithConceptsAntlrParser::Constant_eofContext *ctx) = 0;
  virtual void exitConstant_eof(Grammar_WithConceptsAntlrParser::Constant_eofContext *ctx) = 0;

  virtual void enterConstant(Grammar_WithConceptsAntlrParser::ConstantContext *ctx) = 0;
  virtual void exitConstant(Grammar_WithConceptsAntlrParser::ConstantContext *ctx) = 0;

  virtual void enterConstantGroup_eof(Grammar_WithConceptsAntlrParser::ConstantGroup_eofContext *ctx) = 0;
  virtual void exitConstantGroup_eof(Grammar_WithConceptsAntlrParser::ConstantGroup_eofContext *ctx) = 0;

  virtual void enterConstantGroup(Grammar_WithConceptsAntlrParser::ConstantGroupContext *ctx) = 0;
  virtual void exitConstantGroup(Grammar_WithConceptsAntlrParser::ConstantGroupContext *ctx) = 0;

  virtual void enterEof_eof(Grammar_WithConceptsAntlrParser::Eof_eofContext *ctx) = 0;
  virtual void exitEof_eof(Grammar_WithConceptsAntlrParser::Eof_eofContext *ctx) = 0;

  virtual void enterEof(Grammar_WithConceptsAntlrParser::EofContext *ctx) = 0;
  virtual void exitEof(Grammar_WithConceptsAntlrParser::EofContext *ctx) = 0;

  virtual void enterMCAnything_eof(Grammar_WithConceptsAntlrParser::MCAnything_eofContext *ctx) = 0;
  virtual void exitMCAnything_eof(Grammar_WithConceptsAntlrParser::MCAnything_eofContext *ctx) = 0;

  virtual void enterMCAnything(Grammar_WithConceptsAntlrParser::MCAnythingContext *ctx) = 0;
  virtual void exitMCAnything(Grammar_WithConceptsAntlrParser::MCAnythingContext *ctx) = 0;

  virtual void enterAnything_eof(Grammar_WithConceptsAntlrParser::Anything_eofContext *ctx) = 0;
  virtual void exitAnything_eof(Grammar_WithConceptsAntlrParser::Anything_eofContext *ctx) = 0;

  virtual void enterAnything(Grammar_WithConceptsAntlrParser::AnythingContext *ctx) = 0;
  virtual void exitAnything(Grammar_WithConceptsAntlrParser::AnythingContext *ctx) = 0;

  virtual void enterSemanticpredicateOrAction_eof(Grammar_WithConceptsAntlrParser::SemanticpredicateOrAction_eofContext *ctx) = 0;
  virtual void exitSemanticpredicateOrAction_eof(Grammar_WithConceptsAntlrParser::SemanticpredicateOrAction_eofContext *ctx) = 0;

  virtual void enterSemanticpredicateOrAction(Grammar_WithConceptsAntlrParser::SemanticpredicateOrActionContext *ctx) = 0;
  virtual void exitSemanticpredicateOrAction(Grammar_WithConceptsAntlrParser::SemanticpredicateOrActionContext *ctx) = 0;

  virtual void enterConcept_eof(Grammar_WithConceptsAntlrParser::Concept_eofContext *ctx) = 0;
  virtual void exitConcept_eof(Grammar_WithConceptsAntlrParser::Concept_eofContext *ctx) = 0;

  virtual void enterConcept_(Grammar_WithConceptsAntlrParser::Concept_Context *ctx) = 0;
  virtual void exitConcept_(Grammar_WithConceptsAntlrParser::Concept_Context *ctx) = 0;

  virtual void enterASTRule_eof(Grammar_WithConceptsAntlrParser::ASTRule_eofContext *ctx) = 0;
  virtual void exitASTRule_eof(Grammar_WithConceptsAntlrParser::ASTRule_eofContext *ctx) = 0;

  virtual void enterASTRule(Grammar_WithConceptsAntlrParser::ASTRuleContext *ctx) = 0;
  virtual void exitASTRule(Grammar_WithConceptsAntlrParser::ASTRuleContext *ctx) = 0;

  virtual void enterMethod_eof(Grammar_WithConceptsAntlrParser::Method_eofContext *ctx) = 0;
  virtual void exitMethod_eof(Grammar_WithConceptsAntlrParser::Method_eofContext *ctx) = 0;

  virtual void enterMethod(Grammar_WithConceptsAntlrParser::MethodContext *ctx) = 0;
  virtual void exitMethod(Grammar_WithConceptsAntlrParser::MethodContext *ctx) = 0;

  virtual void enterMethodParameter_eof(Grammar_WithConceptsAntlrParser::MethodParameter_eofContext *ctx) = 0;
  virtual void exitMethodParameter_eof(Grammar_WithConceptsAntlrParser::MethodParameter_eofContext *ctx) = 0;

  virtual void enterMethodParameter(Grammar_WithConceptsAntlrParser::MethodParameterContext *ctx) = 0;
  virtual void exitMethodParameter(Grammar_WithConceptsAntlrParser::MethodParameterContext *ctx) = 0;

  virtual void enterAttributeInAST_eof(Grammar_WithConceptsAntlrParser::AttributeInAST_eofContext *ctx) = 0;
  virtual void exitAttributeInAST_eof(Grammar_WithConceptsAntlrParser::AttributeInAST_eofContext *ctx) = 0;

  virtual void enterAttributeInAST(Grammar_WithConceptsAntlrParser::AttributeInASTContext *ctx) = 0;
  virtual void exitAttributeInAST(Grammar_WithConceptsAntlrParser::AttributeInASTContext *ctx) = 0;

  virtual void enterGenericType_eof(Grammar_WithConceptsAntlrParser::GenericType_eofContext *ctx) = 0;
  virtual void exitGenericType_eof(Grammar_WithConceptsAntlrParser::GenericType_eofContext *ctx) = 0;

  virtual void enterGenericType(Grammar_WithConceptsAntlrParser::GenericTypeContext *ctx) = 0;
  virtual void exitGenericType(Grammar_WithConceptsAntlrParser::GenericTypeContext *ctx) = 0;

  virtual void enterLexAlt_eof(Grammar_WithConceptsAntlrParser::LexAlt_eofContext *ctx) = 0;
  virtual void exitLexAlt_eof(Grammar_WithConceptsAntlrParser::LexAlt_eofContext *ctx) = 0;

  virtual void enterLexAlt(Grammar_WithConceptsAntlrParser::LexAltContext *ctx) = 0;
  virtual void exitLexAlt(Grammar_WithConceptsAntlrParser::LexAltContext *ctx) = 0;

  virtual void enterLexBlock_eof(Grammar_WithConceptsAntlrParser::LexBlock_eofContext *ctx) = 0;
  virtual void exitLexBlock_eof(Grammar_WithConceptsAntlrParser::LexBlock_eofContext *ctx) = 0;

  virtual void enterLexBlock(Grammar_WithConceptsAntlrParser::LexBlockContext *ctx) = 0;
  virtual void exitLexBlock(Grammar_WithConceptsAntlrParser::LexBlockContext *ctx) = 0;

  virtual void enterLexCharRange_eof(Grammar_WithConceptsAntlrParser::LexCharRange_eofContext *ctx) = 0;
  virtual void exitLexCharRange_eof(Grammar_WithConceptsAntlrParser::LexCharRange_eofContext *ctx) = 0;

  virtual void enterLexCharRange(Grammar_WithConceptsAntlrParser::LexCharRangeContext *ctx) = 0;
  virtual void exitLexCharRange(Grammar_WithConceptsAntlrParser::LexCharRangeContext *ctx) = 0;

  virtual void enterLexChar_eof(Grammar_WithConceptsAntlrParser::LexChar_eofContext *ctx) = 0;
  virtual void exitLexChar_eof(Grammar_WithConceptsAntlrParser::LexChar_eofContext *ctx) = 0;

  virtual void enterLexChar(Grammar_WithConceptsAntlrParser::LexCharContext *ctx) = 0;
  virtual void exitLexChar(Grammar_WithConceptsAntlrParser::LexCharContext *ctx) = 0;

  virtual void enterLexAnyChar_eof(Grammar_WithConceptsAntlrParser::LexAnyChar_eofContext *ctx) = 0;
  virtual void exitLexAnyChar_eof(Grammar_WithConceptsAntlrParser::LexAnyChar_eofContext *ctx) = 0;

  virtual void enterLexAnyChar(Grammar_WithConceptsAntlrParser::LexAnyCharContext *ctx) = 0;
  virtual void exitLexAnyChar(Grammar_WithConceptsAntlrParser::LexAnyCharContext *ctx) = 0;

  virtual void enterLexString_eof(Grammar_WithConceptsAntlrParser::LexString_eofContext *ctx) = 0;
  virtual void exitLexString_eof(Grammar_WithConceptsAntlrParser::LexString_eofContext *ctx) = 0;

  virtual void enterLexString(Grammar_WithConceptsAntlrParser::LexStringContext *ctx) = 0;
  virtual void exitLexString(Grammar_WithConceptsAntlrParser::LexStringContext *ctx) = 0;

  virtual void enterLexActionOrPredicate_eof(Grammar_WithConceptsAntlrParser::LexActionOrPredicate_eofContext *ctx) = 0;
  virtual void exitLexActionOrPredicate_eof(Grammar_WithConceptsAntlrParser::LexActionOrPredicate_eofContext *ctx) = 0;

  virtual void enterLexActionOrPredicate(Grammar_WithConceptsAntlrParser::LexActionOrPredicateContext *ctx) = 0;
  virtual void exitLexActionOrPredicate(Grammar_WithConceptsAntlrParser::LexActionOrPredicateContext *ctx) = 0;

  virtual void enterLexNonTerminal_eof(Grammar_WithConceptsAntlrParser::LexNonTerminal_eofContext *ctx) = 0;
  virtual void exitLexNonTerminal_eof(Grammar_WithConceptsAntlrParser::LexNonTerminal_eofContext *ctx) = 0;

  virtual void enterLexNonTerminal(Grammar_WithConceptsAntlrParser::LexNonTerminalContext *ctx) = 0;
  virtual void exitLexNonTerminal(Grammar_WithConceptsAntlrParser::LexNonTerminalContext *ctx) = 0;

  virtual void enterLexSimpleIteration_eof(Grammar_WithConceptsAntlrParser::LexSimpleIteration_eofContext *ctx) = 0;
  virtual void exitLexSimpleIteration_eof(Grammar_WithConceptsAntlrParser::LexSimpleIteration_eofContext *ctx) = 0;

  virtual void enterLexSimpleIteration(Grammar_WithConceptsAntlrParser::LexSimpleIterationContext *ctx) = 0;
  virtual void exitLexSimpleIteration(Grammar_WithConceptsAntlrParser::LexSimpleIterationContext *ctx) = 0;

  virtual void enterLexOption_eof(Grammar_WithConceptsAntlrParser::LexOption_eofContext *ctx) = 0;
  virtual void exitLexOption_eof(Grammar_WithConceptsAntlrParser::LexOption_eofContext *ctx) = 0;

  virtual void enterLexOption(Grammar_WithConceptsAntlrParser::LexOptionContext *ctx) = 0;
  virtual void exitLexOption(Grammar_WithConceptsAntlrParser::LexOptionContext *ctx) = 0;

  virtual void enterSymbolDefinition_eof(Grammar_WithConceptsAntlrParser::SymbolDefinition_eofContext *ctx) = 0;
  virtual void exitSymbolDefinition_eof(Grammar_WithConceptsAntlrParser::SymbolDefinition_eofContext *ctx) = 0;

  virtual void enterSymbolDefinition(Grammar_WithConceptsAntlrParser::SymbolDefinitionContext *ctx) = 0;
  virtual void exitSymbolDefinition(Grammar_WithConceptsAntlrParser::SymbolDefinitionContext *ctx) = 0;

  virtual void enterAction_eof(Grammar_WithConceptsAntlrParser::Action_eofContext *ctx) = 0;
  virtual void exitAction_eof(Grammar_WithConceptsAntlrParser::Action_eofContext *ctx) = 0;

  virtual void enterAction(Grammar_WithConceptsAntlrParser::ActionContext *ctx) = 0;
  virtual void exitAction(Grammar_WithConceptsAntlrParser::ActionContext *ctx) = 0;

  virtual void enterExpressionPredicate_eof(Grammar_WithConceptsAntlrParser::ExpressionPredicate_eofContext *ctx) = 0;
  virtual void exitExpressionPredicate_eof(Grammar_WithConceptsAntlrParser::ExpressionPredicate_eofContext *ctx) = 0;

  virtual void enterExpressionPredicate(Grammar_WithConceptsAntlrParser::ExpressionPredicateContext *ctx) = 0;
  virtual void exitExpressionPredicate(Grammar_WithConceptsAntlrParser::ExpressionPredicateContext *ctx) = 0;

  virtual void enterMCConcept_eof(Grammar_WithConceptsAntlrParser::MCConcept_eofContext *ctx) = 0;
  virtual void exitMCConcept_eof(Grammar_WithConceptsAntlrParser::MCConcept_eofContext *ctx) = 0;

  virtual void enterMCConcept(Grammar_WithConceptsAntlrParser::MCConceptContext *ctx) = 0;
  virtual void exitMCConcept(Grammar_WithConceptsAntlrParser::MCConceptContext *ctx) = 0;

  virtual void enterLiteral_eof(Grammar_WithConceptsAntlrParser::Literal_eofContext *ctx) = 0;
  virtual void exitLiteral_eof(Grammar_WithConceptsAntlrParser::Literal_eofContext *ctx) = 0;

  virtual void enterLiteral(Grammar_WithConceptsAntlrParser::LiteralContext *ctx) = 0;
  virtual void exitLiteral(Grammar_WithConceptsAntlrParser::LiteralContext *ctx) = 0;

  virtual void enterSignedLiteral_eof(Grammar_WithConceptsAntlrParser::SignedLiteral_eofContext *ctx) = 0;
  virtual void exitSignedLiteral_eof(Grammar_WithConceptsAntlrParser::SignedLiteral_eofContext *ctx) = 0;

  virtual void enterSignedLiteral(Grammar_WithConceptsAntlrParser::SignedLiteralContext *ctx) = 0;
  virtual void exitSignedLiteral(Grammar_WithConceptsAntlrParser::SignedLiteralContext *ctx) = 0;

  virtual void enterNumericLiteral_eof(Grammar_WithConceptsAntlrParser::NumericLiteral_eofContext *ctx) = 0;
  virtual void exitNumericLiteral_eof(Grammar_WithConceptsAntlrParser::NumericLiteral_eofContext *ctx) = 0;

  virtual void enterNumericLiteral(Grammar_WithConceptsAntlrParser::NumericLiteralContext *ctx) = 0;
  virtual void exitNumericLiteral(Grammar_WithConceptsAntlrParser::NumericLiteralContext *ctx) = 0;

  virtual void enterSignedNumericLiteral_eof(Grammar_WithConceptsAntlrParser::SignedNumericLiteral_eofContext *ctx) = 0;
  virtual void exitSignedNumericLiteral_eof(Grammar_WithConceptsAntlrParser::SignedNumericLiteral_eofContext *ctx) = 0;

  virtual void enterSignedNumericLiteral(Grammar_WithConceptsAntlrParser::SignedNumericLiteralContext *ctx) = 0;
  virtual void exitSignedNumericLiteral(Grammar_WithConceptsAntlrParser::SignedNumericLiteralContext *ctx) = 0;

  virtual void enterType_eof(Grammar_WithConceptsAntlrParser::Type_eofContext *ctx) = 0;
  virtual void exitType_eof(Grammar_WithConceptsAntlrParser::Type_eofContext *ctx) = 0;

  virtual void enterType(Grammar_WithConceptsAntlrParser::TypeContext *ctx) = 0;
  virtual void exitType(Grammar_WithConceptsAntlrParser::TypeContext *ctx) = 0;

  virtual void enterReferenceType_eof(Grammar_WithConceptsAntlrParser::ReferenceType_eofContext *ctx) = 0;
  virtual void exitReferenceType_eof(Grammar_WithConceptsAntlrParser::ReferenceType_eofContext *ctx) = 0;

  virtual void enterReferenceType(Grammar_WithConceptsAntlrParser::ReferenceTypeContext *ctx) = 0;
  virtual void exitReferenceType(Grammar_WithConceptsAntlrParser::ReferenceTypeContext *ctx) = 0;

  virtual void enterTypeArgument_eof(Grammar_WithConceptsAntlrParser::TypeArgument_eofContext *ctx) = 0;
  virtual void exitTypeArgument_eof(Grammar_WithConceptsAntlrParser::TypeArgument_eofContext *ctx) = 0;

  virtual void enterTypeArgument(Grammar_WithConceptsAntlrParser::TypeArgumentContext *ctx) = 0;
  virtual void exitTypeArgument(Grammar_WithConceptsAntlrParser::TypeArgumentContext *ctx) = 0;

  virtual void enterReturnType_eof(Grammar_WithConceptsAntlrParser::ReturnType_eofContext *ctx) = 0;
  virtual void exitReturnType_eof(Grammar_WithConceptsAntlrParser::ReturnType_eofContext *ctx) = 0;

  virtual void enterReturnType(Grammar_WithConceptsAntlrParser::ReturnTypeContext *ctx) = 0;
  virtual void exitReturnType(Grammar_WithConceptsAntlrParser::ReturnTypeContext *ctx) = 0;

  virtual void enterArrayType_eof(Grammar_WithConceptsAntlrParser::ArrayType_eofContext *ctx) = 0;
  virtual void exitArrayType_eof(Grammar_WithConceptsAntlrParser::ArrayType_eofContext *ctx) = 0;

  virtual void enterArrayType(Grammar_WithConceptsAntlrParser::ArrayTypeContext *ctx) = 0;
  virtual void exitArrayType(Grammar_WithConceptsAntlrParser::ArrayTypeContext *ctx) = 0;

  virtual void enterExpression_eof(Grammar_WithConceptsAntlrParser::Expression_eofContext *ctx) = 0;
  virtual void exitExpression_eof(Grammar_WithConceptsAntlrParser::Expression_eofContext *ctx) = 0;

  virtual void enterExpression(Grammar_WithConceptsAntlrParser::ExpressionContext *ctx) = 0;
  virtual void exitExpression(Grammar_WithConceptsAntlrParser::ExpressionContext *ctx) = 0;

  virtual void enterModifier_eof(Grammar_WithConceptsAntlrParser::Modifier_eofContext *ctx) = 0;
  virtual void exitModifier_eof(Grammar_WithConceptsAntlrParser::Modifier_eofContext *ctx) = 0;

  virtual void enterModifier(Grammar_WithConceptsAntlrParser::ModifierContext *ctx) = 0;
  virtual void exitModifier(Grammar_WithConceptsAntlrParser::ModifierContext *ctx) = 0;

  virtual void enterTypeDeclaration_eof(Grammar_WithConceptsAntlrParser::TypeDeclaration_eofContext *ctx) = 0;
  virtual void exitTypeDeclaration_eof(Grammar_WithConceptsAntlrParser::TypeDeclaration_eofContext *ctx) = 0;

  virtual void enterTypeDeclaration(Grammar_WithConceptsAntlrParser::TypeDeclarationContext *ctx) = 0;
  virtual void exitTypeDeclaration(Grammar_WithConceptsAntlrParser::TypeDeclarationContext *ctx) = 0;

  virtual void enterClassBodyDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassBodyDeclaration_eofContext *ctx) = 0;
  virtual void exitClassBodyDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassBodyDeclaration_eofContext *ctx) = 0;

  virtual void enterClassBodyDeclaration(Grammar_WithConceptsAntlrParser::ClassBodyDeclarationContext *ctx) = 0;
  virtual void exitClassBodyDeclaration(Grammar_WithConceptsAntlrParser::ClassBodyDeclarationContext *ctx) = 0;

  virtual void enterInterfaceBodyDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceBodyDeclaration_eofContext *ctx) = 0;
  virtual void exitInterfaceBodyDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceBodyDeclaration_eofContext *ctx) = 0;

  virtual void enterInterfaceBodyDeclaration(Grammar_WithConceptsAntlrParser::InterfaceBodyDeclarationContext *ctx) = 0;
  virtual void exitInterfaceBodyDeclaration(Grammar_WithConceptsAntlrParser::InterfaceBodyDeclarationContext *ctx) = 0;

  virtual void enterClassMemberDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassMemberDeclaration_eofContext *ctx) = 0;
  virtual void exitClassMemberDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassMemberDeclaration_eofContext *ctx) = 0;

  virtual void enterClassMemberDeclaration(Grammar_WithConceptsAntlrParser::ClassMemberDeclarationContext *ctx) = 0;
  virtual void exitClassMemberDeclaration(Grammar_WithConceptsAntlrParser::ClassMemberDeclarationContext *ctx) = 0;

  virtual void enterMethodBody_eof(Grammar_WithConceptsAntlrParser::MethodBody_eofContext *ctx) = 0;
  virtual void exitMethodBody_eof(Grammar_WithConceptsAntlrParser::MethodBody_eofContext *ctx) = 0;

  virtual void enterMethodBody(Grammar_WithConceptsAntlrParser::MethodBodyContext *ctx) = 0;
  virtual void exitMethodBody(Grammar_WithConceptsAntlrParser::MethodBodyContext *ctx) = 0;

  virtual void enterConstructorBody_eof(Grammar_WithConceptsAntlrParser::ConstructorBody_eofContext *ctx) = 0;
  virtual void exitConstructorBody_eof(Grammar_WithConceptsAntlrParser::ConstructorBody_eofContext *ctx) = 0;

  virtual void enterConstructorBody(Grammar_WithConceptsAntlrParser::ConstructorBodyContext *ctx) = 0;
  virtual void exitConstructorBody(Grammar_WithConceptsAntlrParser::ConstructorBodyContext *ctx) = 0;

  virtual void enterInterfaceMemberDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceMemberDeclaration_eofContext *ctx) = 0;
  virtual void exitInterfaceMemberDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceMemberDeclaration_eofContext *ctx) = 0;

  virtual void enterInterfaceMemberDeclaration(Grammar_WithConceptsAntlrParser::InterfaceMemberDeclarationContext *ctx) = 0;
  virtual void exitInterfaceMemberDeclaration(Grammar_WithConceptsAntlrParser::InterfaceMemberDeclarationContext *ctx) = 0;

  virtual void enterVariableInitializer_eof(Grammar_WithConceptsAntlrParser::VariableInitializer_eofContext *ctx) = 0;
  virtual void exitVariableInitializer_eof(Grammar_WithConceptsAntlrParser::VariableInitializer_eofContext *ctx) = 0;

  virtual void enterVariableInitializer(Grammar_WithConceptsAntlrParser::VariableInitializerContext *ctx) = 0;
  virtual void exitVariableInitializer(Grammar_WithConceptsAntlrParser::VariableInitializerContext *ctx) = 0;

  virtual void enterAnnotationArguments_eof(Grammar_WithConceptsAntlrParser::AnnotationArguments_eofContext *ctx) = 0;
  virtual void exitAnnotationArguments_eof(Grammar_WithConceptsAntlrParser::AnnotationArguments_eofContext *ctx) = 0;

  virtual void enterAnnotationArguments(Grammar_WithConceptsAntlrParser::AnnotationArgumentsContext *ctx) = 0;
  virtual void exitAnnotationArguments(Grammar_WithConceptsAntlrParser::AnnotationArgumentsContext *ctx) = 0;

  virtual void enterElementValue_eof(Grammar_WithConceptsAntlrParser::ElementValue_eofContext *ctx) = 0;
  virtual void exitElementValue_eof(Grammar_WithConceptsAntlrParser::ElementValue_eofContext *ctx) = 0;

  virtual void enterElementValue(Grammar_WithConceptsAntlrParser::ElementValueContext *ctx) = 0;
  virtual void exitElementValue(Grammar_WithConceptsAntlrParser::ElementValueContext *ctx) = 0;

  virtual void enterAnnotationTypeElementDeclaration_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeElementDeclaration_eofContext *ctx) = 0;
  virtual void exitAnnotationTypeElementDeclaration_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeElementDeclaration_eofContext *ctx) = 0;

  virtual void enterAnnotationTypeElementDeclaration(Grammar_WithConceptsAntlrParser::AnnotationTypeElementDeclarationContext *ctx) = 0;
  virtual void exitAnnotationTypeElementDeclaration(Grammar_WithConceptsAntlrParser::AnnotationTypeElementDeclarationContext *ctx) = 0;

  virtual void enterBlockStatement_eof(Grammar_WithConceptsAntlrParser::BlockStatement_eofContext *ctx) = 0;
  virtual void exitBlockStatement_eof(Grammar_WithConceptsAntlrParser::BlockStatement_eofContext *ctx) = 0;

  virtual void enterBlockStatement(Grammar_WithConceptsAntlrParser::BlockStatementContext *ctx) = 0;
  virtual void exitBlockStatement(Grammar_WithConceptsAntlrParser::BlockStatementContext *ctx) = 0;

  virtual void enterStatement_eof(Grammar_WithConceptsAntlrParser::Statement_eofContext *ctx) = 0;
  virtual void exitStatement_eof(Grammar_WithConceptsAntlrParser::Statement_eofContext *ctx) = 0;

  virtual void enterStatement(Grammar_WithConceptsAntlrParser::StatementContext *ctx) = 0;
  virtual void exitStatement(Grammar_WithConceptsAntlrParser::StatementContext *ctx) = 0;

  virtual void enterForControl_eof(Grammar_WithConceptsAntlrParser::ForControl_eofContext *ctx) = 0;
  virtual void exitForControl_eof(Grammar_WithConceptsAntlrParser::ForControl_eofContext *ctx) = 0;

  virtual void enterForControl(Grammar_WithConceptsAntlrParser::ForControlContext *ctx) = 0;
  virtual void exitForControl(Grammar_WithConceptsAntlrParser::ForControlContext *ctx) = 0;

  virtual void enterForInit_eof(Grammar_WithConceptsAntlrParser::ForInit_eofContext *ctx) = 0;
  virtual void exitForInit_eof(Grammar_WithConceptsAntlrParser::ForInit_eofContext *ctx) = 0;

  virtual void enterForInit(Grammar_WithConceptsAntlrParser::ForInitContext *ctx) = 0;
  virtual void exitForInit(Grammar_WithConceptsAntlrParser::ForInitContext *ctx) = 0;

  virtual void enterExceptionHandler_eof(Grammar_WithConceptsAntlrParser::ExceptionHandler_eofContext *ctx) = 0;
  virtual void exitExceptionHandler_eof(Grammar_WithConceptsAntlrParser::ExceptionHandler_eofContext *ctx) = 0;

  virtual void enterExceptionHandler(Grammar_WithConceptsAntlrParser::ExceptionHandlerContext *ctx) = 0;
  virtual void exitExceptionHandler(Grammar_WithConceptsAntlrParser::ExceptionHandlerContext *ctx) = 0;

  virtual void enterFinallyBlock_eof(Grammar_WithConceptsAntlrParser::FinallyBlock_eofContext *ctx) = 0;
  virtual void exitFinallyBlock_eof(Grammar_WithConceptsAntlrParser::FinallyBlock_eofContext *ctx) = 0;

  virtual void enterFinallyBlock(Grammar_WithConceptsAntlrParser::FinallyBlockContext *ctx) = 0;
  virtual void exitFinallyBlock(Grammar_WithConceptsAntlrParser::FinallyBlockContext *ctx) = 0;

  virtual void enterSwitchLabel_eof(Grammar_WithConceptsAntlrParser::SwitchLabel_eofContext *ctx) = 0;
  virtual void exitSwitchLabel_eof(Grammar_WithConceptsAntlrParser::SwitchLabel_eofContext *ctx) = 0;

  virtual void enterSwitchLabel(Grammar_WithConceptsAntlrParser::SwitchLabelContext *ctx) = 0;
  virtual void exitSwitchLabel(Grammar_WithConceptsAntlrParser::SwitchLabelContext *ctx) = 0;

  virtual void enterCreator_eof(Grammar_WithConceptsAntlrParser::Creator_eofContext *ctx) = 0;
  virtual void exitCreator_eof(Grammar_WithConceptsAntlrParser::Creator_eofContext *ctx) = 0;

  virtual void enterCreator(Grammar_WithConceptsAntlrParser::CreatorContext *ctx) = 0;
  virtual void exitCreator(Grammar_WithConceptsAntlrParser::CreatorContext *ctx) = 0;

  virtual void enterArrayDimensionSpecifier_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionSpecifier_eofContext *ctx) = 0;
  virtual void exitArrayDimensionSpecifier_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionSpecifier_eofContext *ctx) = 0;

  virtual void enterArrayDimensionSpecifier(Grammar_WithConceptsAntlrParser::ArrayDimensionSpecifierContext *ctx) = 0;
  virtual void exitArrayDimensionSpecifier(Grammar_WithConceptsAntlrParser::ArrayDimensionSpecifierContext *ctx) = 0;

  virtual void enterProd_eof(Grammar_WithConceptsAntlrParser::Prod_eofContext *ctx) = 0;
  virtual void exitProd_eof(Grammar_WithConceptsAntlrParser::Prod_eofContext *ctx) = 0;

  virtual void enterProd(Grammar_WithConceptsAntlrParser::ProdContext *ctx) = 0;
  virtual void exitProd(Grammar_WithConceptsAntlrParser::ProdContext *ctx) = 0;

  virtual void enterParserProd_eof(Grammar_WithConceptsAntlrParser::ParserProd_eofContext *ctx) = 0;
  virtual void exitParserProd_eof(Grammar_WithConceptsAntlrParser::ParserProd_eofContext *ctx) = 0;

  virtual void enterParserProd(Grammar_WithConceptsAntlrParser::ParserProdContext *ctx) = 0;
  virtual void exitParserProd(Grammar_WithConceptsAntlrParser::ParserProdContext *ctx) = 0;

  virtual void enterRuleComponent_eof(Grammar_WithConceptsAntlrParser::RuleComponent_eofContext *ctx) = 0;
  virtual void exitRuleComponent_eof(Grammar_WithConceptsAntlrParser::RuleComponent_eofContext *ctx) = 0;

  virtual void enterRuleComponent(Grammar_WithConceptsAntlrParser::RuleComponentContext *ctx) = 0;
  virtual void exitRuleComponent(Grammar_WithConceptsAntlrParser::RuleComponentContext *ctx) = 0;

  virtual void enterITerminal_eof(Grammar_WithConceptsAntlrParser::ITerminal_eofContext *ctx) = 0;
  virtual void exitITerminal_eof(Grammar_WithConceptsAntlrParser::ITerminal_eofContext *ctx) = 0;

  virtual void enterITerminal(Grammar_WithConceptsAntlrParser::ITerminalContext *ctx) = 0;
  virtual void exitITerminal(Grammar_WithConceptsAntlrParser::ITerminalContext *ctx) = 0;

  virtual void enterLexComponent_eof(Grammar_WithConceptsAntlrParser::LexComponent_eofContext *ctx) = 0;
  virtual void exitLexComponent_eof(Grammar_WithConceptsAntlrParser::LexComponent_eofContext *ctx) = 0;

  virtual void enterLexComponent(Grammar_WithConceptsAntlrParser::LexComponentContext *ctx) = 0;
  virtual void exitLexComponent(Grammar_WithConceptsAntlrParser::LexComponentContext *ctx) = 0;


};



// Generated from Grammar_WithConceptsAntlr.g4 by ANTLR 4.7.1





