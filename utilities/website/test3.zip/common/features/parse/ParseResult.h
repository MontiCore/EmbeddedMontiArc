#pragma once
#ifndef COMMON_PARSE_RESULT_H
#define COMMON_PARSE_RESULT_H

#include "common/features/analyze/AnalyzeListener.h"
#include "common/features/outline/OutlineListener.h"

namespace common {
    class ParseResult {
        private:
            AnalyzeListener* analyzeListener;
            OutlineListener* outlineListener;

        public:
            ParseResult(AnalyzeListener* analyzeListener, OutlineListener* outlineListener);
            ~ParseResult();
            AnalyzeListener* getAnalyzeListener();
            OutlineListener* getOutlineListener();
    };
}

#endif


using common::ParseResult;
using common::AnalyzeListener;
using common::OutlineListener;

ParseResult::ParseResult(AnalyzeListener* analyzeListener, OutlineListener* outlineListener) {
    this->analyzeListener = analyzeListener;
    this->outlineListener = outlineListener;
}

ParseResult::~ParseResult() {
    //delete this->analyzeListener;
    //delete this->outlineListener;
}

AnalyzeListener* ParseResult::getAnalyzeListener() {
    return this->analyzeListener;
}

OutlineListener* ParseResult::getOutlineListener() {
    return this->outlineListener;
}