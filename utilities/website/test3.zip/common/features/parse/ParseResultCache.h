#pragma once
#ifndef COMMON_PARSE_RESULT_CACHE_H
#define COMMON_PARSE_RESULT_CACHE_H

#include "ParseResult.h"

namespace common {
    class ParseResultCache {
        private:
            ParseResultCache();

            ParseResult* result;
        public:
            virtual ~ParseResultCache();

            static ParseResultCache& getInstance();

            static void set(ParseResult* result);
            virtual void doSet(ParseResult* result);

            static ParseResult* get(); 
            virtual ParseResult* doGet();
    };
}

#endif


using common::ParseResultCache;
using common::ParseResult;

ParseResultCache::ParseResultCache() {}

ParseResultCache::~ParseResultCache() {
    //delete this->result;
}

ParseResultCache& ParseResultCache::getInstance() {
    static ParseResultCache INSTANCE;
    return INSTANCE;
}

void ParseResultCache::set(ParseResult* result) {
    ParseResultCache::getInstance().doSet(result);
}

void ParseResultCache::doSet(ParseResult* result) {
    //delete this->result;
    this->result = result;
}

ParseResult* ParseResultCache::get() {
    return ParseResultCache::getInstance().doGet();
}

ParseResult* ParseResultCache::doGet() {
    return this->result;
}