#pragma once
#ifndef COMMON_SYMBOL_H
#define COMMON_SYMBOL_H

#include <iostream>
#include <emscripten/val.h>

#include "common/features/shared/Position.h"

using common::Position;

using emscripten::val;

using std::string;
using std::shared_ptr;

namespace common {
	class Symbol {
		protected:
			string identifier;
			string package;
			string kind;
			shared_ptr<Position> position;
		public:
			Symbol(string, string, string, shared_ptr<Position>);
			virtual ~Symbol();

			virtual string getIdentifier() const;
			virtual string getPackage() const;
			virtual string getKind() const;
			virtual shared_ptr<Position> getPosition() const;

			virtual val toSQL() const;
	};
}

#endif


using common::Symbol;
using common::Position;

using std::string;
using std::shared_ptr;

Symbol::Symbol(string identifier, string package, string kind, shared_ptr<Position> position) {
	this->identifier = identifier;
	this->package = package;
	this->kind = kind;
	this->position = position;
}

Symbol::~Symbol() = default;

string Symbol::getIdentifier() const {
	return this->identifier;
}

string Symbol::getPackage() const {
	return this->package;
}

string Symbol::getKind() const {
	return this->kind;
}

shared_ptr<Position> Symbol::getPosition() const {
	return this->position;
}

val Symbol::toSQL() const {
	val result = val::object();

	val identifier = val(this->identifier);
	val package = val(this->package);
	val kind = val(this->kind);
	val position = this->position->toJSON();

	result.set("identifier", identifier);
	result.set("package", package);
	result.set("kind", kind);
	result.set("position", position);

	return result;
}