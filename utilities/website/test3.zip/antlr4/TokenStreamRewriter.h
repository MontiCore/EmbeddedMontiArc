﻿/* Copyright (c) 2012-2017 The ANTLR Project. All rights reserved.
 * Use of this file is governed by the BSD 3-clause license that
 * can be found in the LICENSE.txt file in the project root.
 */

#pragma once

namespace antlr4 {

  /**
   * Useful for rewriting out a buffered input token stream after doing some
   * augmentation or other manipulations on it.
   *
   * <p>
   * You can insert stuff, replace, and delete chunks. Note that the operations
   * are done lazily--only if you convert the buffer to a {@link String} with
   * {@link TokenStream#getText()}. This is very efficient because you are not
   * moving data around all the time. As the buffer of tokens is converted to
   * strings, the {@link #getText()} method(s) scan the input token stream and
   * check to see if there is an operation at the current index. If so, the
   * operation is done and then normal {@link String} rendering continues on the
   * buffer. This is like having multiple Turing machine instruction streams
   * (programs) operating on a single input tape. :)</p>
   *
   * <p>
   * This rewriter makes no modifications to the token stream. It does not ask the
   * stream to fill itself up nor does it advance the input cursor. The token
   * stream {@link TokenStream#index()} will return the same value before and
   * after any {@link #getText()} call.</p>
   *
   * <p>
   * The rewriter only works on tokens that you have in the buffer and ignores the
   * current input cursor. If you are buffering tokens on-demand, calling
   * {@link #getText()} halfway through the input will only do rewrites for those
   * tokens in the first half of the file.</p>
   *
   * <p>
   * Since the operations are done lazily at {@link #getText}-time, operations do
   * not screw up the token index values. That is, an insert operation at token
   * index {@code i} does not change the index values for tokens
   * {@code i}+1..n-1.</p>
   *
   * <p>
   * Because operations never actually alter the buffer, you may always get the
   * original token stream back without undoing anything. Since the instructions
   * are queued up, you can easily simulate transactions and roll back any changes
   * if there is an error just by removing instructions. For example,</p>
   *
   * <pre>
   * CharStream input = new ANTLRFileStream("input");
   * TLexer lex = new TLexer(input);
   * CommonTokenStream tokens = new CommonTokenStream(lex);
   * T parser = new T(tokens);
   * TokenStreamRewriter rewriter = new TokenStreamRewriter(tokens);
   * parser.startRule();
   * </pre>
   *
   * <p>
   * Then in the rules, you can execute (assuming rewriter is visible):</p>
   *
   * <pre>
   * Token t,u;
   * ...
   * rewriter.insertAfter(t, "text to put after t");}
   * rewriter.insertAfter(u, "text after u");}
   * System.out.println(rewriter.getText());
   * </pre>
   *
   * <p>
   * You can also have multiple "instruction streams" and get multiple rewrites
   * from a single pass over the input. Just name the instruction streams and use
   * that name again when printing the buffer. This could be useful for generating
   * a C file and also its header file--all from the same buffer:</p>
   *
   * <pre>
   * rewriter.insertAfter("pass1", t, "text to put after t");}
   * rewriter.insertAfter("pass2", u, "text after u");}
   * System.out.println(rewriter.getText("pass1"));
   * System.out.println(rewriter.getText("pass2"));
   * </pre>
   *
   * <p>
   * If you don't use named rewrite streams, a "default" stream is used as the
   * first example shows.</p>
   */
  class ANTLR4CPP_PUBLIC TokenStreamRewriter {
  public:
    static const std::string DEFAULT_PROGRAM_NAME;
    static const size_t PROGRAM_INIT_SIZE = 100;
    static const size_t MIN_TOKEN_INDEX = 0;

    TokenStreamRewriter(TokenStream *tokens);
    virtual ~TokenStreamRewriter();

    TokenStream *getTokenStream();

    virtual void rollback(size_t instructionIndex);

    /// Rollback the instruction stream for a program so that
    /// the indicated instruction (via instructionIndex) is no
    /// longer in the stream.  UNTESTED!
    virtual void rollback(const std::string &programName, size_t instructionIndex);

    virtual void deleteProgram();

    /// Reset the program so that no instructions exist.
    virtual void deleteProgram(const std::string &programName);
    virtual void insertAfter(Token *t, const std::string& text);
    virtual void insertAfter(size_t index, const std::string& text);
    virtual void insertAfter(const std::string &programName, Token *t, const std::string& text);
    virtual void insertAfter(const std::string &programName, size_t index, const std::string& text);

    virtual void insertBefore(Token *t, const std::string& text);
    virtual void insertBefore(size_t index, const std::string& text);
    virtual void insertBefore(const std::string &programName, Token *t, const std::string& text);
    virtual void insertBefore(const std::string &programName, size_t index, const std::string& text);

    virtual void replace(size_t index, const std::string& text);
    virtual void replace(size_t from, size_t to, const std::string& text);
    virtual void replace(Token *indexT, const std::string& text);
    virtual void replace(Token *from, Token *to, const std::string& text);
    virtual void replace(const std::string &programName, size_t from, size_t to, const std::string& text);
    virtual void replace(const std::string &programName, Token *from, Token *to, const std::string& text);

    virtual void Delete(size_t index);
    virtual void Delete(size_t from, size_t to);
    virtual void Delete(Token *indexT);
    virtual void Delete(Token *from, Token *to);
    virtual void Delete(const std::string &programName, size_t from, size_t to);
    virtual void Delete(const std::string &programName, Token *from, Token *to);

    virtual size_t getLastRewriteTokenIndex();

    /// Return the text from the original tokens altered per the
    /// instructions given to this rewriter.
    virtual std::string getText();

    /** Return the text from the original tokens altered per the
     *  instructions given to this rewriter in programName.
     */
    std::string getText(std::string programName);

    /// Return the text associated with the tokens in the interval from the
    /// original token stream but with the alterations given to this rewriter.
    /// The interval refers to the indexes in the original token stream.
    /// We do not alter the token stream in any way, so the indexes
    /// and intervals are still consistent. Includes any operations done
    /// to the first and last token in the interval. So, if you did an
    /// insertBefore on the first token, you would get that insertion.
    /// The same is true if you do an insertAfter the stop token.
    virtual std::string getText(const misc::Interval &interval);

    virtual std::string getText(const std::string &programName, const misc::Interval &interval);

  protected:
    class RewriteOperation {
    public:
      /// What index into rewrites List are we?
      size_t index;
      std::string text;

      /// Token buffer index.
      size_t instructionIndex;

      RewriteOperation(TokenStreamRewriter *outerInstance, size_t index);
      RewriteOperation(TokenStreamRewriter *outerInstance, size_t index, const std::string& text);
      virtual ~RewriteOperation();

      /// Execute the rewrite operation by possibly adding to the buffer.
      /// Return the index of the next token to operate on.

      virtual size_t execute(std::string *buf);
      virtual std::string toString();

    private:
      TokenStreamRewriter *const outerInstance;
      void InitializeInstanceFields();
    };

    class InsertBeforeOp : public RewriteOperation {
    private:
      TokenStreamRewriter *const outerInstance;

    public:
      InsertBeforeOp(TokenStreamRewriter *outerInstance, size_t index, const std::string& text);

      virtual size_t execute(std::string *buf) override;
    };

    class ReplaceOp : public RewriteOperation {
    private:
      TokenStreamRewriter *const outerInstance;

    public:
      size_t lastIndex;

      ReplaceOp(TokenStreamRewriter *outerInstance, size_t from, size_t to, const std::string& text);
      virtual size_t execute(std::string *buf) override;
      virtual std::string toString() override;

    private:
      void InitializeInstanceFields();
    };

    /// Our source stream
    TokenStream *const tokens;

    /// You may have multiple, named streams of rewrite operations.
    /// I'm calling these things "programs."
    /// Maps String (name) -> rewrite (List)
    std::map<std::string, std::vector<RewriteOperation*>> _programs;

    /// <summary>
    /// Map String (program name) -> Integer index </summary>
    std::map<std::string, size_t> _lastRewriteTokenIndexes;
    virtual size_t getLastRewriteTokenIndex(const std::string &programName);
    virtual void setLastRewriteTokenIndex(const std::string &programName, size_t i);
    virtual std::vector<RewriteOperation*>& getProgram(const std::string &name);

    /// <summary>
    /// We need to combine operations and report invalid operations (like
    ///  overlapping replaces that are not completed nested).  Inserts to
    ///  same index need to be combined etc...   Here are the cases:
    ///
    ///  I.i.u I.j.v                                leave alone, nonoverlapping
    ///  I.i.u I.i.v                                combine: Iivu
    ///
    ///  R.i-j.u R.x-y.v    | i-j in x-y            delete first R
    ///  R.i-j.u R.i-j.v                            delete first R
    ///  R.i-j.u R.x-y.v    | x-y in i-j            ERROR
    ///  R.i-j.u R.x-y.v    | boundaries overlap    ERROR
    ///
    ///  Delete special case of replace (text==null):
    ///  D.i-j.u D.x-y.v    | boundaries overlap    combine to max(min)..max(right)
    ///
    ///  I.i.u R.x-y.v | i in (x+1)-y           delete I (since insert before
    ///                                         we're not deleting i)
    ///  I.i.u R.x-y.v | i not in (x+1)-y       leave alone, nonoverlapping
    ///  R.x-y.v I.i.u | i in x-y               ERROR
    ///  R.x-y.v I.x.u                          R.x-y.uv (combine, delete I)
    ///  R.x-y.v I.i.u | i not in x-y           leave alone, nonoverlapping
    ///
    ///  I.i.u = insert u before op @ index i
    ///  R.x-y.u = replace x-y indexed tokens with u
    ///
    ///  First we need to examine replaces.  For any replace op:
    ///
    ///         1. wipe out any insertions before op within that range.
    ///     2. Drop any replace op before that is contained completely within
    ///         that range.
    ///     3. Throw exception upon boundary overlap with any previous replace.
    ///
    ///  Then we can deal with inserts:
    ///
    ///         1. for any inserts to same index, combine even if not adjacent.
    ///         2. for any prior replace with same left boundary, combine this
    ///         insert with replace and delete this replace.
    ///         3. throw exception if index in same range as previous replace
    ///
    ///  Don't actually delete; make op null in list. Easier to walk list.
    ///  Later we can throw as we add to index -> op map.
    ///
    ///  Note that I.2 R.2-2 will wipe out I.2 even though, technically, the
    ///  inserted stuff would be before the replace range.  But, if you
    ///  add tokens in front of a method body '{' and then delete the method
    ///  body, I think the stuff before the '{' you added should disappear too.
    ///
    ///  Return a map from token index to operation.
    /// </summary>
    virtual std::unordered_map<size_t, RewriteOperation*> reduceToSingleOperationPerIndex(std::vector<RewriteOperation*> &rewrites);

    virtual std::string catOpText(std::string *a, std::string *b);

    /// Get all operations before an index of a particular kind.
    template <typename T>
    std::vector<T *> getKindOfOps(std::vector<RewriteOperation *> rewrites, size_t before) {
      std::vector<T *> ops;
      for (size_t i = 0; i < before && i < rewrites.size(); i++) {
        T *op = dynamic_cast<T *>(rewrites[i]);
        if (op == nullptr) { // ignore deleted or non matching entries
          continue;
        }
        ops.push_back(op);
      }
      return ops;
    }

  private:
    std::vector<RewriteOperation *>& initializeProgram(const std::string &name);

  };

} // namespace antlr4

﻿/* Copyright (c) 2012-2017 The ANTLR Project. All rights reserved.
 * Use of this file is governed by the BSD 3-clause license that
 * can be found in the LICENSE.txt file in the project root.
 */

#include "Exceptions.h"
#include "misc/Interval.h"
#include "Token.h"
#include "TokenStream.h"



using namespace antlr4;

using antlr4::misc::Interval;

TokenStreamRewriter::RewriteOperation::RewriteOperation(TokenStreamRewriter *outerInstance_, size_t index_)
  : outerInstance(outerInstance_) {

  InitializeInstanceFields();
  this->index = index_;
}

TokenStreamRewriter::RewriteOperation::RewriteOperation(TokenStreamRewriter *outerInstance_, size_t index_,
  const std::string& text_) : outerInstance(outerInstance_) {

  InitializeInstanceFields();
  this->index = index_;
  this->text = text_;
}

TokenStreamRewriter::RewriteOperation::~RewriteOperation()
{
}

size_t TokenStreamRewriter::RewriteOperation::execute(std::string * /*buf*/) {
  return index;
}

std::string TokenStreamRewriter::RewriteOperation::toString() {
  std::string opName = "TokenStreamRewriter";
  size_t dollarIndex = opName.find('$');
  opName = opName.substr(dollarIndex + 1, opName.length() - (dollarIndex + 1));
  return "<" + opName + "@" + outerInstance->tokens->get(dollarIndex)->getText() + ":\"" + text + "\">";
}

void TokenStreamRewriter::RewriteOperation::InitializeInstanceFields() {
  instructionIndex = 0;
  index = 0;
}

TokenStreamRewriter::InsertBeforeOp::InsertBeforeOp(TokenStreamRewriter *outerInstance_, size_t index_, const std::string& text_)
: RewriteOperation(outerInstance_, index_, text_), outerInstance(outerInstance_) {
}

size_t TokenStreamRewriter::InsertBeforeOp::execute(std::string *buf) {
  buf->append(text);
  if (outerInstance->tokens->get(index)->getType() != Token::EOF) {
    buf->append(outerInstance->tokens->get(index)->getText());
  }
  return index + 1;
}

TokenStreamRewriter::ReplaceOp::ReplaceOp(TokenStreamRewriter *outerInstance_, size_t from, size_t to, const std::string& text)
: RewriteOperation(outerInstance_, from, text), outerInstance(outerInstance_) {

  InitializeInstanceFields();
  lastIndex = to;
}

size_t TokenStreamRewriter::ReplaceOp::execute(std::string *buf) {
  buf->append(text);
  return lastIndex + 1;
}

std::string TokenStreamRewriter::ReplaceOp::toString() {
  if (text.empty()) {
    return "<DeleteOp@" + outerInstance->tokens->get(index)->getText() + ".." + outerInstance->tokens->get(lastIndex)->getText() + ">";
  }
  return "<ReplaceOp@" + outerInstance->tokens->get(index)->getText() + ".." + outerInstance->tokens->get(lastIndex)->getText() + ":\"" + text + "\">";
}

void TokenStreamRewriter::ReplaceOp::InitializeInstanceFields() {
  lastIndex = 0;
}

//------------------ TokenStreamRewriter -------------------------------------------------------------------------------

const std::string TokenStreamRewriter::DEFAULT_PROGRAM_NAME = "default";

TokenStreamRewriter::TokenStreamRewriter(TokenStream *tokens_) : tokens(tokens_) {
  _programs[DEFAULT_PROGRAM_NAME].reserve(PROGRAM_INIT_SIZE);
}

TokenStreamRewriter::~TokenStreamRewriter() {
  for (auto program : _programs) {
    for (auto operation : program.second) {
      delete operation;
    }
  }
}

TokenStream *TokenStreamRewriter::getTokenStream() {
  return tokens;
}

void TokenStreamRewriter::rollback(size_t instructionIndex) {
  rollback(DEFAULT_PROGRAM_NAME, instructionIndex);
}

void TokenStreamRewriter::rollback(const std::string &programName, size_t instructionIndex) {
  std::vector<RewriteOperation*> is = _programs[programName];
  if (is.size() > 0) {
    _programs.insert({ programName, std::vector<RewriteOperation*>(is.begin() + MIN_TOKEN_INDEX, is.begin() + instructionIndex) });
  }
}

void TokenStreamRewriter::deleteProgram() {
  deleteProgram(DEFAULT_PROGRAM_NAME);
}

void TokenStreamRewriter::deleteProgram(const std::string &programName) {
  rollback(programName, MIN_TOKEN_INDEX);
}

void TokenStreamRewriter::insertAfter(Token *t, const std::string& text) {
  insertAfter(DEFAULT_PROGRAM_NAME, t, text);
}

void TokenStreamRewriter::insertAfter(size_t index, const std::string& text) {
  insertAfter(DEFAULT_PROGRAM_NAME, index, text);
}

void TokenStreamRewriter::insertAfter(const std::string &programName, Token *t, const std::string& text) {
  insertAfter(programName, t->getTokenIndex(), text);
}

void TokenStreamRewriter::insertAfter(const std::string &programName, size_t index, const std::string& text) {
  // to insert after, just insert before next index (even if past end)
  insertBefore(programName, index + 1, text);
}

void TokenStreamRewriter::insertBefore(Token *t, const std::string& text) {
  insertBefore(DEFAULT_PROGRAM_NAME, t, text);
}

void TokenStreamRewriter::insertBefore(size_t index, const std::string& text) {
  insertBefore(DEFAULT_PROGRAM_NAME, index, text);
}

void TokenStreamRewriter::insertBefore(const std::string &programName, Token *t, const std::string& text) {
  insertBefore(programName, t->getTokenIndex(), text);
}

void TokenStreamRewriter::insertBefore(const std::string &programName, size_t index, const std::string& text) {
  RewriteOperation *op = new InsertBeforeOp(this, index, text); /* mem-check: deleted in d-tor */
  std::vector<RewriteOperation*> &rewrites = getProgram(programName);
  op->instructionIndex = rewrites.size();
  rewrites.push_back(op);
}

void TokenStreamRewriter::replace(size_t index, const std::string& text) {
  replace(DEFAULT_PROGRAM_NAME, index, index, text);
}

void TokenStreamRewriter::replace(size_t from, size_t to, const std::string& text) {
  replace(DEFAULT_PROGRAM_NAME, from, to, text);
}

void TokenStreamRewriter::replace(Token *indexT, const std::string& text) {
  replace(DEFAULT_PROGRAM_NAME, indexT, indexT, text);
}

void TokenStreamRewriter::replace(Token *from, Token *to, const std::string& text) {
  replace(DEFAULT_PROGRAM_NAME, from, to, text);
}

void TokenStreamRewriter::replace(const std::string &programName, size_t from, size_t to, const std::string& text) {
  if (from > to || to >= tokens->size()) {
    throw IllegalArgumentException("replace: range invalid: " + std::to_string(from) + ".." + std::to_string(to) +
                                   "(size = " + std::to_string(tokens->size()) + ")");
  }
  RewriteOperation *op = new ReplaceOp(this, from, to, text); /* mem-check: deleted in d-tor */
  std::vector<RewriteOperation*> &rewrites = getProgram(programName);
  op->instructionIndex = rewrites.size();
  rewrites.push_back(op);
}

void TokenStreamRewriter::replace(const std::string &programName, Token *from, Token *to, const std::string& text) {
  replace(programName, from->getTokenIndex(), to->getTokenIndex(), text);
}

void TokenStreamRewriter::Delete(size_t index) {
  Delete(DEFAULT_PROGRAM_NAME, index, index);
}

void TokenStreamRewriter::Delete(size_t from, size_t to) {
  Delete(DEFAULT_PROGRAM_NAME, from, to);
}

void TokenStreamRewriter::Delete(Token *indexT) {
  Delete(DEFAULT_PROGRAM_NAME, indexT, indexT);
}

void TokenStreamRewriter::Delete(Token *from, Token *to) {
  Delete(DEFAULT_PROGRAM_NAME, from, to);
}

void TokenStreamRewriter::Delete(const std::string &programName, size_t from, size_t to) {
  std::string nullString;
  replace(programName, from, to, nullString);
}

void TokenStreamRewriter::Delete(const std::string &programName, Token *from, Token *to) {
  std::string nullString;
  replace(programName, from, to, nullString);
}

size_t TokenStreamRewriter::getLastRewriteTokenIndex() {
  return getLastRewriteTokenIndex(DEFAULT_PROGRAM_NAME);
}

size_t TokenStreamRewriter::getLastRewriteTokenIndex(const std::string &programName) {
  if (_lastRewriteTokenIndexes.find(programName) == _lastRewriteTokenIndexes.end()) {
    return INVALID_INDEX;
  }
  return _lastRewriteTokenIndexes[programName];
}

void TokenStreamRewriter::setLastRewriteTokenIndex(const std::string &programName, size_t i) {
  _lastRewriteTokenIndexes.insert({ programName, i });
}

std::vector<TokenStreamRewriter::RewriteOperation*>& TokenStreamRewriter::getProgram(const std::string &name) {
  auto iterator = _programs.find(name);
  if (iterator == _programs.end()) {
    return initializeProgram(name);
  }
  return iterator->second;
}

std::vector<TokenStreamRewriter::RewriteOperation*>& TokenStreamRewriter::initializeProgram(const std::string &name) {
  _programs[name].reserve(PROGRAM_INIT_SIZE);
  return _programs[name];
}

std::string TokenStreamRewriter::getText() {
  return getText(DEFAULT_PROGRAM_NAME, Interval(0UL, tokens->size() - 1));
}

std::string TokenStreamRewriter::getText(std::string programName) {
  return getText(programName, Interval(0UL, tokens->size() - 1));
}

std::string TokenStreamRewriter::getText(const Interval &interval) {
  return getText(DEFAULT_PROGRAM_NAME, interval);
}

std::string TokenStreamRewriter::getText(const std::string &programName, const Interval &interval) {
  std::vector<TokenStreamRewriter::RewriteOperation*> &rewrites = _programs[programName];
  size_t start = interval.a;
  size_t stop = interval.b;

  // ensure start/end are in range
  if (stop > tokens->size() - 1) {
    stop = tokens->size() - 1;
  }
  if (start == INVALID_INDEX) {
    start = 0;
  }

  if (rewrites.empty() || rewrites.empty()) {
    return tokens->getText(interval); // no instructions to execute
  }
  std::string buf;

  // First, optimize instruction stream
  std::unordered_map<size_t, TokenStreamRewriter::RewriteOperation*> indexToOp = reduceToSingleOperationPerIndex(rewrites);

  // Walk buffer, executing instructions and emitting tokens
  size_t i = start;
  while (i <= stop && i < tokens->size()) {
    RewriteOperation *op = indexToOp[i];
    indexToOp.erase(i); // remove so any left have index size-1
    Token *t = tokens->get(i);
    if (op == nullptr) {
      // no operation at that index, just dump token
      if (t->getType() != Token::EOF) {
        buf.append(t->getText());
      }
      i++; // move to next token
    }
    else {
      i = op->execute(&buf); // execute operation and skip
    }
  }

  // include stuff after end if it's last index in buffer
  // So, if they did an insertAfter(lastValidIndex, "foo"), include
  // foo if end==lastValidIndex.
  if (stop == tokens->size() - 1) {
    // Scan any remaining operations after last token
    // should be included (they will be inserts).
    for (auto op : indexToOp) {
      if (op.second->index >= tokens->size() - 1) {
        buf.append(op.second->text);
      }
    }
  }
  return buf;
}

std::unordered_map<size_t, TokenStreamRewriter::RewriteOperation*> TokenStreamRewriter::reduceToSingleOperationPerIndex(
  std::vector<TokenStreamRewriter::RewriteOperation*> &rewrites) {


  // WALK REPLACES
  for (size_t i = 0; i < rewrites.size(); ++i) {
    TokenStreamRewriter::RewriteOperation *op = rewrites[i];
    ReplaceOp *rop = dynamic_cast<ReplaceOp *>(op);
    if (rop == nullptr)
      continue;

    // Wipe prior inserts within range
    std::vector<InsertBeforeOp *> inserts = getKindOfOps<InsertBeforeOp>(rewrites, i);
    for (auto iop : inserts) {
      if (iop->index == rop->index) {
        // E.g., insert before 2, delete 2..2; update replace
        // text to include insert before, kill insert
        delete rewrites[iop->instructionIndex];
        rewrites[iop->instructionIndex] = nullptr;
        rop->text = iop->text + (!rop->text.empty() ? rop->text : "");
      }
      else if (iop->index > rop->index && iop->index <= rop->lastIndex) {
        // delete insert as it's a no-op.
        delete rewrites[iop->instructionIndex];
        rewrites[iop->instructionIndex] = nullptr;
      }
    }
    // Drop any prior replaces contained within
    std::vector<ReplaceOp*> prevReplaces = getKindOfOps<ReplaceOp>(rewrites, i);
    for (auto prevRop : prevReplaces) {
      if (prevRop->index >= rop->index && prevRop->lastIndex <= rop->lastIndex) {
        // delete replace as it's a no-op.
        delete rewrites[prevRop->instructionIndex];
        rewrites[prevRop->instructionIndex] = nullptr;
        continue;
      }
      // throw exception unless disjoint or identical
      bool disjoint = prevRop->lastIndex < rop->index || prevRop->index > rop->lastIndex;
      bool same = prevRop->index == rop->index && prevRop->lastIndex == rop->lastIndex;
      // Delete special case of replace (text==null):
      // D.i-j.u D.x-y.v    | boundaries overlap    combine to max(min)..max(right)
      if (prevRop->text.empty() && rop->text.empty() && !disjoint) {
        delete rewrites[prevRop->instructionIndex];
        rewrites[prevRop->instructionIndex] = nullptr; // kill first delete
        rop->index = std::min(prevRop->index, rop->index);
        rop->lastIndex = std::max(prevRop->lastIndex, rop->lastIndex);
        std::cout << "new rop " << rop << std::endl;
      }
      else if (!disjoint && !same) {
        throw IllegalArgumentException("replace op boundaries of " + rop->toString() +
                                       " overlap with previous " + prevRop->toString());
      }
    }
  }

  // WALK INSERTS
  for (size_t i = 0; i < rewrites.size(); i++) {
    InsertBeforeOp *iop = dynamic_cast<InsertBeforeOp *>(rewrites[i]);
    if (iop == nullptr)
      continue;

    // combine current insert with prior if any at same index

    std::vector<InsertBeforeOp *> prevInserts = getKindOfOps<InsertBeforeOp>(rewrites, i);
    for (auto prevIop : prevInserts) {
      if (prevIop->index == iop->index) { // combine objects
                                          // convert to strings...we're in process of toString'ing
                                          // whole token buffer so no lazy eval issue with any templates
        iop->text = catOpText(&iop->text, &prevIop->text);
        // delete redundant prior insert
        delete rewrites[prevIop->instructionIndex];
        rewrites[prevIop->instructionIndex] = nullptr;
      }
    }
    // look for replaces where iop.index is in range; error
    std::vector<ReplaceOp*> prevReplaces = getKindOfOps<ReplaceOp>(rewrites, i);
    for (auto rop : prevReplaces) {
      if (iop->index == rop->index) {
        rop->text = catOpText(&iop->text, &rop->text);
        delete rewrites[i];
        rewrites[i] = nullptr; // delete current insert
        continue;
      }
      if (iop->index >= rop->index && iop->index <= rop->lastIndex) {
        throw IllegalArgumentException("insert op " + iop->toString() + " within boundaries of previous " + rop->toString());
      }
    }
  }

  std::unordered_map<size_t, TokenStreamRewriter::RewriteOperation*> m;
  for (TokenStreamRewriter::RewriteOperation *op : rewrites) {
    if (op == nullptr) { // ignore deleted ops
      continue;
    }
    if (m.count(op->index) > 0) {
      throw RuntimeException("should only be one op per index");
    }
    m[op->index] = op;
  }

  return m;
}

std::string TokenStreamRewriter::catOpText(std::string *a, std::string *b) {
  std::string x = "";
  std::string y = "";
  if (a != nullptr) {
    x = *a;
  }
  if (b != nullptr) {
    y = *b;
  }
  return x + y;
}
