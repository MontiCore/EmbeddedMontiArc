﻿/* Copyright (c) 2012-2017 The ANTLR Project. All rights reserved.
 * Use of this file is governed by the BSD 3-clause license that
 * can be found in the LICENSE.txt file in the project root.
 */

#pragma once

#include "ProxyErrorListener.h"

namespace antlr4 {

  class ANTLR4CPP_PUBLIC Recognizer {
  public:
    static const size_t EOF = static_cast<size_t>(-1); // std::numeric_limits<size_t>::max(); doesn't work in VS 2013.

    Recognizer();
    Recognizer(Recognizer const&) = delete;
    virtual ~Recognizer();

    Recognizer& operator=(Recognizer const&) = delete;

    /** Used to print out token names like ID during debugging and
     *  error reporting.  The generated parsers implement a method
     *  that overrides this to point to their String[] tokenNames.
     *
     * @deprecated Use {@link #getVocabulary()} instead.
     */
    virtual std::vector<std::string> const& getTokenNames() const = 0;
    virtual std::vector<std::string> const& getRuleNames() const = 0;

    /**
     * Get the vocabulary used by the recognizer.
     *
     * @return A {@link Vocabulary} instance providing information about the
     * vocabulary used by the grammar.
     */
    virtual dfa::Vocabulary const& getVocabulary() const;

    /// <summary>
    /// Get a map from token names to token types.
    /// <p/>
    /// Used for XPath and tree pattern compilation.
    /// </summary>
    virtual std::map<std::string, size_t> getTokenTypeMap();

    /// <summary>
    /// Get a map from rule names to rule indexes.
    /// <p/>
    /// Used for XPath and tree pattern compilation.
    /// </summary>
    virtual std::map<std::string, size_t> getRuleIndexMap();

    virtual size_t getTokenType(const std::string &tokenName);

    /// <summary>
    /// If this recognizer was generated, it will have a serialized ATN
    /// representation of the grammar.
    /// <p/>
    /// For interpreters, we don't know their serialized ATN despite having
    /// created the interpreter from it.
    /// </summary>
    virtual const std::vector<uint16_t> getSerializedATN() const {
      throw "there is no serialized ATN";
    }

    /// <summary>
    /// For debugging and other purposes, might want the grammar name.
    ///  Have ANTLR generate an implementation for this method.
    /// </summary>
    virtual std::string getGrammarFileName() const = 0;

    /// Get the ATN interpreter (in fact one of it's descendants) used by the recognizer for prediction.
    /// @returns The ATN interpreter used by the recognizer for prediction.
    template <class T>
    T* getInterpreter() const {
      return dynamic_cast<T *>(_interpreter);
    }

    /**
     * Set the ATN interpreter used by the recognizer for prediction.
     *
     * @param interpreter The ATN interpreter used by the recognizer for
     * prediction.
     */
    void setInterpreter(atn::ATNSimulator *interpreter);

    /// What is the error header, normally line/character position information?
    virtual std::string getErrorHeader(RecognitionException *e);

    /** How should a token be displayed in an error message? The default
     *  is to display just the text, but during development you might
     *  want to have a lot of information spit out.  Override in that case
     *  to use t.toString() (which, for CommonToken, dumps everything about
     *  the token). This is better than forcing you to override a method in
     *  your token objects because you don't have to go modify your lexer
     *  so that it creates a new Java type.
     *
     * @deprecated This method is not called by the ANTLR 4 Runtime. Specific
     * implementations of {@link ANTLRErrorStrategy} may provide a similar
     * feature when necessary. For example, see
     * {@link DefaultErrorStrategy#getTokenErrorDisplay}.
     */
    virtual std::string getTokenErrorDisplay(Token *t);

    /// <exception cref="NullPointerException"> if {@code listener} is {@code null}. </exception>
    virtual void addErrorListener(ANTLRErrorListener *listener);

    virtual void removeErrorListener(ANTLRErrorListener *listener);

    virtual void removeErrorListeners();

    virtual ProxyErrorListener& getErrorListenerDispatch();

    // subclass needs to override these if there are sempreds or actions
    // that the ATN interp needs to execute
    virtual bool sempred(RuleContext *localctx, size_t ruleIndex, size_t actionIndex);

    virtual bool precpred(RuleContext *localctx, int precedence);

    virtual void action(RuleContext *localctx, size_t ruleIndex, size_t actionIndex);

    virtual size_t getState() const ;

    // Get the ATN used by the recognizer for prediction.
    virtual const atn::ATN& getATN() const = 0;

    /// <summary>
    /// Indicate that the recognizer has changed internal state that is
    ///  consistent with the ATN state passed in.  This way we always know
    ///  where we are in the ATN as the parser goes along. The rule
    ///  context objects form a stack that lets us see the stack of
    ///  invoking rules. Combine this and we have complete ATN
    ///  configuration information.
    /// </summary>
    void setState(size_t atnState);

    virtual IntStream* getInputStream() = 0;

    virtual void setInputStream(IntStream *input) = 0;

    virtual Ref<TokenFactory<CommonToken>> getTokenFactory() = 0;

    template<typename T1>
    void setTokenFactory(TokenFactory<T1> *input);

  protected:
    atn::ATNSimulator *_interpreter; // Set and deleted in descendants (or the profiler).

    // Mutex to manage synchronized access for multithreading.
    std::mutex _mutex;

  private:
    static std::map<const dfa::Vocabulary*, std::map<std::string, size_t>> _tokenTypeMapCache;
    static std::map<std::vector<std::string>, std::map<std::string, size_t>> _ruleIndexMapCache;

    ProxyErrorListener _proxListener; // Manages a collection of listeners.

    size_t _stateNumber;

    void InitializeInstanceFields();

  };

} // namespace antlr4

/* Copyright (c) 2012-2017 The ANTLR Project. All rights reserved.
 * Use of this file is governed by the BSD 3-clause license that
 * can be found in the LICENSE.txt file in the project root.
 */

#include "ConsoleErrorListener.h"
#include "RecognitionException.h"
#include "support/CPPUtils.h"
#include "support/StringUtils.h"
#include "Token.h"
#include "atn/ATN.h"
#include "atn/ATNSimulator.h"
#include "support/CPPUtils.h"

#include "Vocabulary.h"



using namespace antlr4;
using namespace antlr4::atn;

std::map<const dfa::Vocabulary*, std::map<std::string, size_t>> Recognizer::_tokenTypeMapCache;
std::map<std::vector<std::string>, std::map<std::string, size_t>> Recognizer::_ruleIndexMapCache;

Recognizer::Recognizer() {
  InitializeInstanceFields();
  _proxListener.addErrorListener(&ConsoleErrorListener::INSTANCE);
}

Recognizer::~Recognizer() {
}

dfa::Vocabulary const& Recognizer::getVocabulary() const {
  static dfa::Vocabulary vocabulary = dfa::Vocabulary::fromTokenNames(getTokenNames());
  return vocabulary;
}

std::map<std::string, size_t> Recognizer::getTokenTypeMap() {
  const dfa::Vocabulary& vocabulary = getVocabulary();

  std::lock_guard<std::mutex> lck(_mutex);
  std::map<std::string, size_t> result;
  auto iterator = _tokenTypeMapCache.find(&vocabulary);
  if (iterator != _tokenTypeMapCache.end()) {
    result = iterator->second;
  } else {
    for (size_t i = 0; i <= getATN().maxTokenType; ++i) {
      std::string literalName = vocabulary.getLiteralName(i);
      if (!literalName.empty()) {
        result[literalName] = i;
      }

      std::string symbolicName = vocabulary.getSymbolicName(i);
      if (!symbolicName.empty()) {
        result[symbolicName] = i;
      }
				}
    result["EOF"] = EOF;
    _tokenTypeMapCache[&vocabulary] = result;
  }

  return result;
}

std::map<std::string, size_t> Recognizer::getRuleIndexMap() {
  const std::vector<std::string>& ruleNames = getRuleNames();
  if (ruleNames.empty()) {
    throw "The current recognizer does not provide a list of rule names.";
  }

  std::lock_guard<std::mutex> lck(_mutex);
  std::map<std::string, size_t> result;
  auto iterator = _ruleIndexMapCache.find(ruleNames);
  if (iterator != _ruleIndexMapCache.end()) {
    result = iterator->second;
  } else {
    result = antlrcpp::toMap(ruleNames);
    _ruleIndexMapCache[ruleNames] = result;
  }
  return result;
}

size_t Recognizer::getTokenType(const std::string &tokenName) {
  const std::map<std::string, size_t> &map = getTokenTypeMap();
  auto iterator = map.find(tokenName);
  if (iterator == map.end())
    return Token::INVALID_TYPE;

  return iterator->second;
}

void Recognizer::setInterpreter(atn::ATNSimulator *interpreter) {
  // Usually the interpreter is set by the descendant (lexer or parser (simulator), but can also be exchanged
  // by the profiling ATN simulator.
  delete _interpreter;
  _interpreter = interpreter;
}

std::string Recognizer::getErrorHeader(RecognitionException *e) {
  // We're having issues with cross header dependencies, these two classes will need to be
  // rewritten to remove that.
  size_t line = e->getOffendingToken()->getLine();
  size_t charPositionInLine = e->getOffendingToken()->getCharPositionInLine();
  return std::string("line ") + std::to_string(line) + ":" + std::to_string(charPositionInLine);

}

std::string Recognizer::getTokenErrorDisplay(Token *t) {
  if (t == nullptr) {
    return "<no Token>";
  }
  std::string s = t->getText();
  if (s == "") {
    if (t->getType() == EOF) {
      s = "<EOF>";
    } else {
      s = std::string("<") + std::to_string(t->getType()) + std::string(">");
    }
  }

  antlrcpp::replaceAll(s, "\n", "\\n");
  antlrcpp::replaceAll(s, "\r","\\r");
  antlrcpp::replaceAll(s, "\t", "\\t");

  return "'" + s + "'";
}

void Recognizer::addErrorListener(ANTLRErrorListener *listener) {
  _proxListener.addErrorListener(listener);
}

void Recognizer::removeErrorListener(ANTLRErrorListener *listener) {
  _proxListener.removeErrorListener(listener);
}

void Recognizer::removeErrorListeners() {
  _proxListener.removeErrorListeners();
}

ProxyErrorListener& Recognizer::getErrorListenerDispatch() {
  return _proxListener;
}

bool Recognizer::sempred(RuleContext * /*localctx*/, size_t /*ruleIndex*/, size_t /*actionIndex*/) {
  return true;
}

bool Recognizer::precpred(RuleContext * /*localctx*/, int /*precedence*/) {
  return true;
}

void Recognizer::action(RuleContext * /*localctx*/, size_t /*ruleIndex*/, size_t /*actionIndex*/) {
}

size_t Recognizer::getState() const {
  return _stateNumber;
}

void Recognizer::setState(size_t atnState) {
  _stateNumber = atnState;
}

void Recognizer::InitializeInstanceFields() {
  _stateNumber = ATNState::INVALID_STATE_NUMBER;
  _interpreter = nullptr;
}

