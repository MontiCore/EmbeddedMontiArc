#include "SyntaxError.h"

using common::SyntaxError;
using common::Position;
using std::string;

SyntaxError::SyntaxError(Position* position, string message) : AnalyzeItem(position, "error", message) {}