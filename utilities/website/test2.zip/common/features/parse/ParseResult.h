#pragma once
#ifndef COMMON_PARSE_RESULT_H
#define COMMON_PARSE_RESULT_H

#include "common/features/analyze/AnalyzeListener.h"
#include "common/features/outline/OutlineListener.h"

namespace common {
    class ParseResult {
        private:
            AnalyzeListener* analyzeListener;
            OutlineListener* outlineListener;

        public:
            ParseResult(AnalyzeListener* analyzeListener, OutlineListener* outlineListener);
            ~ParseResult();
            AnalyzeListener* getAnalyzeListener();
            OutlineListener* getOutlineListener();
    };
}

#endif