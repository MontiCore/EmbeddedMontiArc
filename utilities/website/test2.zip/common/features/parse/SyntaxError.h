#pragma once
#ifndef COMMON_SYNTAX_ERROR_H
#define COMMON_SYNTAX_ERROR_H

#include <iostream>

#include "common/features/shared/Position.h"
#include "common/features/analyze/AnalyzeItem.h"

using std::string;

namespace common {
    class SyntaxError : public AnalyzeItem {
        public:
            SyntaxError(Position* position, string message);
    };
}

#endif