#pragma once
#ifndef COMMON_OUTLINE_ITEM_H
#define COMMON_OUTLINE_ITEM_H

#include "common/features/shared/Position.h"

using std::list;
using std::string;

namespace common {
    class OutlineItem {
        protected:
            string icon;
            string name;
            Position* position;
            Position* displayPosition;
            list<OutlineItem*> items;
            bool unordered;

        public:
            OutlineItem();
            OutlineItem(string icon, string name, Position* position, Position* displayPosition, list<OutlineItem*> items, bool unordered);
            virtual ~OutlineItem();
            
            virtual string getIcon() const;
            virtual string getName() const;
            
            virtual Position* getPosition() const;
            void setPosition(Position*);
            virtual Position* getDisplayPosition() const;
            void setDisplayPosition(Position*);

            virtual list<OutlineItem*> getItems() const;
            virtual void addItem(OutlineItem* item);
            
            virtual bool isUnordered() const;
            
            virtual val toJSON() const;
            virtual string toString() const;
    };
}

#endif