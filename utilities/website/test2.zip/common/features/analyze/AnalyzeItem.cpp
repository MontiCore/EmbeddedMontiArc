#include "AnalyzeItem.h"

using common::AnalyzeItem;
using common::Position;
using std::string;
using std::stringstream;
using emscripten::val;

AnalyzeItem::AnalyzeItem(Position* position, string type, string message) {
    this->position = position;
    this->type = type;
    this->message = message;
}

AnalyzeItem::~AnalyzeItem() {
    delete this->position;
}

Position* AnalyzeItem::getPosition() const {
    return this->position;
}

string AnalyzeItem::getType() const {
    return this->type;
}

string AnalyzeItem::getMessage() const {
    return this->message;
}

val AnalyzeItem::toJSON() const {
    val item = val::object();
    val position = this->getPosition()->toJSON();

    string type = this->getType();
    string message = this->getMessage();

    item.set("pos", position);
    item.set("type", val(type));
    item.set("message", val(message));

    return item;
}

string AnalyzeItem::toString() const {
    stringstream stream;

    stream << "{";
    stream << "pos:" + this->getPosition()->toString();
    stream << ",";
    stream << "type:" + this->getType();
    stream << ",";
    stream << "message:" + this->getMessage();
    stream << "}";

    return stream.str();
}