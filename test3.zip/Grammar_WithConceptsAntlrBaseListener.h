
// Generated from Grammar_WithConceptsAntlr.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"
#include "Grammar_WithConceptsAntlrListener.h"


/**
 * This class provides an empty implementation of Grammar_WithConceptsAntlrListener,
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
class  Grammar_WithConceptsAntlrBaseListener : public Grammar_WithConceptsAntlrListener {
public:

  virtual void enterConceptAntlr_eof(Grammar_WithConceptsAntlrParser::ConceptAntlr_eofContext * /*ctx*/) override { }
  virtual void exitConceptAntlr_eof(Grammar_WithConceptsAntlrParser::ConceptAntlr_eofContext * /*ctx*/) override { }

  virtual void enterConceptAntlr(Grammar_WithConceptsAntlrParser::ConceptAntlrContext * /*ctx*/) override { }
  virtual void exitConceptAntlr(Grammar_WithConceptsAntlrParser::ConceptAntlrContext * /*ctx*/) override { }

  virtual void enterAntlrParserAction_eof(Grammar_WithConceptsAntlrParser::AntlrParserAction_eofContext * /*ctx*/) override { }
  virtual void exitAntlrParserAction_eof(Grammar_WithConceptsAntlrParser::AntlrParserAction_eofContext * /*ctx*/) override { }

  virtual void enterAntlrParserAction(Grammar_WithConceptsAntlrParser::AntlrParserActionContext * /*ctx*/) override { }
  virtual void exitAntlrParserAction(Grammar_WithConceptsAntlrParser::AntlrParserActionContext * /*ctx*/) override { }

  virtual void enterAntlrLexerAction_eof(Grammar_WithConceptsAntlrParser::AntlrLexerAction_eofContext * /*ctx*/) override { }
  virtual void exitAntlrLexerAction_eof(Grammar_WithConceptsAntlrParser::AntlrLexerAction_eofContext * /*ctx*/) override { }

  virtual void enterAntlrLexerAction(Grammar_WithConceptsAntlrParser::AntlrLexerActionContext * /*ctx*/) override { }
  virtual void exitAntlrLexerAction(Grammar_WithConceptsAntlrParser::AntlrLexerActionContext * /*ctx*/) override { }

  virtual void enterJavaCode_eof(Grammar_WithConceptsAntlrParser::JavaCode_eofContext * /*ctx*/) override { }
  virtual void exitJavaCode_eof(Grammar_WithConceptsAntlrParser::JavaCode_eofContext * /*ctx*/) override { }

  virtual void enterJavaCode(Grammar_WithConceptsAntlrParser::JavaCodeContext * /*ctx*/) override { }
  virtual void exitJavaCode(Grammar_WithConceptsAntlrParser::JavaCodeContext * /*ctx*/) override { }

  virtual void enterNullLiteral_eof(Grammar_WithConceptsAntlrParser::NullLiteral_eofContext * /*ctx*/) override { }
  virtual void exitNullLiteral_eof(Grammar_WithConceptsAntlrParser::NullLiteral_eofContext * /*ctx*/) override { }

  virtual void enterNullLiteral(Grammar_WithConceptsAntlrParser::NullLiteralContext * /*ctx*/) override { }
  virtual void exitNullLiteral(Grammar_WithConceptsAntlrParser::NullLiteralContext * /*ctx*/) override { }

  virtual void enterBooleanLiteral_eof(Grammar_WithConceptsAntlrParser::BooleanLiteral_eofContext * /*ctx*/) override { }
  virtual void exitBooleanLiteral_eof(Grammar_WithConceptsAntlrParser::BooleanLiteral_eofContext * /*ctx*/) override { }

  virtual void enterBooleanLiteral(Grammar_WithConceptsAntlrParser::BooleanLiteralContext * /*ctx*/) override { }
  virtual void exitBooleanLiteral(Grammar_WithConceptsAntlrParser::BooleanLiteralContext * /*ctx*/) override { }

  virtual void enterCharLiteral_eof(Grammar_WithConceptsAntlrParser::CharLiteral_eofContext * /*ctx*/) override { }
  virtual void exitCharLiteral_eof(Grammar_WithConceptsAntlrParser::CharLiteral_eofContext * /*ctx*/) override { }

  virtual void enterCharLiteral(Grammar_WithConceptsAntlrParser::CharLiteralContext * /*ctx*/) override { }
  virtual void exitCharLiteral(Grammar_WithConceptsAntlrParser::CharLiteralContext * /*ctx*/) override { }

  virtual void enterStringLiteral_eof(Grammar_WithConceptsAntlrParser::StringLiteral_eofContext * /*ctx*/) override { }
  virtual void exitStringLiteral_eof(Grammar_WithConceptsAntlrParser::StringLiteral_eofContext * /*ctx*/) override { }

  virtual void enterStringLiteral(Grammar_WithConceptsAntlrParser::StringLiteralContext * /*ctx*/) override { }
  virtual void exitStringLiteral(Grammar_WithConceptsAntlrParser::StringLiteralContext * /*ctx*/) override { }

  virtual void enterIntLiteral_eof(Grammar_WithConceptsAntlrParser::IntLiteral_eofContext * /*ctx*/) override { }
  virtual void exitIntLiteral_eof(Grammar_WithConceptsAntlrParser::IntLiteral_eofContext * /*ctx*/) override { }

  virtual void enterIntLiteral(Grammar_WithConceptsAntlrParser::IntLiteralContext * /*ctx*/) override { }
  virtual void exitIntLiteral(Grammar_WithConceptsAntlrParser::IntLiteralContext * /*ctx*/) override { }

  virtual void enterSignedIntLiteral_eof(Grammar_WithConceptsAntlrParser::SignedIntLiteral_eofContext * /*ctx*/) override { }
  virtual void exitSignedIntLiteral_eof(Grammar_WithConceptsAntlrParser::SignedIntLiteral_eofContext * /*ctx*/) override { }

  virtual void enterSignedIntLiteral(Grammar_WithConceptsAntlrParser::SignedIntLiteralContext * /*ctx*/) override { }
  virtual void exitSignedIntLiteral(Grammar_WithConceptsAntlrParser::SignedIntLiteralContext * /*ctx*/) override { }

  virtual void enterLongLiteral_eof(Grammar_WithConceptsAntlrParser::LongLiteral_eofContext * /*ctx*/) override { }
  virtual void exitLongLiteral_eof(Grammar_WithConceptsAntlrParser::LongLiteral_eofContext * /*ctx*/) override { }

  virtual void enterLongLiteral(Grammar_WithConceptsAntlrParser::LongLiteralContext * /*ctx*/) override { }
  virtual void exitLongLiteral(Grammar_WithConceptsAntlrParser::LongLiteralContext * /*ctx*/) override { }

  virtual void enterSignedLongLiteral_eof(Grammar_WithConceptsAntlrParser::SignedLongLiteral_eofContext * /*ctx*/) override { }
  virtual void exitSignedLongLiteral_eof(Grammar_WithConceptsAntlrParser::SignedLongLiteral_eofContext * /*ctx*/) override { }

  virtual void enterSignedLongLiteral(Grammar_WithConceptsAntlrParser::SignedLongLiteralContext * /*ctx*/) override { }
  virtual void exitSignedLongLiteral(Grammar_WithConceptsAntlrParser::SignedLongLiteralContext * /*ctx*/) override { }

  virtual void enterFloatLiteral_eof(Grammar_WithConceptsAntlrParser::FloatLiteral_eofContext * /*ctx*/) override { }
  virtual void exitFloatLiteral_eof(Grammar_WithConceptsAntlrParser::FloatLiteral_eofContext * /*ctx*/) override { }

  virtual void enterFloatLiteral(Grammar_WithConceptsAntlrParser::FloatLiteralContext * /*ctx*/) override { }
  virtual void exitFloatLiteral(Grammar_WithConceptsAntlrParser::FloatLiteralContext * /*ctx*/) override { }

  virtual void enterSignedFloatLiteral_eof(Grammar_WithConceptsAntlrParser::SignedFloatLiteral_eofContext * /*ctx*/) override { }
  virtual void exitSignedFloatLiteral_eof(Grammar_WithConceptsAntlrParser::SignedFloatLiteral_eofContext * /*ctx*/) override { }

  virtual void enterSignedFloatLiteral(Grammar_WithConceptsAntlrParser::SignedFloatLiteralContext * /*ctx*/) override { }
  virtual void exitSignedFloatLiteral(Grammar_WithConceptsAntlrParser::SignedFloatLiteralContext * /*ctx*/) override { }

  virtual void enterDoubleLiteral_eof(Grammar_WithConceptsAntlrParser::DoubleLiteral_eofContext * /*ctx*/) override { }
  virtual void exitDoubleLiteral_eof(Grammar_WithConceptsAntlrParser::DoubleLiteral_eofContext * /*ctx*/) override { }

  virtual void enterDoubleLiteral(Grammar_WithConceptsAntlrParser::DoubleLiteralContext * /*ctx*/) override { }
  virtual void exitDoubleLiteral(Grammar_WithConceptsAntlrParser::DoubleLiteralContext * /*ctx*/) override { }

  virtual void enterSignedDoubleLiteral_eof(Grammar_WithConceptsAntlrParser::SignedDoubleLiteral_eofContext * /*ctx*/) override { }
  virtual void exitSignedDoubleLiteral_eof(Grammar_WithConceptsAntlrParser::SignedDoubleLiteral_eofContext * /*ctx*/) override { }

  virtual void enterSignedDoubleLiteral(Grammar_WithConceptsAntlrParser::SignedDoubleLiteralContext * /*ctx*/) override { }
  virtual void exitSignedDoubleLiteral(Grammar_WithConceptsAntlrParser::SignedDoubleLiteralContext * /*ctx*/) override { }

  virtual void enterQualifiedName_eof(Grammar_WithConceptsAntlrParser::QualifiedName_eofContext * /*ctx*/) override { }
  virtual void exitQualifiedName_eof(Grammar_WithConceptsAntlrParser::QualifiedName_eofContext * /*ctx*/) override { }

  virtual void enterQualifiedName(Grammar_WithConceptsAntlrParser::QualifiedNameContext * /*ctx*/) override { }
  virtual void exitQualifiedName(Grammar_WithConceptsAntlrParser::QualifiedNameContext * /*ctx*/) override { }

  virtual void enterComplexArrayType_eof(Grammar_WithConceptsAntlrParser::ComplexArrayType_eofContext * /*ctx*/) override { }
  virtual void exitComplexArrayType_eof(Grammar_WithConceptsAntlrParser::ComplexArrayType_eofContext * /*ctx*/) override { }

  virtual void enterComplexArrayType(Grammar_WithConceptsAntlrParser::ComplexArrayTypeContext * /*ctx*/) override { }
  virtual void exitComplexArrayType(Grammar_WithConceptsAntlrParser::ComplexArrayTypeContext * /*ctx*/) override { }

  virtual void enterPrimitiveArrayType_eof(Grammar_WithConceptsAntlrParser::PrimitiveArrayType_eofContext * /*ctx*/) override { }
  virtual void exitPrimitiveArrayType_eof(Grammar_WithConceptsAntlrParser::PrimitiveArrayType_eofContext * /*ctx*/) override { }

  virtual void enterPrimitiveArrayType(Grammar_WithConceptsAntlrParser::PrimitiveArrayTypeContext * /*ctx*/) override { }
  virtual void exitPrimitiveArrayType(Grammar_WithConceptsAntlrParser::PrimitiveArrayTypeContext * /*ctx*/) override { }

  virtual void enterVoidType_eof(Grammar_WithConceptsAntlrParser::VoidType_eofContext * /*ctx*/) override { }
  virtual void exitVoidType_eof(Grammar_WithConceptsAntlrParser::VoidType_eofContext * /*ctx*/) override { }

  virtual void enterVoidType(Grammar_WithConceptsAntlrParser::VoidTypeContext * /*ctx*/) override { }
  virtual void exitVoidType(Grammar_WithConceptsAntlrParser::VoidTypeContext * /*ctx*/) override { }

  virtual void enterPrimitiveType_eof(Grammar_WithConceptsAntlrParser::PrimitiveType_eofContext * /*ctx*/) override { }
  virtual void exitPrimitiveType_eof(Grammar_WithConceptsAntlrParser::PrimitiveType_eofContext * /*ctx*/) override { }

  virtual void enterPrimitiveType(Grammar_WithConceptsAntlrParser::PrimitiveTypeContext * /*ctx*/) override { }
  virtual void exitPrimitiveType(Grammar_WithConceptsAntlrParser::PrimitiveTypeContext * /*ctx*/) override { }

  virtual void enterSimpleReferenceType_eof(Grammar_WithConceptsAntlrParser::SimpleReferenceType_eofContext * /*ctx*/) override { }
  virtual void exitSimpleReferenceType_eof(Grammar_WithConceptsAntlrParser::SimpleReferenceType_eofContext * /*ctx*/) override { }

  virtual void enterSimpleReferenceType(Grammar_WithConceptsAntlrParser::SimpleReferenceTypeContext * /*ctx*/) override { }
  virtual void exitSimpleReferenceType(Grammar_WithConceptsAntlrParser::SimpleReferenceTypeContext * /*ctx*/) override { }

  virtual void enterComplexReferenceType_eof(Grammar_WithConceptsAntlrParser::ComplexReferenceType_eofContext * /*ctx*/) override { }
  virtual void exitComplexReferenceType_eof(Grammar_WithConceptsAntlrParser::ComplexReferenceType_eofContext * /*ctx*/) override { }

  virtual void enterComplexReferenceType(Grammar_WithConceptsAntlrParser::ComplexReferenceTypeContext * /*ctx*/) override { }
  virtual void exitComplexReferenceType(Grammar_WithConceptsAntlrParser::ComplexReferenceTypeContext * /*ctx*/) override { }

  virtual void enterTypeArguments_eof(Grammar_WithConceptsAntlrParser::TypeArguments_eofContext * /*ctx*/) override { }
  virtual void exitTypeArguments_eof(Grammar_WithConceptsAntlrParser::TypeArguments_eofContext * /*ctx*/) override { }

  virtual void enterTypeArguments(Grammar_WithConceptsAntlrParser::TypeArgumentsContext * /*ctx*/) override { }
  virtual void exitTypeArguments(Grammar_WithConceptsAntlrParser::TypeArgumentsContext * /*ctx*/) override { }

  virtual void enterWildcardType_eof(Grammar_WithConceptsAntlrParser::WildcardType_eofContext * /*ctx*/) override { }
  virtual void exitWildcardType_eof(Grammar_WithConceptsAntlrParser::WildcardType_eofContext * /*ctx*/) override { }

  virtual void enterWildcardType(Grammar_WithConceptsAntlrParser::WildcardTypeContext * /*ctx*/) override { }
  virtual void exitWildcardType(Grammar_WithConceptsAntlrParser::WildcardTypeContext * /*ctx*/) override { }

  virtual void enterTypeParameters_eof(Grammar_WithConceptsAntlrParser::TypeParameters_eofContext * /*ctx*/) override { }
  virtual void exitTypeParameters_eof(Grammar_WithConceptsAntlrParser::TypeParameters_eofContext * /*ctx*/) override { }

  virtual void enterTypeParameters(Grammar_WithConceptsAntlrParser::TypeParametersContext * /*ctx*/) override { }
  virtual void exitTypeParameters(Grammar_WithConceptsAntlrParser::TypeParametersContext * /*ctx*/) override { }

  virtual void enterTypeVariableDeclaration_eof(Grammar_WithConceptsAntlrParser::TypeVariableDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitTypeVariableDeclaration_eof(Grammar_WithConceptsAntlrParser::TypeVariableDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterTypeVariableDeclaration(Grammar_WithConceptsAntlrParser::TypeVariableDeclarationContext * /*ctx*/) override { }
  virtual void exitTypeVariableDeclaration(Grammar_WithConceptsAntlrParser::TypeVariableDeclarationContext * /*ctx*/) override { }

  virtual void enterImportStatement_eof(Grammar_WithConceptsAntlrParser::ImportStatement_eofContext * /*ctx*/) override { }
  virtual void exitImportStatement_eof(Grammar_WithConceptsAntlrParser::ImportStatement_eofContext * /*ctx*/) override { }

  virtual void enterImportStatement(Grammar_WithConceptsAntlrParser::ImportStatementContext * /*ctx*/) override { }
  virtual void exitImportStatement(Grammar_WithConceptsAntlrParser::ImportStatementContext * /*ctx*/) override { }

  virtual void enterTypeCastExpression_eof(Grammar_WithConceptsAntlrParser::TypeCastExpression_eofContext * /*ctx*/) override { }
  virtual void exitTypeCastExpression_eof(Grammar_WithConceptsAntlrParser::TypeCastExpression_eofContext * /*ctx*/) override { }

  virtual void enterTypeCastExpression(Grammar_WithConceptsAntlrParser::TypeCastExpressionContext * /*ctx*/) override { }
  virtual void exitTypeCastExpression(Grammar_WithConceptsAntlrParser::TypeCastExpressionContext * /*ctx*/) override { }

  virtual void enterPrefixExpression_eof(Grammar_WithConceptsAntlrParser::PrefixExpression_eofContext * /*ctx*/) override { }
  virtual void exitPrefixExpression_eof(Grammar_WithConceptsAntlrParser::PrefixExpression_eofContext * /*ctx*/) override { }

  virtual void enterPrefixExpression(Grammar_WithConceptsAntlrParser::PrefixExpressionContext * /*ctx*/) override { }
  virtual void exitPrefixExpression(Grammar_WithConceptsAntlrParser::PrefixExpressionContext * /*ctx*/) override { }

  virtual void enterBooleanNotExpression_eof(Grammar_WithConceptsAntlrParser::BooleanNotExpression_eofContext * /*ctx*/) override { }
  virtual void exitBooleanNotExpression_eof(Grammar_WithConceptsAntlrParser::BooleanNotExpression_eofContext * /*ctx*/) override { }

  virtual void enterBooleanNotExpression(Grammar_WithConceptsAntlrParser::BooleanNotExpressionContext * /*ctx*/) override { }
  virtual void exitBooleanNotExpression(Grammar_WithConceptsAntlrParser::BooleanNotExpressionContext * /*ctx*/) override { }

  virtual void enterLogicalNotExpression_eof(Grammar_WithConceptsAntlrParser::LogicalNotExpression_eofContext * /*ctx*/) override { }
  virtual void exitLogicalNotExpression_eof(Grammar_WithConceptsAntlrParser::LogicalNotExpression_eofContext * /*ctx*/) override { }

  virtual void enterLogicalNotExpression(Grammar_WithConceptsAntlrParser::LogicalNotExpressionContext * /*ctx*/) override { }
  virtual void exitLogicalNotExpression(Grammar_WithConceptsAntlrParser::LogicalNotExpressionContext * /*ctx*/) override { }

  virtual void enterBracketExpression_eof(Grammar_WithConceptsAntlrParser::BracketExpression_eofContext * /*ctx*/) override { }
  virtual void exitBracketExpression_eof(Grammar_WithConceptsAntlrParser::BracketExpression_eofContext * /*ctx*/) override { }

  virtual void enterBracketExpression(Grammar_WithConceptsAntlrParser::BracketExpressionContext * /*ctx*/) override { }
  virtual void exitBracketExpression(Grammar_WithConceptsAntlrParser::BracketExpressionContext * /*ctx*/) override { }

  virtual void enterPrimaryThisExpression_eof(Grammar_WithConceptsAntlrParser::PrimaryThisExpression_eofContext * /*ctx*/) override { }
  virtual void exitPrimaryThisExpression_eof(Grammar_WithConceptsAntlrParser::PrimaryThisExpression_eofContext * /*ctx*/) override { }

  virtual void enterPrimaryThisExpression(Grammar_WithConceptsAntlrParser::PrimaryThisExpressionContext * /*ctx*/) override { }
  virtual void exitPrimaryThisExpression(Grammar_WithConceptsAntlrParser::PrimaryThisExpressionContext * /*ctx*/) override { }

  virtual void enterPrimarySuperExpression_eof(Grammar_WithConceptsAntlrParser::PrimarySuperExpression_eofContext * /*ctx*/) override { }
  virtual void exitPrimarySuperExpression_eof(Grammar_WithConceptsAntlrParser::PrimarySuperExpression_eofContext * /*ctx*/) override { }

  virtual void enterPrimarySuperExpression(Grammar_WithConceptsAntlrParser::PrimarySuperExpressionContext * /*ctx*/) override { }
  virtual void exitPrimarySuperExpression(Grammar_WithConceptsAntlrParser::PrimarySuperExpressionContext * /*ctx*/) override { }

  virtual void enterLiteralExpression_eof(Grammar_WithConceptsAntlrParser::LiteralExpression_eofContext * /*ctx*/) override { }
  virtual void exitLiteralExpression_eof(Grammar_WithConceptsAntlrParser::LiteralExpression_eofContext * /*ctx*/) override { }

  virtual void enterLiteralExpression(Grammar_WithConceptsAntlrParser::LiteralExpressionContext * /*ctx*/) override { }
  virtual void exitLiteralExpression(Grammar_WithConceptsAntlrParser::LiteralExpressionContext * /*ctx*/) override { }

  virtual void enterNameExpression_eof(Grammar_WithConceptsAntlrParser::NameExpression_eofContext * /*ctx*/) override { }
  virtual void exitNameExpression_eof(Grammar_WithConceptsAntlrParser::NameExpression_eofContext * /*ctx*/) override { }

  virtual void enterNameExpression(Grammar_WithConceptsAntlrParser::NameExpressionContext * /*ctx*/) override { }
  virtual void exitNameExpression(Grammar_WithConceptsAntlrParser::NameExpressionContext * /*ctx*/) override { }

  virtual void enterClassExpression_eof(Grammar_WithConceptsAntlrParser::ClassExpression_eofContext * /*ctx*/) override { }
  virtual void exitClassExpression_eof(Grammar_WithConceptsAntlrParser::ClassExpression_eofContext * /*ctx*/) override { }

  virtual void enterClassExpression(Grammar_WithConceptsAntlrParser::ClassExpressionContext * /*ctx*/) override { }
  virtual void exitClassExpression(Grammar_WithConceptsAntlrParser::ClassExpressionContext * /*ctx*/) override { }

  virtual void enterPrimaryGenericInvocationExpression_eof(Grammar_WithConceptsAntlrParser::PrimaryGenericInvocationExpression_eofContext * /*ctx*/) override { }
  virtual void exitPrimaryGenericInvocationExpression_eof(Grammar_WithConceptsAntlrParser::PrimaryGenericInvocationExpression_eofContext * /*ctx*/) override { }

  virtual void enterPrimaryGenericInvocationExpression(Grammar_WithConceptsAntlrParser::PrimaryGenericInvocationExpressionContext * /*ctx*/) override { }
  virtual void exitPrimaryGenericInvocationExpression(Grammar_WithConceptsAntlrParser::PrimaryGenericInvocationExpressionContext * /*ctx*/) override { }

  virtual void enterGenericInvocationSuffix_eof(Grammar_WithConceptsAntlrParser::GenericInvocationSuffix_eofContext * /*ctx*/) override { }
  virtual void exitGenericInvocationSuffix_eof(Grammar_WithConceptsAntlrParser::GenericInvocationSuffix_eofContext * /*ctx*/) override { }

  virtual void enterGenericInvocationSuffix(Grammar_WithConceptsAntlrParser::GenericInvocationSuffixContext * /*ctx*/) override { }
  virtual void exitGenericInvocationSuffix(Grammar_WithConceptsAntlrParser::GenericInvocationSuffixContext * /*ctx*/) override { }

  virtual void enterSuperSuffix_eof(Grammar_WithConceptsAntlrParser::SuperSuffix_eofContext * /*ctx*/) override { }
  virtual void exitSuperSuffix_eof(Grammar_WithConceptsAntlrParser::SuperSuffix_eofContext * /*ctx*/) override { }

  virtual void enterSuperSuffix(Grammar_WithConceptsAntlrParser::SuperSuffixContext * /*ctx*/) override { }
  virtual void exitSuperSuffix(Grammar_WithConceptsAntlrParser::SuperSuffixContext * /*ctx*/) override { }

  virtual void enterArguments_eof(Grammar_WithConceptsAntlrParser::Arguments_eofContext * /*ctx*/) override { }
  virtual void exitArguments_eof(Grammar_WithConceptsAntlrParser::Arguments_eofContext * /*ctx*/) override { }

  virtual void enterArguments(Grammar_WithConceptsAntlrParser::ArgumentsContext * /*ctx*/) override { }
  virtual void exitArguments(Grammar_WithConceptsAntlrParser::ArgumentsContext * /*ctx*/) override { }

  virtual void enterCompilationUnit_eof(Grammar_WithConceptsAntlrParser::CompilationUnit_eofContext * /*ctx*/) override { }
  virtual void exitCompilationUnit_eof(Grammar_WithConceptsAntlrParser::CompilationUnit_eofContext * /*ctx*/) override { }

  virtual void enterCompilationUnit(Grammar_WithConceptsAntlrParser::CompilationUnitContext * /*ctx*/) override { }
  virtual void exitCompilationUnit(Grammar_WithConceptsAntlrParser::CompilationUnitContext * /*ctx*/) override { }

  virtual void enterPackageDeclaration_eof(Grammar_WithConceptsAntlrParser::PackageDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitPackageDeclaration_eof(Grammar_WithConceptsAntlrParser::PackageDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterPackageDeclaration(Grammar_WithConceptsAntlrParser::PackageDeclarationContext * /*ctx*/) override { }
  virtual void exitPackageDeclaration(Grammar_WithConceptsAntlrParser::PackageDeclarationContext * /*ctx*/) override { }

  virtual void enterImportDeclaration_eof(Grammar_WithConceptsAntlrParser::ImportDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitImportDeclaration_eof(Grammar_WithConceptsAntlrParser::ImportDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterImportDeclaration(Grammar_WithConceptsAntlrParser::ImportDeclarationContext * /*ctx*/) override { }
  virtual void exitImportDeclaration(Grammar_WithConceptsAntlrParser::ImportDeclarationContext * /*ctx*/) override { }

  virtual void enterPrimitiveModifier_eof(Grammar_WithConceptsAntlrParser::PrimitiveModifier_eofContext * /*ctx*/) override { }
  virtual void exitPrimitiveModifier_eof(Grammar_WithConceptsAntlrParser::PrimitiveModifier_eofContext * /*ctx*/) override { }

  virtual void enterPrimitiveModifier(Grammar_WithConceptsAntlrParser::PrimitiveModifierContext * /*ctx*/) override { }
  virtual void exitPrimitiveModifier(Grammar_WithConceptsAntlrParser::PrimitiveModifierContext * /*ctx*/) override { }

  virtual void enterEmptyDeclaration_eof(Grammar_WithConceptsAntlrParser::EmptyDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitEmptyDeclaration_eof(Grammar_WithConceptsAntlrParser::EmptyDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterEmptyDeclaration(Grammar_WithConceptsAntlrParser::EmptyDeclarationContext * /*ctx*/) override { }
  virtual void exitEmptyDeclaration(Grammar_WithConceptsAntlrParser::EmptyDeclarationContext * /*ctx*/) override { }

  virtual void enterClassDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitClassDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterClassDeclaration(Grammar_WithConceptsAntlrParser::ClassDeclarationContext * /*ctx*/) override { }
  virtual void exitClassDeclaration(Grammar_WithConceptsAntlrParser::ClassDeclarationContext * /*ctx*/) override { }

  virtual void enterClassBody_eof(Grammar_WithConceptsAntlrParser::ClassBody_eofContext * /*ctx*/) override { }
  virtual void exitClassBody_eof(Grammar_WithConceptsAntlrParser::ClassBody_eofContext * /*ctx*/) override { }

  virtual void enterClassBody(Grammar_WithConceptsAntlrParser::ClassBodyContext * /*ctx*/) override { }
  virtual void exitClassBody(Grammar_WithConceptsAntlrParser::ClassBodyContext * /*ctx*/) override { }

  virtual void enterInterfaceDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitInterfaceDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterInterfaceDeclaration(Grammar_WithConceptsAntlrParser::InterfaceDeclarationContext * /*ctx*/) override { }
  virtual void exitInterfaceDeclaration(Grammar_WithConceptsAntlrParser::InterfaceDeclarationContext * /*ctx*/) override { }

  virtual void enterInterfaceBody_eof(Grammar_WithConceptsAntlrParser::InterfaceBody_eofContext * /*ctx*/) override { }
  virtual void exitInterfaceBody_eof(Grammar_WithConceptsAntlrParser::InterfaceBody_eofContext * /*ctx*/) override { }

  virtual void enterInterfaceBody(Grammar_WithConceptsAntlrParser::InterfaceBodyContext * /*ctx*/) override { }
  virtual void exitInterfaceBody(Grammar_WithConceptsAntlrParser::InterfaceBodyContext * /*ctx*/) override { }

  virtual void enterEnumDeclaration_eof(Grammar_WithConceptsAntlrParser::EnumDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitEnumDeclaration_eof(Grammar_WithConceptsAntlrParser::EnumDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterEnumDeclaration(Grammar_WithConceptsAntlrParser::EnumDeclarationContext * /*ctx*/) override { }
  virtual void exitEnumDeclaration(Grammar_WithConceptsAntlrParser::EnumDeclarationContext * /*ctx*/) override { }

  virtual void enterEnumConstantDeclaration_eof(Grammar_WithConceptsAntlrParser::EnumConstantDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitEnumConstantDeclaration_eof(Grammar_WithConceptsAntlrParser::EnumConstantDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterEnumConstantDeclaration(Grammar_WithConceptsAntlrParser::EnumConstantDeclarationContext * /*ctx*/) override { }
  virtual void exitEnumConstantDeclaration(Grammar_WithConceptsAntlrParser::EnumConstantDeclarationContext * /*ctx*/) override { }

  virtual void enterEnumBody_eof(Grammar_WithConceptsAntlrParser::EnumBody_eofContext * /*ctx*/) override { }
  virtual void exitEnumBody_eof(Grammar_WithConceptsAntlrParser::EnumBody_eofContext * /*ctx*/) override { }

  virtual void enterEnumBody(Grammar_WithConceptsAntlrParser::EnumBodyContext * /*ctx*/) override { }
  virtual void exitEnumBody(Grammar_WithConceptsAntlrParser::EnumBodyContext * /*ctx*/) override { }

  virtual void enterClassBlock_eof(Grammar_WithConceptsAntlrParser::ClassBlock_eofContext * /*ctx*/) override { }
  virtual void exitClassBlock_eof(Grammar_WithConceptsAntlrParser::ClassBlock_eofContext * /*ctx*/) override { }

  virtual void enterClassBlock(Grammar_WithConceptsAntlrParser::ClassBlockContext * /*ctx*/) override { }
  virtual void exitClassBlock(Grammar_WithConceptsAntlrParser::ClassBlockContext * /*ctx*/) override { }

  virtual void enterMethodDeclaration_eof(Grammar_WithConceptsAntlrParser::MethodDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitMethodDeclaration_eof(Grammar_WithConceptsAntlrParser::MethodDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterMethodDeclaration(Grammar_WithConceptsAntlrParser::MethodDeclarationContext * /*ctx*/) override { }
  virtual void exitMethodDeclaration(Grammar_WithConceptsAntlrParser::MethodDeclarationContext * /*ctx*/) override { }

  virtual void enterConstructorDeclaration_eof(Grammar_WithConceptsAntlrParser::ConstructorDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitConstructorDeclaration_eof(Grammar_WithConceptsAntlrParser::ConstructorDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterConstructorDeclaration(Grammar_WithConceptsAntlrParser::ConstructorDeclarationContext * /*ctx*/) override { }
  virtual void exitConstructorDeclaration(Grammar_WithConceptsAntlrParser::ConstructorDeclarationContext * /*ctx*/) override { }

  virtual void enterFieldDeclaration_eof(Grammar_WithConceptsAntlrParser::FieldDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitFieldDeclaration_eof(Grammar_WithConceptsAntlrParser::FieldDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterFieldDeclaration(Grammar_WithConceptsAntlrParser::FieldDeclarationContext * /*ctx*/) override { }
  virtual void exitFieldDeclaration(Grammar_WithConceptsAntlrParser::FieldDeclarationContext * /*ctx*/) override { }

  virtual void enterConstDeclaration_eof(Grammar_WithConceptsAntlrParser::ConstDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitConstDeclaration_eof(Grammar_WithConceptsAntlrParser::ConstDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterConstDeclaration(Grammar_WithConceptsAntlrParser::ConstDeclarationContext * /*ctx*/) override { }
  virtual void exitConstDeclaration(Grammar_WithConceptsAntlrParser::ConstDeclarationContext * /*ctx*/) override { }

  virtual void enterConstantDeclarator_eof(Grammar_WithConceptsAntlrParser::ConstantDeclarator_eofContext * /*ctx*/) override { }
  virtual void exitConstantDeclarator_eof(Grammar_WithConceptsAntlrParser::ConstantDeclarator_eofContext * /*ctx*/) override { }

  virtual void enterConstantDeclarator(Grammar_WithConceptsAntlrParser::ConstantDeclaratorContext * /*ctx*/) override { }
  virtual void exitConstantDeclarator(Grammar_WithConceptsAntlrParser::ConstantDeclaratorContext * /*ctx*/) override { }

  virtual void enterInterfaceMethodDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceMethodDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitInterfaceMethodDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceMethodDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterInterfaceMethodDeclaration(Grammar_WithConceptsAntlrParser::InterfaceMethodDeclarationContext * /*ctx*/) override { }
  virtual void exitInterfaceMethodDeclaration(Grammar_WithConceptsAntlrParser::InterfaceMethodDeclarationContext * /*ctx*/) override { }

  virtual void enterMethodSignature_eof(Grammar_WithConceptsAntlrParser::MethodSignature_eofContext * /*ctx*/) override { }
  virtual void exitMethodSignature_eof(Grammar_WithConceptsAntlrParser::MethodSignature_eofContext * /*ctx*/) override { }

  virtual void enterMethodSignature(Grammar_WithConceptsAntlrParser::MethodSignatureContext * /*ctx*/) override { }
  virtual void exitMethodSignature(Grammar_WithConceptsAntlrParser::MethodSignatureContext * /*ctx*/) override { }

  virtual void enterR__throws_eof(Grammar_WithConceptsAntlrParser::R__throws_eofContext * /*ctx*/) override { }
  virtual void exitR__throws_eof(Grammar_WithConceptsAntlrParser::R__throws_eofContext * /*ctx*/) override { }

  virtual void enterR__throws(Grammar_WithConceptsAntlrParser::R__throwsContext * /*ctx*/) override { }
  virtual void exitR__throws(Grammar_WithConceptsAntlrParser::R__throwsContext * /*ctx*/) override { }

  virtual void enterVariableDeclarator_eof(Grammar_WithConceptsAntlrParser::VariableDeclarator_eofContext * /*ctx*/) override { }
  virtual void exitVariableDeclarator_eof(Grammar_WithConceptsAntlrParser::VariableDeclarator_eofContext * /*ctx*/) override { }

  virtual void enterVariableDeclarator(Grammar_WithConceptsAntlrParser::VariableDeclaratorContext * /*ctx*/) override { }
  virtual void exitVariableDeclarator(Grammar_WithConceptsAntlrParser::VariableDeclaratorContext * /*ctx*/) override { }

  virtual void enterDeclaratorId_eof(Grammar_WithConceptsAntlrParser::DeclaratorId_eofContext * /*ctx*/) override { }
  virtual void exitDeclaratorId_eof(Grammar_WithConceptsAntlrParser::DeclaratorId_eofContext * /*ctx*/) override { }

  virtual void enterDeclaratorId(Grammar_WithConceptsAntlrParser::DeclaratorIdContext * /*ctx*/) override { }
  virtual void exitDeclaratorId(Grammar_WithConceptsAntlrParser::DeclaratorIdContext * /*ctx*/) override { }

  virtual void enterVariableInititializerOrExpression_eof(Grammar_WithConceptsAntlrParser::VariableInititializerOrExpression_eofContext * /*ctx*/) override { }
  virtual void exitVariableInititializerOrExpression_eof(Grammar_WithConceptsAntlrParser::VariableInititializerOrExpression_eofContext * /*ctx*/) override { }

  virtual void enterVariableInititializerOrExpression(Grammar_WithConceptsAntlrParser::VariableInititializerOrExpressionContext * /*ctx*/) override { }
  virtual void exitVariableInititializerOrExpression(Grammar_WithConceptsAntlrParser::VariableInititializerOrExpressionContext * /*ctx*/) override { }

  virtual void enterArrayInitializer_eof(Grammar_WithConceptsAntlrParser::ArrayInitializer_eofContext * /*ctx*/) override { }
  virtual void exitArrayInitializer_eof(Grammar_WithConceptsAntlrParser::ArrayInitializer_eofContext * /*ctx*/) override { }

  virtual void enterArrayInitializer(Grammar_WithConceptsAntlrParser::ArrayInitializerContext * /*ctx*/) override { }
  virtual void exitArrayInitializer(Grammar_WithConceptsAntlrParser::ArrayInitializerContext * /*ctx*/) override { }

  virtual void enterFormalParameters_eof(Grammar_WithConceptsAntlrParser::FormalParameters_eofContext * /*ctx*/) override { }
  virtual void exitFormalParameters_eof(Grammar_WithConceptsAntlrParser::FormalParameters_eofContext * /*ctx*/) override { }

  virtual void enterFormalParameters(Grammar_WithConceptsAntlrParser::FormalParametersContext * /*ctx*/) override { }
  virtual void exitFormalParameters(Grammar_WithConceptsAntlrParser::FormalParametersContext * /*ctx*/) override { }

  virtual void enterFormalParameterListing_eof(Grammar_WithConceptsAntlrParser::FormalParameterListing_eofContext * /*ctx*/) override { }
  virtual void exitFormalParameterListing_eof(Grammar_WithConceptsAntlrParser::FormalParameterListing_eofContext * /*ctx*/) override { }

  virtual void enterFormalParameterListing(Grammar_WithConceptsAntlrParser::FormalParameterListingContext * /*ctx*/) override { }
  virtual void exitFormalParameterListing(Grammar_WithConceptsAntlrParser::FormalParameterListingContext * /*ctx*/) override { }

  virtual void enterFormalParameter_eof(Grammar_WithConceptsAntlrParser::FormalParameter_eofContext * /*ctx*/) override { }
  virtual void exitFormalParameter_eof(Grammar_WithConceptsAntlrParser::FormalParameter_eofContext * /*ctx*/) override { }

  virtual void enterFormalParameter(Grammar_WithConceptsAntlrParser::FormalParameterContext * /*ctx*/) override { }
  virtual void exitFormalParameter(Grammar_WithConceptsAntlrParser::FormalParameterContext * /*ctx*/) override { }

  virtual void enterLastFormalParameter_eof(Grammar_WithConceptsAntlrParser::LastFormalParameter_eofContext * /*ctx*/) override { }
  virtual void exitLastFormalParameter_eof(Grammar_WithConceptsAntlrParser::LastFormalParameter_eofContext * /*ctx*/) override { }

  virtual void enterLastFormalParameter(Grammar_WithConceptsAntlrParser::LastFormalParameterContext * /*ctx*/) override { }
  virtual void exitLastFormalParameter(Grammar_WithConceptsAntlrParser::LastFormalParameterContext * /*ctx*/) override { }

  virtual void enterAnnotation_eof(Grammar_WithConceptsAntlrParser::Annotation_eofContext * /*ctx*/) override { }
  virtual void exitAnnotation_eof(Grammar_WithConceptsAntlrParser::Annotation_eofContext * /*ctx*/) override { }

  virtual void enterAnnotation(Grammar_WithConceptsAntlrParser::AnnotationContext * /*ctx*/) override { }
  virtual void exitAnnotation(Grammar_WithConceptsAntlrParser::AnnotationContext * /*ctx*/) override { }

  virtual void enterAnnotationPairArguments_eof(Grammar_WithConceptsAntlrParser::AnnotationPairArguments_eofContext * /*ctx*/) override { }
  virtual void exitAnnotationPairArguments_eof(Grammar_WithConceptsAntlrParser::AnnotationPairArguments_eofContext * /*ctx*/) override { }

  virtual void enterAnnotationPairArguments(Grammar_WithConceptsAntlrParser::AnnotationPairArgumentsContext * /*ctx*/) override { }
  virtual void exitAnnotationPairArguments(Grammar_WithConceptsAntlrParser::AnnotationPairArgumentsContext * /*ctx*/) override { }

  virtual void enterElementValuePair_eof(Grammar_WithConceptsAntlrParser::ElementValuePair_eofContext * /*ctx*/) override { }
  virtual void exitElementValuePair_eof(Grammar_WithConceptsAntlrParser::ElementValuePair_eofContext * /*ctx*/) override { }

  virtual void enterElementValuePair(Grammar_WithConceptsAntlrParser::ElementValuePairContext * /*ctx*/) override { }
  virtual void exitElementValuePair(Grammar_WithConceptsAntlrParser::ElementValuePairContext * /*ctx*/) override { }

  virtual void enterElementValueOrExpr_eof(Grammar_WithConceptsAntlrParser::ElementValueOrExpr_eofContext * /*ctx*/) override { }
  virtual void exitElementValueOrExpr_eof(Grammar_WithConceptsAntlrParser::ElementValueOrExpr_eofContext * /*ctx*/) override { }

  virtual void enterElementValueOrExpr(Grammar_WithConceptsAntlrParser::ElementValueOrExprContext * /*ctx*/) override { }
  virtual void exitElementValueOrExpr(Grammar_WithConceptsAntlrParser::ElementValueOrExprContext * /*ctx*/) override { }

  virtual void enterElementValueArrayInitializer_eof(Grammar_WithConceptsAntlrParser::ElementValueArrayInitializer_eofContext * /*ctx*/) override { }
  virtual void exitElementValueArrayInitializer_eof(Grammar_WithConceptsAntlrParser::ElementValueArrayInitializer_eofContext * /*ctx*/) override { }

  virtual void enterElementValueArrayInitializer(Grammar_WithConceptsAntlrParser::ElementValueArrayInitializerContext * /*ctx*/) override { }
  virtual void exitElementValueArrayInitializer(Grammar_WithConceptsAntlrParser::ElementValueArrayInitializerContext * /*ctx*/) override { }

  virtual void enterAnnotationTypeDeclaration_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitAnnotationTypeDeclaration_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterAnnotationTypeDeclaration(Grammar_WithConceptsAntlrParser::AnnotationTypeDeclarationContext * /*ctx*/) override { }
  virtual void exitAnnotationTypeDeclaration(Grammar_WithConceptsAntlrParser::AnnotationTypeDeclarationContext * /*ctx*/) override { }

  virtual void enterAnnotationTypeBody_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeBody_eofContext * /*ctx*/) override { }
  virtual void exitAnnotationTypeBody_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeBody_eofContext * /*ctx*/) override { }

  virtual void enterAnnotationTypeBody(Grammar_WithConceptsAntlrParser::AnnotationTypeBodyContext * /*ctx*/) override { }
  virtual void exitAnnotationTypeBody(Grammar_WithConceptsAntlrParser::AnnotationTypeBodyContext * /*ctx*/) override { }

  virtual void enterAnnotationMethod_eof(Grammar_WithConceptsAntlrParser::AnnotationMethod_eofContext * /*ctx*/) override { }
  virtual void exitAnnotationMethod_eof(Grammar_WithConceptsAntlrParser::AnnotationMethod_eofContext * /*ctx*/) override { }

  virtual void enterAnnotationMethod(Grammar_WithConceptsAntlrParser::AnnotationMethodContext * /*ctx*/) override { }
  virtual void exitAnnotationMethod(Grammar_WithConceptsAntlrParser::AnnotationMethodContext * /*ctx*/) override { }

  virtual void enterAnnotationConstant_eof(Grammar_WithConceptsAntlrParser::AnnotationConstant_eofContext * /*ctx*/) override { }
  virtual void exitAnnotationConstant_eof(Grammar_WithConceptsAntlrParser::AnnotationConstant_eofContext * /*ctx*/) override { }

  virtual void enterAnnotationConstant(Grammar_WithConceptsAntlrParser::AnnotationConstantContext * /*ctx*/) override { }
  virtual void exitAnnotationConstant(Grammar_WithConceptsAntlrParser::AnnotationConstantContext * /*ctx*/) override { }

  virtual void enterDefaultValue_eof(Grammar_WithConceptsAntlrParser::DefaultValue_eofContext * /*ctx*/) override { }
  virtual void exitDefaultValue_eof(Grammar_WithConceptsAntlrParser::DefaultValue_eofContext * /*ctx*/) override { }

  virtual void enterDefaultValue(Grammar_WithConceptsAntlrParser::DefaultValueContext * /*ctx*/) override { }
  virtual void exitDefaultValue(Grammar_WithConceptsAntlrParser::DefaultValueContext * /*ctx*/) override { }

  virtual void enterLocalVariableDeclarationStatement_eof(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationStatement_eofContext * /*ctx*/) override { }
  virtual void exitLocalVariableDeclarationStatement_eof(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationStatement_eofContext * /*ctx*/) override { }

  virtual void enterLocalVariableDeclarationStatement(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationStatementContext * /*ctx*/) override { }
  virtual void exitLocalVariableDeclarationStatement(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationStatementContext * /*ctx*/) override { }

  virtual void enterLocalVariableDeclaration_eof(Grammar_WithConceptsAntlrParser::LocalVariableDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitLocalVariableDeclaration_eof(Grammar_WithConceptsAntlrParser::LocalVariableDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterLocalVariableDeclaration(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationContext * /*ctx*/) override { }
  virtual void exitLocalVariableDeclaration(Grammar_WithConceptsAntlrParser::LocalVariableDeclarationContext * /*ctx*/) override { }

  virtual void enterJavaBlock_eof(Grammar_WithConceptsAntlrParser::JavaBlock_eofContext * /*ctx*/) override { }
  virtual void exitJavaBlock_eof(Grammar_WithConceptsAntlrParser::JavaBlock_eofContext * /*ctx*/) override { }

  virtual void enterJavaBlock(Grammar_WithConceptsAntlrParser::JavaBlockContext * /*ctx*/) override { }
  virtual void exitJavaBlock(Grammar_WithConceptsAntlrParser::JavaBlockContext * /*ctx*/) override { }

  virtual void enterAssertStatement_eof(Grammar_WithConceptsAntlrParser::AssertStatement_eofContext * /*ctx*/) override { }
  virtual void exitAssertStatement_eof(Grammar_WithConceptsAntlrParser::AssertStatement_eofContext * /*ctx*/) override { }

  virtual void enterAssertStatement(Grammar_WithConceptsAntlrParser::AssertStatementContext * /*ctx*/) override { }
  virtual void exitAssertStatement(Grammar_WithConceptsAntlrParser::AssertStatementContext * /*ctx*/) override { }

  virtual void enterIfStatement_eof(Grammar_WithConceptsAntlrParser::IfStatement_eofContext * /*ctx*/) override { }
  virtual void exitIfStatement_eof(Grammar_WithConceptsAntlrParser::IfStatement_eofContext * /*ctx*/) override { }

  virtual void enterIfStatement(Grammar_WithConceptsAntlrParser::IfStatementContext * /*ctx*/) override { }
  virtual void exitIfStatement(Grammar_WithConceptsAntlrParser::IfStatementContext * /*ctx*/) override { }

  virtual void enterForStatement_eof(Grammar_WithConceptsAntlrParser::ForStatement_eofContext * /*ctx*/) override { }
  virtual void exitForStatement_eof(Grammar_WithConceptsAntlrParser::ForStatement_eofContext * /*ctx*/) override { }

  virtual void enterForStatement(Grammar_WithConceptsAntlrParser::ForStatementContext * /*ctx*/) override { }
  virtual void exitForStatement(Grammar_WithConceptsAntlrParser::ForStatementContext * /*ctx*/) override { }

  virtual void enterCommonForControl_eof(Grammar_WithConceptsAntlrParser::CommonForControl_eofContext * /*ctx*/) override { }
  virtual void exitCommonForControl_eof(Grammar_WithConceptsAntlrParser::CommonForControl_eofContext * /*ctx*/) override { }

  virtual void enterCommonForControl(Grammar_WithConceptsAntlrParser::CommonForControlContext * /*ctx*/) override { }
  virtual void exitCommonForControl(Grammar_WithConceptsAntlrParser::CommonForControlContext * /*ctx*/) override { }

  virtual void enterForInitByExpressions_eof(Grammar_WithConceptsAntlrParser::ForInitByExpressions_eofContext * /*ctx*/) override { }
  virtual void exitForInitByExpressions_eof(Grammar_WithConceptsAntlrParser::ForInitByExpressions_eofContext * /*ctx*/) override { }

  virtual void enterForInitByExpressions(Grammar_WithConceptsAntlrParser::ForInitByExpressionsContext * /*ctx*/) override { }
  virtual void exitForInitByExpressions(Grammar_WithConceptsAntlrParser::ForInitByExpressionsContext * /*ctx*/) override { }

  virtual void enterEnhancedForControl_eof(Grammar_WithConceptsAntlrParser::EnhancedForControl_eofContext * /*ctx*/) override { }
  virtual void exitEnhancedForControl_eof(Grammar_WithConceptsAntlrParser::EnhancedForControl_eofContext * /*ctx*/) override { }

  virtual void enterEnhancedForControl(Grammar_WithConceptsAntlrParser::EnhancedForControlContext * /*ctx*/) override { }
  virtual void exitEnhancedForControl(Grammar_WithConceptsAntlrParser::EnhancedForControlContext * /*ctx*/) override { }

  virtual void enterWhileStatement_eof(Grammar_WithConceptsAntlrParser::WhileStatement_eofContext * /*ctx*/) override { }
  virtual void exitWhileStatement_eof(Grammar_WithConceptsAntlrParser::WhileStatement_eofContext * /*ctx*/) override { }

  virtual void enterWhileStatement(Grammar_WithConceptsAntlrParser::WhileStatementContext * /*ctx*/) override { }
  virtual void exitWhileStatement(Grammar_WithConceptsAntlrParser::WhileStatementContext * /*ctx*/) override { }

  virtual void enterDoWhileStatement_eof(Grammar_WithConceptsAntlrParser::DoWhileStatement_eofContext * /*ctx*/) override { }
  virtual void exitDoWhileStatement_eof(Grammar_WithConceptsAntlrParser::DoWhileStatement_eofContext * /*ctx*/) override { }

  virtual void enterDoWhileStatement(Grammar_WithConceptsAntlrParser::DoWhileStatementContext * /*ctx*/) override { }
  virtual void exitDoWhileStatement(Grammar_WithConceptsAntlrParser::DoWhileStatementContext * /*ctx*/) override { }

  virtual void enterTryStatement_eof(Grammar_WithConceptsAntlrParser::TryStatement_eofContext * /*ctx*/) override { }
  virtual void exitTryStatement_eof(Grammar_WithConceptsAntlrParser::TryStatement_eofContext * /*ctx*/) override { }

  virtual void enterTryStatement(Grammar_WithConceptsAntlrParser::TryStatementContext * /*ctx*/) override { }
  virtual void exitTryStatement(Grammar_WithConceptsAntlrParser::TryStatementContext * /*ctx*/) override { }

  virtual void enterCatchExceptionsHandler_eof(Grammar_WithConceptsAntlrParser::CatchExceptionsHandler_eofContext * /*ctx*/) override { }
  virtual void exitCatchExceptionsHandler_eof(Grammar_WithConceptsAntlrParser::CatchExceptionsHandler_eofContext * /*ctx*/) override { }

  virtual void enterCatchExceptionsHandler(Grammar_WithConceptsAntlrParser::CatchExceptionsHandlerContext * /*ctx*/) override { }
  virtual void exitCatchExceptionsHandler(Grammar_WithConceptsAntlrParser::CatchExceptionsHandlerContext * /*ctx*/) override { }

  virtual void enterFinallyBlockOnlyHandler_eof(Grammar_WithConceptsAntlrParser::FinallyBlockOnlyHandler_eofContext * /*ctx*/) override { }
  virtual void exitFinallyBlockOnlyHandler_eof(Grammar_WithConceptsAntlrParser::FinallyBlockOnlyHandler_eofContext * /*ctx*/) override { }

  virtual void enterFinallyBlockOnlyHandler(Grammar_WithConceptsAntlrParser::FinallyBlockOnlyHandlerContext * /*ctx*/) override { }
  virtual void exitFinallyBlockOnlyHandler(Grammar_WithConceptsAntlrParser::FinallyBlockOnlyHandlerContext * /*ctx*/) override { }

  virtual void enterTryStatementWithResources_eof(Grammar_WithConceptsAntlrParser::TryStatementWithResources_eofContext * /*ctx*/) override { }
  virtual void exitTryStatementWithResources_eof(Grammar_WithConceptsAntlrParser::TryStatementWithResources_eofContext * /*ctx*/) override { }

  virtual void enterTryStatementWithResources(Grammar_WithConceptsAntlrParser::TryStatementWithResourcesContext * /*ctx*/) override { }
  virtual void exitTryStatementWithResources(Grammar_WithConceptsAntlrParser::TryStatementWithResourcesContext * /*ctx*/) override { }

  virtual void enterResource_eof(Grammar_WithConceptsAntlrParser::Resource_eofContext * /*ctx*/) override { }
  virtual void exitResource_eof(Grammar_WithConceptsAntlrParser::Resource_eofContext * /*ctx*/) override { }

  virtual void enterResource(Grammar_WithConceptsAntlrParser::ResourceContext * /*ctx*/) override { }
  virtual void exitResource(Grammar_WithConceptsAntlrParser::ResourceContext * /*ctx*/) override { }

  virtual void enterIdentifierAndTypeArgument_eof(Grammar_WithConceptsAntlrParser::IdentifierAndTypeArgument_eofContext * /*ctx*/) override { }
  virtual void exitIdentifierAndTypeArgument_eof(Grammar_WithConceptsAntlrParser::IdentifierAndTypeArgument_eofContext * /*ctx*/) override { }

  virtual void enterIdentifierAndTypeArgument(Grammar_WithConceptsAntlrParser::IdentifierAndTypeArgumentContext * /*ctx*/) override { }
  virtual void exitIdentifierAndTypeArgument(Grammar_WithConceptsAntlrParser::IdentifierAndTypeArgumentContext * /*ctx*/) override { }

  virtual void enterCatchClause_eof(Grammar_WithConceptsAntlrParser::CatchClause_eofContext * /*ctx*/) override { }
  virtual void exitCatchClause_eof(Grammar_WithConceptsAntlrParser::CatchClause_eofContext * /*ctx*/) override { }

  virtual void enterCatchClause(Grammar_WithConceptsAntlrParser::CatchClauseContext * /*ctx*/) override { }
  virtual void exitCatchClause(Grammar_WithConceptsAntlrParser::CatchClauseContext * /*ctx*/) override { }

  virtual void enterCatchType_eof(Grammar_WithConceptsAntlrParser::CatchType_eofContext * /*ctx*/) override { }
  virtual void exitCatchType_eof(Grammar_WithConceptsAntlrParser::CatchType_eofContext * /*ctx*/) override { }

  virtual void enterCatchType(Grammar_WithConceptsAntlrParser::CatchTypeContext * /*ctx*/) override { }
  virtual void exitCatchType(Grammar_WithConceptsAntlrParser::CatchTypeContext * /*ctx*/) override { }

  virtual void enterSwitchStatement_eof(Grammar_WithConceptsAntlrParser::SwitchStatement_eofContext * /*ctx*/) override { }
  virtual void exitSwitchStatement_eof(Grammar_WithConceptsAntlrParser::SwitchStatement_eofContext * /*ctx*/) override { }

  virtual void enterSwitchStatement(Grammar_WithConceptsAntlrParser::SwitchStatementContext * /*ctx*/) override { }
  virtual void exitSwitchStatement(Grammar_WithConceptsAntlrParser::SwitchStatementContext * /*ctx*/) override { }

  virtual void enterSynchronizedStatement_eof(Grammar_WithConceptsAntlrParser::SynchronizedStatement_eofContext * /*ctx*/) override { }
  virtual void exitSynchronizedStatement_eof(Grammar_WithConceptsAntlrParser::SynchronizedStatement_eofContext * /*ctx*/) override { }

  virtual void enterSynchronizedStatement(Grammar_WithConceptsAntlrParser::SynchronizedStatementContext * /*ctx*/) override { }
  virtual void exitSynchronizedStatement(Grammar_WithConceptsAntlrParser::SynchronizedStatementContext * /*ctx*/) override { }

  virtual void enterReturnStatement_eof(Grammar_WithConceptsAntlrParser::ReturnStatement_eofContext * /*ctx*/) override { }
  virtual void exitReturnStatement_eof(Grammar_WithConceptsAntlrParser::ReturnStatement_eofContext * /*ctx*/) override { }

  virtual void enterReturnStatement(Grammar_WithConceptsAntlrParser::ReturnStatementContext * /*ctx*/) override { }
  virtual void exitReturnStatement(Grammar_WithConceptsAntlrParser::ReturnStatementContext * /*ctx*/) override { }

  virtual void enterThrowStatement_eof(Grammar_WithConceptsAntlrParser::ThrowStatement_eofContext * /*ctx*/) override { }
  virtual void exitThrowStatement_eof(Grammar_WithConceptsAntlrParser::ThrowStatement_eofContext * /*ctx*/) override { }

  virtual void enterThrowStatement(Grammar_WithConceptsAntlrParser::ThrowStatementContext * /*ctx*/) override { }
  virtual void exitThrowStatement(Grammar_WithConceptsAntlrParser::ThrowStatementContext * /*ctx*/) override { }

  virtual void enterBreakStatement_eof(Grammar_WithConceptsAntlrParser::BreakStatement_eofContext * /*ctx*/) override { }
  virtual void exitBreakStatement_eof(Grammar_WithConceptsAntlrParser::BreakStatement_eofContext * /*ctx*/) override { }

  virtual void enterBreakStatement(Grammar_WithConceptsAntlrParser::BreakStatementContext * /*ctx*/) override { }
  virtual void exitBreakStatement(Grammar_WithConceptsAntlrParser::BreakStatementContext * /*ctx*/) override { }

  virtual void enterContinueStatement_eof(Grammar_WithConceptsAntlrParser::ContinueStatement_eofContext * /*ctx*/) override { }
  virtual void exitContinueStatement_eof(Grammar_WithConceptsAntlrParser::ContinueStatement_eofContext * /*ctx*/) override { }

  virtual void enterContinueStatement(Grammar_WithConceptsAntlrParser::ContinueStatementContext * /*ctx*/) override { }
  virtual void exitContinueStatement(Grammar_WithConceptsAntlrParser::ContinueStatementContext * /*ctx*/) override { }

  virtual void enterEmptyStatement_eof(Grammar_WithConceptsAntlrParser::EmptyStatement_eofContext * /*ctx*/) override { }
  virtual void exitEmptyStatement_eof(Grammar_WithConceptsAntlrParser::EmptyStatement_eofContext * /*ctx*/) override { }

  virtual void enterEmptyStatement(Grammar_WithConceptsAntlrParser::EmptyStatementContext * /*ctx*/) override { }
  virtual void exitEmptyStatement(Grammar_WithConceptsAntlrParser::EmptyStatementContext * /*ctx*/) override { }

  virtual void enterExpressionStatement_eof(Grammar_WithConceptsAntlrParser::ExpressionStatement_eofContext * /*ctx*/) override { }
  virtual void exitExpressionStatement_eof(Grammar_WithConceptsAntlrParser::ExpressionStatement_eofContext * /*ctx*/) override { }

  virtual void enterExpressionStatement(Grammar_WithConceptsAntlrParser::ExpressionStatementContext * /*ctx*/) override { }
  virtual void exitExpressionStatement(Grammar_WithConceptsAntlrParser::ExpressionStatementContext * /*ctx*/) override { }

  virtual void enterASTStatement_eof(Grammar_WithConceptsAntlrParser::ASTStatement_eofContext * /*ctx*/) override { }
  virtual void exitASTStatement_eof(Grammar_WithConceptsAntlrParser::ASTStatement_eofContext * /*ctx*/) override { }

  virtual void enterASTStatement(Grammar_WithConceptsAntlrParser::ASTStatementContext * /*ctx*/) override { }
  virtual void exitASTStatement(Grammar_WithConceptsAntlrParser::ASTStatementContext * /*ctx*/) override { }

  virtual void enterLabeledStatement_eof(Grammar_WithConceptsAntlrParser::LabeledStatement_eofContext * /*ctx*/) override { }
  virtual void exitLabeledStatement_eof(Grammar_WithConceptsAntlrParser::LabeledStatement_eofContext * /*ctx*/) override { }

  virtual void enterLabeledStatement(Grammar_WithConceptsAntlrParser::LabeledStatementContext * /*ctx*/) override { }
  virtual void exitLabeledStatement(Grammar_WithConceptsAntlrParser::LabeledStatementContext * /*ctx*/) override { }

  virtual void enterSwitchBlockStatementGroup_eof(Grammar_WithConceptsAntlrParser::SwitchBlockStatementGroup_eofContext * /*ctx*/) override { }
  virtual void exitSwitchBlockStatementGroup_eof(Grammar_WithConceptsAntlrParser::SwitchBlockStatementGroup_eofContext * /*ctx*/) override { }

  virtual void enterSwitchBlockStatementGroup(Grammar_WithConceptsAntlrParser::SwitchBlockStatementGroupContext * /*ctx*/) override { }
  virtual void exitSwitchBlockStatementGroup(Grammar_WithConceptsAntlrParser::SwitchBlockStatementGroupContext * /*ctx*/) override { }

  virtual void enterConstantExpressionSwitchLabel_eof(Grammar_WithConceptsAntlrParser::ConstantExpressionSwitchLabel_eofContext * /*ctx*/) override { }
  virtual void exitConstantExpressionSwitchLabel_eof(Grammar_WithConceptsAntlrParser::ConstantExpressionSwitchLabel_eofContext * /*ctx*/) override { }

  virtual void enterConstantExpressionSwitchLabel(Grammar_WithConceptsAntlrParser::ConstantExpressionSwitchLabelContext * /*ctx*/) override { }
  virtual void exitConstantExpressionSwitchLabel(Grammar_WithConceptsAntlrParser::ConstantExpressionSwitchLabelContext * /*ctx*/) override { }

  virtual void enterEnumConstantSwitchLabel_eof(Grammar_WithConceptsAntlrParser::EnumConstantSwitchLabel_eofContext * /*ctx*/) override { }
  virtual void exitEnumConstantSwitchLabel_eof(Grammar_WithConceptsAntlrParser::EnumConstantSwitchLabel_eofContext * /*ctx*/) override { }

  virtual void enterEnumConstantSwitchLabel(Grammar_WithConceptsAntlrParser::EnumConstantSwitchLabelContext * /*ctx*/) override { }
  virtual void exitEnumConstantSwitchLabel(Grammar_WithConceptsAntlrParser::EnumConstantSwitchLabelContext * /*ctx*/) override { }

  virtual void enterDefaultSwitchLabel_eof(Grammar_WithConceptsAntlrParser::DefaultSwitchLabel_eofContext * /*ctx*/) override { }
  virtual void exitDefaultSwitchLabel_eof(Grammar_WithConceptsAntlrParser::DefaultSwitchLabel_eofContext * /*ctx*/) override { }

  virtual void enterDefaultSwitchLabel(Grammar_WithConceptsAntlrParser::DefaultSwitchLabelContext * /*ctx*/) override { }
  virtual void exitDefaultSwitchLabel(Grammar_WithConceptsAntlrParser::DefaultSwitchLabelContext * /*ctx*/) override { }

  virtual void enterCreatorExpression_eof(Grammar_WithConceptsAntlrParser::CreatorExpression_eofContext * /*ctx*/) override { }
  virtual void exitCreatorExpression_eof(Grammar_WithConceptsAntlrParser::CreatorExpression_eofContext * /*ctx*/) override { }

  virtual void enterCreatorExpression(Grammar_WithConceptsAntlrParser::CreatorExpressionContext * /*ctx*/) override { }
  virtual void exitCreatorExpression(Grammar_WithConceptsAntlrParser::CreatorExpressionContext * /*ctx*/) override { }

  virtual void enterAnonymousClass_eof(Grammar_WithConceptsAntlrParser::AnonymousClass_eofContext * /*ctx*/) override { }
  virtual void exitAnonymousClass_eof(Grammar_WithConceptsAntlrParser::AnonymousClass_eofContext * /*ctx*/) override { }

  virtual void enterAnonymousClass(Grammar_WithConceptsAntlrParser::AnonymousClassContext * /*ctx*/) override { }
  virtual void exitAnonymousClass(Grammar_WithConceptsAntlrParser::AnonymousClassContext * /*ctx*/) override { }

  virtual void enterArrayCreator_eof(Grammar_WithConceptsAntlrParser::ArrayCreator_eofContext * /*ctx*/) override { }
  virtual void exitArrayCreator_eof(Grammar_WithConceptsAntlrParser::ArrayCreator_eofContext * /*ctx*/) override { }

  virtual void enterArrayCreator(Grammar_WithConceptsAntlrParser::ArrayCreatorContext * /*ctx*/) override { }
  virtual void exitArrayCreator(Grammar_WithConceptsAntlrParser::ArrayCreatorContext * /*ctx*/) override { }

  virtual void enterArrayDimensionByInitializer_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionByInitializer_eofContext * /*ctx*/) override { }
  virtual void exitArrayDimensionByInitializer_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionByInitializer_eofContext * /*ctx*/) override { }

  virtual void enterArrayDimensionByInitializer(Grammar_WithConceptsAntlrParser::ArrayDimensionByInitializerContext * /*ctx*/) override { }
  virtual void exitArrayDimensionByInitializer(Grammar_WithConceptsAntlrParser::ArrayDimensionByInitializerContext * /*ctx*/) override { }

  virtual void enterArrayDimensionByExpression_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionByExpression_eofContext * /*ctx*/) override { }
  virtual void exitArrayDimensionByExpression_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionByExpression_eofContext * /*ctx*/) override { }

  virtual void enterArrayDimensionByExpression(Grammar_WithConceptsAntlrParser::ArrayDimensionByExpressionContext * /*ctx*/) override { }
  virtual void exitArrayDimensionByExpression(Grammar_WithConceptsAntlrParser::ArrayDimensionByExpressionContext * /*ctx*/) override { }

  virtual void enterCreatedName_eof(Grammar_WithConceptsAntlrParser::CreatedName_eofContext * /*ctx*/) override { }
  virtual void exitCreatedName_eof(Grammar_WithConceptsAntlrParser::CreatedName_eofContext * /*ctx*/) override { }

  virtual void enterCreatedName(Grammar_WithConceptsAntlrParser::CreatedNameContext * /*ctx*/) override { }
  virtual void exitCreatedName(Grammar_WithConceptsAntlrParser::CreatedNameContext * /*ctx*/) override { }

  virtual void enterInnerCreator_eof(Grammar_WithConceptsAntlrParser::InnerCreator_eofContext * /*ctx*/) override { }
  virtual void exitInnerCreator_eof(Grammar_WithConceptsAntlrParser::InnerCreator_eofContext * /*ctx*/) override { }

  virtual void enterInnerCreator(Grammar_WithConceptsAntlrParser::InnerCreatorContext * /*ctx*/) override { }
  virtual void exitInnerCreator(Grammar_WithConceptsAntlrParser::InnerCreatorContext * /*ctx*/) override { }

  virtual void enterClassCreatorRest_eof(Grammar_WithConceptsAntlrParser::ClassCreatorRest_eofContext * /*ctx*/) override { }
  virtual void exitClassCreatorRest_eof(Grammar_WithConceptsAntlrParser::ClassCreatorRest_eofContext * /*ctx*/) override { }

  virtual void enterClassCreatorRest(Grammar_WithConceptsAntlrParser::ClassCreatorRestContext * /*ctx*/) override { }
  virtual void exitClassCreatorRest(Grammar_WithConceptsAntlrParser::ClassCreatorRestContext * /*ctx*/) override { }

  virtual void enterMCGrammar_eof(Grammar_WithConceptsAntlrParser::MCGrammar_eofContext * /*ctx*/) override { }
  virtual void exitMCGrammar_eof(Grammar_WithConceptsAntlrParser::MCGrammar_eofContext * /*ctx*/) override { }

  virtual void enterMCGrammar(Grammar_WithConceptsAntlrParser::MCGrammarContext * /*ctx*/) override { }
  virtual void exitMCGrammar(Grammar_WithConceptsAntlrParser::MCGrammarContext * /*ctx*/) override { }

  virtual void enterMCImportStatement_eof(Grammar_WithConceptsAntlrParser::MCImportStatement_eofContext * /*ctx*/) override { }
  virtual void exitMCImportStatement_eof(Grammar_WithConceptsAntlrParser::MCImportStatement_eofContext * /*ctx*/) override { }

  virtual void enterMCImportStatement(Grammar_WithConceptsAntlrParser::MCImportStatementContext * /*ctx*/) override { }
  virtual void exitMCImportStatement(Grammar_WithConceptsAntlrParser::MCImportStatementContext * /*ctx*/) override { }

  virtual void enterGrammarReference_eof(Grammar_WithConceptsAntlrParser::GrammarReference_eofContext * /*ctx*/) override { }
  virtual void exitGrammarReference_eof(Grammar_WithConceptsAntlrParser::GrammarReference_eofContext * /*ctx*/) override { }

  virtual void enterGrammarReference(Grammar_WithConceptsAntlrParser::GrammarReferenceContext * /*ctx*/) override { }
  virtual void exitGrammarReference(Grammar_WithConceptsAntlrParser::GrammarReferenceContext * /*ctx*/) override { }

  virtual void enterGrammarOption_eof(Grammar_WithConceptsAntlrParser::GrammarOption_eofContext * /*ctx*/) override { }
  virtual void exitGrammarOption_eof(Grammar_WithConceptsAntlrParser::GrammarOption_eofContext * /*ctx*/) override { }

  virtual void enterGrammarOption(Grammar_WithConceptsAntlrParser::GrammarOptionContext * /*ctx*/) override { }
  virtual void exitGrammarOption(Grammar_WithConceptsAntlrParser::GrammarOptionContext * /*ctx*/) override { }

  virtual void enterFollowOption_eof(Grammar_WithConceptsAntlrParser::FollowOption_eofContext * /*ctx*/) override { }
  virtual void exitFollowOption_eof(Grammar_WithConceptsAntlrParser::FollowOption_eofContext * /*ctx*/) override { }

  virtual void enterFollowOption(Grammar_WithConceptsAntlrParser::FollowOptionContext * /*ctx*/) override { }
  virtual void exitFollowOption(Grammar_WithConceptsAntlrParser::FollowOptionContext * /*ctx*/) override { }

  virtual void enterAntlrOption_eof(Grammar_WithConceptsAntlrParser::AntlrOption_eofContext * /*ctx*/) override { }
  virtual void exitAntlrOption_eof(Grammar_WithConceptsAntlrParser::AntlrOption_eofContext * /*ctx*/) override { }

  virtual void enterAntlrOption(Grammar_WithConceptsAntlrParser::AntlrOptionContext * /*ctx*/) override { }
  virtual void exitAntlrOption(Grammar_WithConceptsAntlrParser::AntlrOptionContext * /*ctx*/) override { }

  virtual void enterStartRule_eof(Grammar_WithConceptsAntlrParser::StartRule_eofContext * /*ctx*/) override { }
  virtual void exitStartRule_eof(Grammar_WithConceptsAntlrParser::StartRule_eofContext * /*ctx*/) override { }

  virtual void enterStartRule(Grammar_WithConceptsAntlrParser::StartRuleContext * /*ctx*/) override { }
  virtual void exitStartRule(Grammar_WithConceptsAntlrParser::StartRuleContext * /*ctx*/) override { }

  virtual void enterLexProd_eof(Grammar_WithConceptsAntlrParser::LexProd_eofContext * /*ctx*/) override { }
  virtual void exitLexProd_eof(Grammar_WithConceptsAntlrParser::LexProd_eofContext * /*ctx*/) override { }

  virtual void enterLexProd(Grammar_WithConceptsAntlrParser::LexProdContext * /*ctx*/) override { }
  virtual void exitLexProd(Grammar_WithConceptsAntlrParser::LexProdContext * /*ctx*/) override { }

  virtual void enterEnumProd_eof(Grammar_WithConceptsAntlrParser::EnumProd_eofContext * /*ctx*/) override { }
  virtual void exitEnumProd_eof(Grammar_WithConceptsAntlrParser::EnumProd_eofContext * /*ctx*/) override { }

  virtual void enterEnumProd(Grammar_WithConceptsAntlrParser::EnumProdContext * /*ctx*/) override { }
  virtual void exitEnumProd(Grammar_WithConceptsAntlrParser::EnumProdContext * /*ctx*/) override { }

  virtual void enterExternalProd_eof(Grammar_WithConceptsAntlrParser::ExternalProd_eofContext * /*ctx*/) override { }
  virtual void exitExternalProd_eof(Grammar_WithConceptsAntlrParser::ExternalProd_eofContext * /*ctx*/) override { }

  virtual void enterExternalProd(Grammar_WithConceptsAntlrParser::ExternalProdContext * /*ctx*/) override { }
  virtual void exitExternalProd(Grammar_WithConceptsAntlrParser::ExternalProdContext * /*ctx*/) override { }

  virtual void enterInterfaceProd_eof(Grammar_WithConceptsAntlrParser::InterfaceProd_eofContext * /*ctx*/) override { }
  virtual void exitInterfaceProd_eof(Grammar_WithConceptsAntlrParser::InterfaceProd_eofContext * /*ctx*/) override { }

  virtual void enterInterfaceProd(Grammar_WithConceptsAntlrParser::InterfaceProdContext * /*ctx*/) override { }
  virtual void exitInterfaceProd(Grammar_WithConceptsAntlrParser::InterfaceProdContext * /*ctx*/) override { }

  virtual void enterAbstractProd_eof(Grammar_WithConceptsAntlrParser::AbstractProd_eofContext * /*ctx*/) override { }
  virtual void exitAbstractProd_eof(Grammar_WithConceptsAntlrParser::AbstractProd_eofContext * /*ctx*/) override { }

  virtual void enterAbstractProd(Grammar_WithConceptsAntlrParser::AbstractProdContext * /*ctx*/) override { }
  virtual void exitAbstractProd(Grammar_WithConceptsAntlrParser::AbstractProdContext * /*ctx*/) override { }

  virtual void enterClassProd_eof(Grammar_WithConceptsAntlrParser::ClassProd_eofContext * /*ctx*/) override { }
  virtual void exitClassProd_eof(Grammar_WithConceptsAntlrParser::ClassProd_eofContext * /*ctx*/) override { }

  virtual void enterClassProd(Grammar_WithConceptsAntlrParser::ClassProdContext * /*ctx*/) override { }
  virtual void exitClassProd(Grammar_WithConceptsAntlrParser::ClassProdContext * /*ctx*/) override { }

  virtual void enterCard_eof(Grammar_WithConceptsAntlrParser::Card_eofContext * /*ctx*/) override { }
  virtual void exitCard_eof(Grammar_WithConceptsAntlrParser::Card_eofContext * /*ctx*/) override { }

  virtual void enterCard(Grammar_WithConceptsAntlrParser::CardContext * /*ctx*/) override { }
  virtual void exitCard(Grammar_WithConceptsAntlrParser::CardContext * /*ctx*/) override { }

  virtual void enterRuleReference_eof(Grammar_WithConceptsAntlrParser::RuleReference_eofContext * /*ctx*/) override { }
  virtual void exitRuleReference_eof(Grammar_WithConceptsAntlrParser::RuleReference_eofContext * /*ctx*/) override { }

  virtual void enterRuleReference(Grammar_WithConceptsAntlrParser::RuleReferenceContext * /*ctx*/) override { }
  virtual void exitRuleReference(Grammar_WithConceptsAntlrParser::RuleReferenceContext * /*ctx*/) override { }

  virtual void enterAlt_eof(Grammar_WithConceptsAntlrParser::Alt_eofContext * /*ctx*/) override { }
  virtual void exitAlt_eof(Grammar_WithConceptsAntlrParser::Alt_eofContext * /*ctx*/) override { }

  virtual void enterAlt(Grammar_WithConceptsAntlrParser::AltContext * /*ctx*/) override { }
  virtual void exitAlt(Grammar_WithConceptsAntlrParser::AltContext * /*ctx*/) override { }

  virtual void enterNonTerminalSeparator_eof(Grammar_WithConceptsAntlrParser::NonTerminalSeparator_eofContext * /*ctx*/) override { }
  virtual void exitNonTerminalSeparator_eof(Grammar_WithConceptsAntlrParser::NonTerminalSeparator_eofContext * /*ctx*/) override { }

  virtual void enterNonTerminalSeparator(Grammar_WithConceptsAntlrParser::NonTerminalSeparatorContext * /*ctx*/) override { }
  virtual void exitNonTerminalSeparator(Grammar_WithConceptsAntlrParser::NonTerminalSeparatorContext * /*ctx*/) override { }

  virtual void enterBlock_eof(Grammar_WithConceptsAntlrParser::Block_eofContext * /*ctx*/) override { }
  virtual void exitBlock_eof(Grammar_WithConceptsAntlrParser::Block_eofContext * /*ctx*/) override { }

  virtual void enterBlock(Grammar_WithConceptsAntlrParser::BlockContext * /*ctx*/) override { }
  virtual void exitBlock(Grammar_WithConceptsAntlrParser::BlockContext * /*ctx*/) override { }

  virtual void enterOption_eof(Grammar_WithConceptsAntlrParser::Option_eofContext * /*ctx*/) override { }
  virtual void exitOption_eof(Grammar_WithConceptsAntlrParser::Option_eofContext * /*ctx*/) override { }

  virtual void enterOption(Grammar_WithConceptsAntlrParser::OptionContext * /*ctx*/) override { }
  virtual void exitOption(Grammar_WithConceptsAntlrParser::OptionContext * /*ctx*/) override { }

  virtual void enterOptionValue_eof(Grammar_WithConceptsAntlrParser::OptionValue_eofContext * /*ctx*/) override { }
  virtual void exitOptionValue_eof(Grammar_WithConceptsAntlrParser::OptionValue_eofContext * /*ctx*/) override { }

  virtual void enterOptionValue(Grammar_WithConceptsAntlrParser::OptionValueContext * /*ctx*/) override { }
  virtual void exitOptionValue(Grammar_WithConceptsAntlrParser::OptionValueContext * /*ctx*/) override { }

  virtual void enterNonTerminal_eof(Grammar_WithConceptsAntlrParser::NonTerminal_eofContext * /*ctx*/) override { }
  virtual void exitNonTerminal_eof(Grammar_WithConceptsAntlrParser::NonTerminal_eofContext * /*ctx*/) override { }

  virtual void enterNonTerminal(Grammar_WithConceptsAntlrParser::NonTerminalContext * /*ctx*/) override { }
  virtual void exitNonTerminal(Grammar_WithConceptsAntlrParser::NonTerminalContext * /*ctx*/) override { }

  virtual void enterTerminal_eof(Grammar_WithConceptsAntlrParser::Terminal_eofContext * /*ctx*/) override { }
  virtual void exitTerminal_eof(Grammar_WithConceptsAntlrParser::Terminal_eofContext * /*ctx*/) override { }

  virtual void enterTerminal(Grammar_WithConceptsAntlrParser::TerminalContext * /*ctx*/) override { }
  virtual void exitTerminal(Grammar_WithConceptsAntlrParser::TerminalContext * /*ctx*/) override { }

  virtual void enterConstant_eof(Grammar_WithConceptsAntlrParser::Constant_eofContext * /*ctx*/) override { }
  virtual void exitConstant_eof(Grammar_WithConceptsAntlrParser::Constant_eofContext * /*ctx*/) override { }

  virtual void enterConstant(Grammar_WithConceptsAntlrParser::ConstantContext * /*ctx*/) override { }
  virtual void exitConstant(Grammar_WithConceptsAntlrParser::ConstantContext * /*ctx*/) override { }

  virtual void enterConstantGroup_eof(Grammar_WithConceptsAntlrParser::ConstantGroup_eofContext * /*ctx*/) override { }
  virtual void exitConstantGroup_eof(Grammar_WithConceptsAntlrParser::ConstantGroup_eofContext * /*ctx*/) override { }

  virtual void enterConstantGroup(Grammar_WithConceptsAntlrParser::ConstantGroupContext * /*ctx*/) override { }
  virtual void exitConstantGroup(Grammar_WithConceptsAntlrParser::ConstantGroupContext * /*ctx*/) override { }

  virtual void enterEof_eof(Grammar_WithConceptsAntlrParser::Eof_eofContext * /*ctx*/) override { }
  virtual void exitEof_eof(Grammar_WithConceptsAntlrParser::Eof_eofContext * /*ctx*/) override { }

  virtual void enterEof(Grammar_WithConceptsAntlrParser::EofContext * /*ctx*/) override { }
  virtual void exitEof(Grammar_WithConceptsAntlrParser::EofContext * /*ctx*/) override { }

  virtual void enterMCAnything_eof(Grammar_WithConceptsAntlrParser::MCAnything_eofContext * /*ctx*/) override { }
  virtual void exitMCAnything_eof(Grammar_WithConceptsAntlrParser::MCAnything_eofContext * /*ctx*/) override { }

  virtual void enterMCAnything(Grammar_WithConceptsAntlrParser::MCAnythingContext * /*ctx*/) override { }
  virtual void exitMCAnything(Grammar_WithConceptsAntlrParser::MCAnythingContext * /*ctx*/) override { }

  virtual void enterAnything_eof(Grammar_WithConceptsAntlrParser::Anything_eofContext * /*ctx*/) override { }
  virtual void exitAnything_eof(Grammar_WithConceptsAntlrParser::Anything_eofContext * /*ctx*/) override { }

  virtual void enterAnything(Grammar_WithConceptsAntlrParser::AnythingContext * /*ctx*/) override { }
  virtual void exitAnything(Grammar_WithConceptsAntlrParser::AnythingContext * /*ctx*/) override { }

  virtual void enterSemanticpredicateOrAction_eof(Grammar_WithConceptsAntlrParser::SemanticpredicateOrAction_eofContext * /*ctx*/) override { }
  virtual void exitSemanticpredicateOrAction_eof(Grammar_WithConceptsAntlrParser::SemanticpredicateOrAction_eofContext * /*ctx*/) override { }

  virtual void enterSemanticpredicateOrAction(Grammar_WithConceptsAntlrParser::SemanticpredicateOrActionContext * /*ctx*/) override { }
  virtual void exitSemanticpredicateOrAction(Grammar_WithConceptsAntlrParser::SemanticpredicateOrActionContext * /*ctx*/) override { }

  virtual void enterConcept_eof(Grammar_WithConceptsAntlrParser::Concept_eofContext * /*ctx*/) override { }
  virtual void exitConcept_eof(Grammar_WithConceptsAntlrParser::Concept_eofContext * /*ctx*/) override { }

  virtual void enterConcept_(Grammar_WithConceptsAntlrParser::Concept_Context * /*ctx*/) override { }
  virtual void exitConcept_(Grammar_WithConceptsAntlrParser::Concept_Context * /*ctx*/) override { }

  virtual void enterASTRule_eof(Grammar_WithConceptsAntlrParser::ASTRule_eofContext * /*ctx*/) override { }
  virtual void exitASTRule_eof(Grammar_WithConceptsAntlrParser::ASTRule_eofContext * /*ctx*/) override { }

  virtual void enterASTRule(Grammar_WithConceptsAntlrParser::ASTRuleContext * /*ctx*/) override { }
  virtual void exitASTRule(Grammar_WithConceptsAntlrParser::ASTRuleContext * /*ctx*/) override { }

  virtual void enterMethod_eof(Grammar_WithConceptsAntlrParser::Method_eofContext * /*ctx*/) override { }
  virtual void exitMethod_eof(Grammar_WithConceptsAntlrParser::Method_eofContext * /*ctx*/) override { }

  virtual void enterMethod(Grammar_WithConceptsAntlrParser::MethodContext * /*ctx*/) override { }
  virtual void exitMethod(Grammar_WithConceptsAntlrParser::MethodContext * /*ctx*/) override { }

  virtual void enterMethodParameter_eof(Grammar_WithConceptsAntlrParser::MethodParameter_eofContext * /*ctx*/) override { }
  virtual void exitMethodParameter_eof(Grammar_WithConceptsAntlrParser::MethodParameter_eofContext * /*ctx*/) override { }

  virtual void enterMethodParameter(Grammar_WithConceptsAntlrParser::MethodParameterContext * /*ctx*/) override { }
  virtual void exitMethodParameter(Grammar_WithConceptsAntlrParser::MethodParameterContext * /*ctx*/) override { }

  virtual void enterAttributeInAST_eof(Grammar_WithConceptsAntlrParser::AttributeInAST_eofContext * /*ctx*/) override { }
  virtual void exitAttributeInAST_eof(Grammar_WithConceptsAntlrParser::AttributeInAST_eofContext * /*ctx*/) override { }

  virtual void enterAttributeInAST(Grammar_WithConceptsAntlrParser::AttributeInASTContext * /*ctx*/) override { }
  virtual void exitAttributeInAST(Grammar_WithConceptsAntlrParser::AttributeInASTContext * /*ctx*/) override { }

  virtual void enterGenericType_eof(Grammar_WithConceptsAntlrParser::GenericType_eofContext * /*ctx*/) override { }
  virtual void exitGenericType_eof(Grammar_WithConceptsAntlrParser::GenericType_eofContext * /*ctx*/) override { }

  virtual void enterGenericType(Grammar_WithConceptsAntlrParser::GenericTypeContext * /*ctx*/) override { }
  virtual void exitGenericType(Grammar_WithConceptsAntlrParser::GenericTypeContext * /*ctx*/) override { }

  virtual void enterLexAlt_eof(Grammar_WithConceptsAntlrParser::LexAlt_eofContext * /*ctx*/) override { }
  virtual void exitLexAlt_eof(Grammar_WithConceptsAntlrParser::LexAlt_eofContext * /*ctx*/) override { }

  virtual void enterLexAlt(Grammar_WithConceptsAntlrParser::LexAltContext * /*ctx*/) override { }
  virtual void exitLexAlt(Grammar_WithConceptsAntlrParser::LexAltContext * /*ctx*/) override { }

  virtual void enterLexBlock_eof(Grammar_WithConceptsAntlrParser::LexBlock_eofContext * /*ctx*/) override { }
  virtual void exitLexBlock_eof(Grammar_WithConceptsAntlrParser::LexBlock_eofContext * /*ctx*/) override { }

  virtual void enterLexBlock(Grammar_WithConceptsAntlrParser::LexBlockContext * /*ctx*/) override { }
  virtual void exitLexBlock(Grammar_WithConceptsAntlrParser::LexBlockContext * /*ctx*/) override { }

  virtual void enterLexCharRange_eof(Grammar_WithConceptsAntlrParser::LexCharRange_eofContext * /*ctx*/) override { }
  virtual void exitLexCharRange_eof(Grammar_WithConceptsAntlrParser::LexCharRange_eofContext * /*ctx*/) override { }

  virtual void enterLexCharRange(Grammar_WithConceptsAntlrParser::LexCharRangeContext * /*ctx*/) override { }
  virtual void exitLexCharRange(Grammar_WithConceptsAntlrParser::LexCharRangeContext * /*ctx*/) override { }

  virtual void enterLexChar_eof(Grammar_WithConceptsAntlrParser::LexChar_eofContext * /*ctx*/) override { }
  virtual void exitLexChar_eof(Grammar_WithConceptsAntlrParser::LexChar_eofContext * /*ctx*/) override { }

  virtual void enterLexChar(Grammar_WithConceptsAntlrParser::LexCharContext * /*ctx*/) override { }
  virtual void exitLexChar(Grammar_WithConceptsAntlrParser::LexCharContext * /*ctx*/) override { }

  virtual void enterLexAnyChar_eof(Grammar_WithConceptsAntlrParser::LexAnyChar_eofContext * /*ctx*/) override { }
  virtual void exitLexAnyChar_eof(Grammar_WithConceptsAntlrParser::LexAnyChar_eofContext * /*ctx*/) override { }

  virtual void enterLexAnyChar(Grammar_WithConceptsAntlrParser::LexAnyCharContext * /*ctx*/) override { }
  virtual void exitLexAnyChar(Grammar_WithConceptsAntlrParser::LexAnyCharContext * /*ctx*/) override { }

  virtual void enterLexString_eof(Grammar_WithConceptsAntlrParser::LexString_eofContext * /*ctx*/) override { }
  virtual void exitLexString_eof(Grammar_WithConceptsAntlrParser::LexString_eofContext * /*ctx*/) override { }

  virtual void enterLexString(Grammar_WithConceptsAntlrParser::LexStringContext * /*ctx*/) override { }
  virtual void exitLexString(Grammar_WithConceptsAntlrParser::LexStringContext * /*ctx*/) override { }

  virtual void enterLexActionOrPredicate_eof(Grammar_WithConceptsAntlrParser::LexActionOrPredicate_eofContext * /*ctx*/) override { }
  virtual void exitLexActionOrPredicate_eof(Grammar_WithConceptsAntlrParser::LexActionOrPredicate_eofContext * /*ctx*/) override { }

  virtual void enterLexActionOrPredicate(Grammar_WithConceptsAntlrParser::LexActionOrPredicateContext * /*ctx*/) override { }
  virtual void exitLexActionOrPredicate(Grammar_WithConceptsAntlrParser::LexActionOrPredicateContext * /*ctx*/) override { }

  virtual void enterLexNonTerminal_eof(Grammar_WithConceptsAntlrParser::LexNonTerminal_eofContext * /*ctx*/) override { }
  virtual void exitLexNonTerminal_eof(Grammar_WithConceptsAntlrParser::LexNonTerminal_eofContext * /*ctx*/) override { }

  virtual void enterLexNonTerminal(Grammar_WithConceptsAntlrParser::LexNonTerminalContext * /*ctx*/) override { }
  virtual void exitLexNonTerminal(Grammar_WithConceptsAntlrParser::LexNonTerminalContext * /*ctx*/) override { }

  virtual void enterLexSimpleIteration_eof(Grammar_WithConceptsAntlrParser::LexSimpleIteration_eofContext * /*ctx*/) override { }
  virtual void exitLexSimpleIteration_eof(Grammar_WithConceptsAntlrParser::LexSimpleIteration_eofContext * /*ctx*/) override { }

  virtual void enterLexSimpleIteration(Grammar_WithConceptsAntlrParser::LexSimpleIterationContext * /*ctx*/) override { }
  virtual void exitLexSimpleIteration(Grammar_WithConceptsAntlrParser::LexSimpleIterationContext * /*ctx*/) override { }

  virtual void enterLexOption_eof(Grammar_WithConceptsAntlrParser::LexOption_eofContext * /*ctx*/) override { }
  virtual void exitLexOption_eof(Grammar_WithConceptsAntlrParser::LexOption_eofContext * /*ctx*/) override { }

  virtual void enterLexOption(Grammar_WithConceptsAntlrParser::LexOptionContext * /*ctx*/) override { }
  virtual void exitLexOption(Grammar_WithConceptsAntlrParser::LexOptionContext * /*ctx*/) override { }

  virtual void enterSymbolDefinition_eof(Grammar_WithConceptsAntlrParser::SymbolDefinition_eofContext * /*ctx*/) override { }
  virtual void exitSymbolDefinition_eof(Grammar_WithConceptsAntlrParser::SymbolDefinition_eofContext * /*ctx*/) override { }

  virtual void enterSymbolDefinition(Grammar_WithConceptsAntlrParser::SymbolDefinitionContext * /*ctx*/) override { }
  virtual void exitSymbolDefinition(Grammar_WithConceptsAntlrParser::SymbolDefinitionContext * /*ctx*/) override { }

  virtual void enterAction_eof(Grammar_WithConceptsAntlrParser::Action_eofContext * /*ctx*/) override { }
  virtual void exitAction_eof(Grammar_WithConceptsAntlrParser::Action_eofContext * /*ctx*/) override { }

  virtual void enterAction(Grammar_WithConceptsAntlrParser::ActionContext * /*ctx*/) override { }
  virtual void exitAction(Grammar_WithConceptsAntlrParser::ActionContext * /*ctx*/) override { }

  virtual void enterExpressionPredicate_eof(Grammar_WithConceptsAntlrParser::ExpressionPredicate_eofContext * /*ctx*/) override { }
  virtual void exitExpressionPredicate_eof(Grammar_WithConceptsAntlrParser::ExpressionPredicate_eofContext * /*ctx*/) override { }

  virtual void enterExpressionPredicate(Grammar_WithConceptsAntlrParser::ExpressionPredicateContext * /*ctx*/) override { }
  virtual void exitExpressionPredicate(Grammar_WithConceptsAntlrParser::ExpressionPredicateContext * /*ctx*/) override { }

  virtual void enterMCConcept_eof(Grammar_WithConceptsAntlrParser::MCConcept_eofContext * /*ctx*/) override { }
  virtual void exitMCConcept_eof(Grammar_WithConceptsAntlrParser::MCConcept_eofContext * /*ctx*/) override { }

  virtual void enterMCConcept(Grammar_WithConceptsAntlrParser::MCConceptContext * /*ctx*/) override { }
  virtual void exitMCConcept(Grammar_WithConceptsAntlrParser::MCConceptContext * /*ctx*/) override { }

  virtual void enterLiteral_eof(Grammar_WithConceptsAntlrParser::Literal_eofContext * /*ctx*/) override { }
  virtual void exitLiteral_eof(Grammar_WithConceptsAntlrParser::Literal_eofContext * /*ctx*/) override { }

  virtual void enterLiteral(Grammar_WithConceptsAntlrParser::LiteralContext * /*ctx*/) override { }
  virtual void exitLiteral(Grammar_WithConceptsAntlrParser::LiteralContext * /*ctx*/) override { }

  virtual void enterSignedLiteral_eof(Grammar_WithConceptsAntlrParser::SignedLiteral_eofContext * /*ctx*/) override { }
  virtual void exitSignedLiteral_eof(Grammar_WithConceptsAntlrParser::SignedLiteral_eofContext * /*ctx*/) override { }

  virtual void enterSignedLiteral(Grammar_WithConceptsAntlrParser::SignedLiteralContext * /*ctx*/) override { }
  virtual void exitSignedLiteral(Grammar_WithConceptsAntlrParser::SignedLiteralContext * /*ctx*/) override { }

  virtual void enterNumericLiteral_eof(Grammar_WithConceptsAntlrParser::NumericLiteral_eofContext * /*ctx*/) override { }
  virtual void exitNumericLiteral_eof(Grammar_WithConceptsAntlrParser::NumericLiteral_eofContext * /*ctx*/) override { }

  virtual void enterNumericLiteral(Grammar_WithConceptsAntlrParser::NumericLiteralContext * /*ctx*/) override { }
  virtual void exitNumericLiteral(Grammar_WithConceptsAntlrParser::NumericLiteralContext * /*ctx*/) override { }

  virtual void enterSignedNumericLiteral_eof(Grammar_WithConceptsAntlrParser::SignedNumericLiteral_eofContext * /*ctx*/) override { }
  virtual void exitSignedNumericLiteral_eof(Grammar_WithConceptsAntlrParser::SignedNumericLiteral_eofContext * /*ctx*/) override { }

  virtual void enterSignedNumericLiteral(Grammar_WithConceptsAntlrParser::SignedNumericLiteralContext * /*ctx*/) override { }
  virtual void exitSignedNumericLiteral(Grammar_WithConceptsAntlrParser::SignedNumericLiteralContext * /*ctx*/) override { }

  virtual void enterType_eof(Grammar_WithConceptsAntlrParser::Type_eofContext * /*ctx*/) override { }
  virtual void exitType_eof(Grammar_WithConceptsAntlrParser::Type_eofContext * /*ctx*/) override { }

  virtual void enterType(Grammar_WithConceptsAntlrParser::TypeContext * /*ctx*/) override { }
  virtual void exitType(Grammar_WithConceptsAntlrParser::TypeContext * /*ctx*/) override { }

  virtual void enterReferenceType_eof(Grammar_WithConceptsAntlrParser::ReferenceType_eofContext * /*ctx*/) override { }
  virtual void exitReferenceType_eof(Grammar_WithConceptsAntlrParser::ReferenceType_eofContext * /*ctx*/) override { }

  virtual void enterReferenceType(Grammar_WithConceptsAntlrParser::ReferenceTypeContext * /*ctx*/) override { }
  virtual void exitReferenceType(Grammar_WithConceptsAntlrParser::ReferenceTypeContext * /*ctx*/) override { }

  virtual void enterTypeArgument_eof(Grammar_WithConceptsAntlrParser::TypeArgument_eofContext * /*ctx*/) override { }
  virtual void exitTypeArgument_eof(Grammar_WithConceptsAntlrParser::TypeArgument_eofContext * /*ctx*/) override { }

  virtual void enterTypeArgument(Grammar_WithConceptsAntlrParser::TypeArgumentContext * /*ctx*/) override { }
  virtual void exitTypeArgument(Grammar_WithConceptsAntlrParser::TypeArgumentContext * /*ctx*/) override { }

  virtual void enterReturnType_eof(Grammar_WithConceptsAntlrParser::ReturnType_eofContext * /*ctx*/) override { }
  virtual void exitReturnType_eof(Grammar_WithConceptsAntlrParser::ReturnType_eofContext * /*ctx*/) override { }

  virtual void enterReturnType(Grammar_WithConceptsAntlrParser::ReturnTypeContext * /*ctx*/) override { }
  virtual void exitReturnType(Grammar_WithConceptsAntlrParser::ReturnTypeContext * /*ctx*/) override { }

  virtual void enterArrayType_eof(Grammar_WithConceptsAntlrParser::ArrayType_eofContext * /*ctx*/) override { }
  virtual void exitArrayType_eof(Grammar_WithConceptsAntlrParser::ArrayType_eofContext * /*ctx*/) override { }

  virtual void enterArrayType(Grammar_WithConceptsAntlrParser::ArrayTypeContext * /*ctx*/) override { }
  virtual void exitArrayType(Grammar_WithConceptsAntlrParser::ArrayTypeContext * /*ctx*/) override { }

  virtual void enterExpression_eof(Grammar_WithConceptsAntlrParser::Expression_eofContext * /*ctx*/) override { }
  virtual void exitExpression_eof(Grammar_WithConceptsAntlrParser::Expression_eofContext * /*ctx*/) override { }

  virtual void enterExpression(Grammar_WithConceptsAntlrParser::ExpressionContext * /*ctx*/) override { }
  virtual void exitExpression(Grammar_WithConceptsAntlrParser::ExpressionContext * /*ctx*/) override { }

  virtual void enterModifier_eof(Grammar_WithConceptsAntlrParser::Modifier_eofContext * /*ctx*/) override { }
  virtual void exitModifier_eof(Grammar_WithConceptsAntlrParser::Modifier_eofContext * /*ctx*/) override { }

  virtual void enterModifier(Grammar_WithConceptsAntlrParser::ModifierContext * /*ctx*/) override { }
  virtual void exitModifier(Grammar_WithConceptsAntlrParser::ModifierContext * /*ctx*/) override { }

  virtual void enterTypeDeclaration_eof(Grammar_WithConceptsAntlrParser::TypeDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitTypeDeclaration_eof(Grammar_WithConceptsAntlrParser::TypeDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterTypeDeclaration(Grammar_WithConceptsAntlrParser::TypeDeclarationContext * /*ctx*/) override { }
  virtual void exitTypeDeclaration(Grammar_WithConceptsAntlrParser::TypeDeclarationContext * /*ctx*/) override { }

  virtual void enterClassBodyDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassBodyDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitClassBodyDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassBodyDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterClassBodyDeclaration(Grammar_WithConceptsAntlrParser::ClassBodyDeclarationContext * /*ctx*/) override { }
  virtual void exitClassBodyDeclaration(Grammar_WithConceptsAntlrParser::ClassBodyDeclarationContext * /*ctx*/) override { }

  virtual void enterInterfaceBodyDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceBodyDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitInterfaceBodyDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceBodyDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterInterfaceBodyDeclaration(Grammar_WithConceptsAntlrParser::InterfaceBodyDeclarationContext * /*ctx*/) override { }
  virtual void exitInterfaceBodyDeclaration(Grammar_WithConceptsAntlrParser::InterfaceBodyDeclarationContext * /*ctx*/) override { }

  virtual void enterClassMemberDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassMemberDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitClassMemberDeclaration_eof(Grammar_WithConceptsAntlrParser::ClassMemberDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterClassMemberDeclaration(Grammar_WithConceptsAntlrParser::ClassMemberDeclarationContext * /*ctx*/) override { }
  virtual void exitClassMemberDeclaration(Grammar_WithConceptsAntlrParser::ClassMemberDeclarationContext * /*ctx*/) override { }

  virtual void enterMethodBody_eof(Grammar_WithConceptsAntlrParser::MethodBody_eofContext * /*ctx*/) override { }
  virtual void exitMethodBody_eof(Grammar_WithConceptsAntlrParser::MethodBody_eofContext * /*ctx*/) override { }

  virtual void enterMethodBody(Grammar_WithConceptsAntlrParser::MethodBodyContext * /*ctx*/) override { }
  virtual void exitMethodBody(Grammar_WithConceptsAntlrParser::MethodBodyContext * /*ctx*/) override { }

  virtual void enterConstructorBody_eof(Grammar_WithConceptsAntlrParser::ConstructorBody_eofContext * /*ctx*/) override { }
  virtual void exitConstructorBody_eof(Grammar_WithConceptsAntlrParser::ConstructorBody_eofContext * /*ctx*/) override { }

  virtual void enterConstructorBody(Grammar_WithConceptsAntlrParser::ConstructorBodyContext * /*ctx*/) override { }
  virtual void exitConstructorBody(Grammar_WithConceptsAntlrParser::ConstructorBodyContext * /*ctx*/) override { }

  virtual void enterInterfaceMemberDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceMemberDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitInterfaceMemberDeclaration_eof(Grammar_WithConceptsAntlrParser::InterfaceMemberDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterInterfaceMemberDeclaration(Grammar_WithConceptsAntlrParser::InterfaceMemberDeclarationContext * /*ctx*/) override { }
  virtual void exitInterfaceMemberDeclaration(Grammar_WithConceptsAntlrParser::InterfaceMemberDeclarationContext * /*ctx*/) override { }

  virtual void enterVariableInitializer_eof(Grammar_WithConceptsAntlrParser::VariableInitializer_eofContext * /*ctx*/) override { }
  virtual void exitVariableInitializer_eof(Grammar_WithConceptsAntlrParser::VariableInitializer_eofContext * /*ctx*/) override { }

  virtual void enterVariableInitializer(Grammar_WithConceptsAntlrParser::VariableInitializerContext * /*ctx*/) override { }
  virtual void exitVariableInitializer(Grammar_WithConceptsAntlrParser::VariableInitializerContext * /*ctx*/) override { }

  virtual void enterAnnotationArguments_eof(Grammar_WithConceptsAntlrParser::AnnotationArguments_eofContext * /*ctx*/) override { }
  virtual void exitAnnotationArguments_eof(Grammar_WithConceptsAntlrParser::AnnotationArguments_eofContext * /*ctx*/) override { }

  virtual void enterAnnotationArguments(Grammar_WithConceptsAntlrParser::AnnotationArgumentsContext * /*ctx*/) override { }
  virtual void exitAnnotationArguments(Grammar_WithConceptsAntlrParser::AnnotationArgumentsContext * /*ctx*/) override { }

  virtual void enterElementValue_eof(Grammar_WithConceptsAntlrParser::ElementValue_eofContext * /*ctx*/) override { }
  virtual void exitElementValue_eof(Grammar_WithConceptsAntlrParser::ElementValue_eofContext * /*ctx*/) override { }

  virtual void enterElementValue(Grammar_WithConceptsAntlrParser::ElementValueContext * /*ctx*/) override { }
  virtual void exitElementValue(Grammar_WithConceptsAntlrParser::ElementValueContext * /*ctx*/) override { }

  virtual void enterAnnotationTypeElementDeclaration_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeElementDeclaration_eofContext * /*ctx*/) override { }
  virtual void exitAnnotationTypeElementDeclaration_eof(Grammar_WithConceptsAntlrParser::AnnotationTypeElementDeclaration_eofContext * /*ctx*/) override { }

  virtual void enterAnnotationTypeElementDeclaration(Grammar_WithConceptsAntlrParser::AnnotationTypeElementDeclarationContext * /*ctx*/) override { }
  virtual void exitAnnotationTypeElementDeclaration(Grammar_WithConceptsAntlrParser::AnnotationTypeElementDeclarationContext * /*ctx*/) override { }

  virtual void enterBlockStatement_eof(Grammar_WithConceptsAntlrParser::BlockStatement_eofContext * /*ctx*/) override { }
  virtual void exitBlockStatement_eof(Grammar_WithConceptsAntlrParser::BlockStatement_eofContext * /*ctx*/) override { }

  virtual void enterBlockStatement(Grammar_WithConceptsAntlrParser::BlockStatementContext * /*ctx*/) override { }
  virtual void exitBlockStatement(Grammar_WithConceptsAntlrParser::BlockStatementContext * /*ctx*/) override { }

  virtual void enterStatement_eof(Grammar_WithConceptsAntlrParser::Statement_eofContext * /*ctx*/) override { }
  virtual void exitStatement_eof(Grammar_WithConceptsAntlrParser::Statement_eofContext * /*ctx*/) override { }

  virtual void enterStatement(Grammar_WithConceptsAntlrParser::StatementContext * /*ctx*/) override { }
  virtual void exitStatement(Grammar_WithConceptsAntlrParser::StatementContext * /*ctx*/) override { }

  virtual void enterForControl_eof(Grammar_WithConceptsAntlrParser::ForControl_eofContext * /*ctx*/) override { }
  virtual void exitForControl_eof(Grammar_WithConceptsAntlrParser::ForControl_eofContext * /*ctx*/) override { }

  virtual void enterForControl(Grammar_WithConceptsAntlrParser::ForControlContext * /*ctx*/) override { }
  virtual void exitForControl(Grammar_WithConceptsAntlrParser::ForControlContext * /*ctx*/) override { }

  virtual void enterForInit_eof(Grammar_WithConceptsAntlrParser::ForInit_eofContext * /*ctx*/) override { }
  virtual void exitForInit_eof(Grammar_WithConceptsAntlrParser::ForInit_eofContext * /*ctx*/) override { }

  virtual void enterForInit(Grammar_WithConceptsAntlrParser::ForInitContext * /*ctx*/) override { }
  virtual void exitForInit(Grammar_WithConceptsAntlrParser::ForInitContext * /*ctx*/) override { }

  virtual void enterExceptionHandler_eof(Grammar_WithConceptsAntlrParser::ExceptionHandler_eofContext * /*ctx*/) override { }
  virtual void exitExceptionHandler_eof(Grammar_WithConceptsAntlrParser::ExceptionHandler_eofContext * /*ctx*/) override { }

  virtual void enterExceptionHandler(Grammar_WithConceptsAntlrParser::ExceptionHandlerContext * /*ctx*/) override { }
  virtual void exitExceptionHandler(Grammar_WithConceptsAntlrParser::ExceptionHandlerContext * /*ctx*/) override { }

  virtual void enterFinallyBlock_eof(Grammar_WithConceptsAntlrParser::FinallyBlock_eofContext * /*ctx*/) override { }
  virtual void exitFinallyBlock_eof(Grammar_WithConceptsAntlrParser::FinallyBlock_eofContext * /*ctx*/) override { }

  virtual void enterFinallyBlock(Grammar_WithConceptsAntlrParser::FinallyBlockContext * /*ctx*/) override { }
  virtual void exitFinallyBlock(Grammar_WithConceptsAntlrParser::FinallyBlockContext * /*ctx*/) override { }

  virtual void enterSwitchLabel_eof(Grammar_WithConceptsAntlrParser::SwitchLabel_eofContext * /*ctx*/) override { }
  virtual void exitSwitchLabel_eof(Grammar_WithConceptsAntlrParser::SwitchLabel_eofContext * /*ctx*/) override { }

  virtual void enterSwitchLabel(Grammar_WithConceptsAntlrParser::SwitchLabelContext * /*ctx*/) override { }
  virtual void exitSwitchLabel(Grammar_WithConceptsAntlrParser::SwitchLabelContext * /*ctx*/) override { }

  virtual void enterCreator_eof(Grammar_WithConceptsAntlrParser::Creator_eofContext * /*ctx*/) override { }
  virtual void exitCreator_eof(Grammar_WithConceptsAntlrParser::Creator_eofContext * /*ctx*/) override { }

  virtual void enterCreator(Grammar_WithConceptsAntlrParser::CreatorContext * /*ctx*/) override { }
  virtual void exitCreator(Grammar_WithConceptsAntlrParser::CreatorContext * /*ctx*/) override { }

  virtual void enterArrayDimensionSpecifier_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionSpecifier_eofContext * /*ctx*/) override { }
  virtual void exitArrayDimensionSpecifier_eof(Grammar_WithConceptsAntlrParser::ArrayDimensionSpecifier_eofContext * /*ctx*/) override { }

  virtual void enterArrayDimensionSpecifier(Grammar_WithConceptsAntlrParser::ArrayDimensionSpecifierContext * /*ctx*/) override { }
  virtual void exitArrayDimensionSpecifier(Grammar_WithConceptsAntlrParser::ArrayDimensionSpecifierContext * /*ctx*/) override { }

  virtual void enterProd_eof(Grammar_WithConceptsAntlrParser::Prod_eofContext * /*ctx*/) override { }
  virtual void exitProd_eof(Grammar_WithConceptsAntlrParser::Prod_eofContext * /*ctx*/) override { }

  virtual void enterProd(Grammar_WithConceptsAntlrParser::ProdContext * /*ctx*/) override { }
  virtual void exitProd(Grammar_WithConceptsAntlrParser::ProdContext * /*ctx*/) override { }

  virtual void enterParserProd_eof(Grammar_WithConceptsAntlrParser::ParserProd_eofContext * /*ctx*/) override { }
  virtual void exitParserProd_eof(Grammar_WithConceptsAntlrParser::ParserProd_eofContext * /*ctx*/) override { }

  virtual void enterParserProd(Grammar_WithConceptsAntlrParser::ParserProdContext * /*ctx*/) override { }
  virtual void exitParserProd(Grammar_WithConceptsAntlrParser::ParserProdContext * /*ctx*/) override { }

  virtual void enterRuleComponent_eof(Grammar_WithConceptsAntlrParser::RuleComponent_eofContext * /*ctx*/) override { }
  virtual void exitRuleComponent_eof(Grammar_WithConceptsAntlrParser::RuleComponent_eofContext * /*ctx*/) override { }

  virtual void enterRuleComponent(Grammar_WithConceptsAntlrParser::RuleComponentContext * /*ctx*/) override { }
  virtual void exitRuleComponent(Grammar_WithConceptsAntlrParser::RuleComponentContext * /*ctx*/) override { }

  virtual void enterITerminal_eof(Grammar_WithConceptsAntlrParser::ITerminal_eofContext * /*ctx*/) override { }
  virtual void exitITerminal_eof(Grammar_WithConceptsAntlrParser::ITerminal_eofContext * /*ctx*/) override { }

  virtual void enterITerminal(Grammar_WithConceptsAntlrParser::ITerminalContext * /*ctx*/) override { }
  virtual void exitITerminal(Grammar_WithConceptsAntlrParser::ITerminalContext * /*ctx*/) override { }

  virtual void enterLexComponent_eof(Grammar_WithConceptsAntlrParser::LexComponent_eofContext * /*ctx*/) override { }
  virtual void exitLexComponent_eof(Grammar_WithConceptsAntlrParser::LexComponent_eofContext * /*ctx*/) override { }

  virtual void enterLexComponent(Grammar_WithConceptsAntlrParser::LexComponentContext * /*ctx*/) override { }
  virtual void exitLexComponent(Grammar_WithConceptsAntlrParser::LexComponentContext * /*ctx*/) override { }


  virtual void enterEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void exitEveryRule(antlr4::ParserRuleContext * /*ctx*/) override { }
  virtual void visitTerminal(antlr4::tree::TerminalNode * /*node*/) override { }
  virtual void visitErrorNode(antlr4::tree::ErrorNode * /*node*/) override { }

};

