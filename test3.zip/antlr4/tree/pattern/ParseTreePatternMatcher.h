﻿/* Copyright (c) 2012-2017 The ANTLR Project. All rights reserved.
 * Use of this file is governed by the BSD 3-clause license that
 * can be found in the LICENSE.txt file in the project root.
 */

#pragma once

#include "Exceptions.h"

namespace antlr4 {
namespace tree {
namespace pattern {

  /// <summary>
  /// A tree pattern matching mechanism for ANTLR <seealso cref="ParseTree"/>s.
  /// <p/>
  /// Patterns are strings of source input text with special tags representing
  /// token or rule references such as:
  /// <p/>
  /// {@code <ID> = <expr>;}
  /// <p/>
  /// Given a pattern start rule such as {@code statement}, this object constructs
  /// a <seealso cref="ParseTree"/> with placeholders for the {@code ID} and {@code expr}
  /// subtree. Then the <seealso cref="#match"/> routines can compare an actual
  /// <seealso cref="ParseTree"/> from a parse with this pattern. Tag {@code <ID>} matches
  /// any {@code ID} token and tag {@code <expr>} references the result of the
  /// {@code expr} rule (generally an instance of {@code ExprContext}.
  /// <p/>
  /// Pattern {@code x = 0;} is a similar pattern that matches the same pattern
  /// except that it requires the identifier to be {@code x} and the expression to
  /// be {@code 0}.
  /// <p/>
  /// The <seealso cref="#matches"/> routines return {@code true} or {@code false} based
  /// upon a match for the tree rooted at the parameter sent in. The
  /// <seealso cref="#match"/> routines return a <seealso cref="ParseTreeMatch"/> object that
  /// contains the parse tree, the parse tree pattern, and a map from tag name to
  /// matched nodes (more below). A subtree that fails to match, returns with
  /// <seealso cref="ParseTreeMatch#mismatchedNode"/> set to the first tree node that did not
  /// match.
  /// <p/>
  /// For efficiency, you can compile a tree pattern in string form to a
  /// <seealso cref="ParseTreePattern"/> object.
  /// <p/>
  /// See {@code TestParseTreeMatcher} for lots of examples.
  /// <seealso cref="ParseTreePattern"/> has two static helper methods:
  /// <seealso cref="ParseTreePattern#findAll"/> and <seealso cref="ParseTreePattern#match"/> that
  /// are easy to use but not super efficient because they create new
  /// <seealso cref="ParseTreePatternMatcher"/> objects each time and have to compile the
  /// pattern in string form before using it.
  /// <p/>
  /// The lexer and parser that you pass into the <seealso cref="ParseTreePatternMatcher"/>
  /// constructor are used to parse the pattern in string form. The lexer converts
  /// the {@code <ID> = <expr>;} into a sequence of four tokens (assuming lexer
  /// throws out whitespace or puts it on a hidden channel). Be aware that the
  /// input stream is reset for the lexer (but not the parser; a
  /// <seealso cref="ParserInterpreter"/> is created to parse the input.). Any user-defined
  /// fields you have put into the lexer might get changed when this mechanism asks
  /// it to scan the pattern string.
  /// <p/>
  /// Normally a parser does not accept token {@code <expr>} as a valid
  /// {@code expr} but, from the parser passed in, we create a special version of
  /// the underlying grammar representation (an <seealso cref="ATN"/>) that allows imaginary
  /// tokens representing rules ({@code <expr>}) to match entire rules. We call
  /// these <em>bypass alternatives</em>.
  /// <p/>
  /// Delimiters are {@code <} and {@code >}, with {@code \} as the escape string
  /// by default, but you can set them to whatever you want using
  /// <seealso cref="#setDelimiters"/>. You must escape both start and stop strings
  /// {@code \<} and {@code \>}.
  /// </summary>
  class ANTLR4CPP_PUBLIC ParseTreePatternMatcher {
  public:
    class CannotInvokeStartRule : public RuntimeException {
    public:
      CannotInvokeStartRule(const RuntimeException &e);
      ~CannotInvokeStartRule();
    };

    // Fixes https://github.com/antlr/antlr4/issues/413
    // "Tree pattern compilation doesn't check for a complete parse"
    class StartRuleDoesNotConsumeFullPattern : public RuntimeException {
    public:
      StartRuleDoesNotConsumeFullPattern() = default;
      StartRuleDoesNotConsumeFullPattern(StartRuleDoesNotConsumeFullPattern const&) = default;
      ~StartRuleDoesNotConsumeFullPattern();

      StartRuleDoesNotConsumeFullPattern& operator=(StartRuleDoesNotConsumeFullPattern const&) = default;
    };

    /// Constructs a <seealso cref="ParseTreePatternMatcher"/> or from a <seealso cref="Lexer"/> and
    /// <seealso cref="Parser"/> object. The lexer input stream is altered for tokenizing
    /// the tree patterns. The parser is used as a convenient mechanism to get
    /// the grammar name, plus token, rule names.
    ParseTreePatternMatcher(Lexer *lexer, Parser *parser);
    virtual ~ParseTreePatternMatcher();

    /// <summary>
    /// Set the delimiters used for marking rule and token tags within concrete
    /// syntax used by the tree pattern parser.
    /// </summary>
    /// <param name="start"> The start delimiter. </param>
    /// <param name="stop"> The stop delimiter. </param>
    /// <param name="escapeLeft"> The escape sequence to use for escaping a start or stop delimiter.
    /// </param>
    /// <exception cref="IllegalArgumentException"> if {@code start} is {@code null} or empty. </exception>
    /// <exception cref="IllegalArgumentException"> if {@code stop} is {@code null} or empty. </exception>
    virtual void setDelimiters(const std::string &start, const std::string &stop, const std::string &escapeLeft);

    /// <summary>
    /// Does {@code pattern} matched as rule {@code patternRuleIndex} match {@code tree}? </summary>
    virtual bool matches(ParseTree *tree, const std::string &pattern, int patternRuleIndex);

    /// <summary>
    /// Does {@code pattern} matched as rule patternRuleIndex match tree? Pass in a
    ///  compiled pattern instead of a string representation of a tree pattern.
    /// </summary>
    virtual bool matches(ParseTree *tree, const ParseTreePattern &pattern);

    /// <summary>
    /// Compare {@code pattern} matched as rule {@code patternRuleIndex} against
    /// {@code tree} and return a <seealso cref="ParseTreeMatch"/> object that contains the
    /// matched elements, or the node at which the match failed.
    /// </summary>
    virtual ParseTreeMatch match(ParseTree *tree, const std::string &pattern, int patternRuleIndex);

    /// <summary>
    /// Compare {@code pattern} matched against {@code tree} and return a
    /// <seealso cref="ParseTreeMatch"/> object that contains the matched elements, or the
    /// node at which the match failed. Pass in a compiled pattern instead of a
    /// string representation of a tree pattern.
    /// </summary>
    virtual ParseTreeMatch match(ParseTree *tree, const ParseTreePattern &pattern);

    /// <summary>
    /// For repeated use of a tree pattern, compile it to a
    /// <seealso cref="ParseTreePattern"/> using this method.
    /// </summary>
    virtual ParseTreePattern compile(const std::string &pattern, int patternRuleIndex);

    /// <summary>
    /// Used to convert the tree pattern string into a series of tokens. The
    /// input stream is reset.
    /// </summary>
    virtual Lexer* getLexer();

    /// <summary>
    /// Used to collect to the grammar file name, token names, rule names for
    /// used to parse the pattern into a parse tree.
    /// </summary>
    virtual Parser* getParser();

    // ---- SUPPORT CODE ----

    virtual std::vector<std::unique_ptr<Token>> tokenize(const std::string &pattern);

    /// Split "<ID> = <e:expr>;" into 4 chunks for tokenizing by tokenize().
    virtual std::vector<Chunk> split(const std::string &pattern);

  protected:
    std::string _start;
    std::string _stop;
    std::string _escape; // e.g., \< and \> must escape BOTH!

    /// Recursively walk {@code tree} against {@code patternTree}, filling
    /// {@code match.}<seealso cref="ParseTreeMatch#labels labels"/>.
    ///
    /// <returns> the first node encountered in {@code tree} which does not match
    /// a corresponding node in {@code patternTree}, or {@code null} if the match
    /// was successful. The specific node returned depends on the matching
    /// algorithm used by the implementation, and may be overridden. </returns>
    virtual ParseTree* matchImpl(ParseTree *tree, ParseTree *patternTree, std::map<std::string, std::vector<ParseTree *>> &labels);

    /// Is t <expr> subtree?
    virtual RuleTagToken* getRuleTagToken(ParseTree *t);

  private:
    Lexer *_lexer;
    Parser *_parser;

    void InitializeInstanceFields();
  };

} // namespace pattern
} // namespace tree
} // namespace antlr4
﻿/* Copyright (c) 2012-2017 The ANTLR Project. All rights reserved.
 * Use of this file is governed by the BSD 3-clause license that
 * can be found in the LICENSE.txt file in the project root.
 */

#include "tree/pattern/ParseTreePattern.h"
#include "tree/pattern/ParseTreeMatch.h"
#include "tree/TerminalNode.h"
#include "CommonTokenStream.h"
#include "ParserInterpreter.h"
#include "tree/pattern/TokenTagToken.h"
#include "ParserRuleContext.h"
#include "tree/pattern/RuleTagToken.h"
#include "tree/pattern/TagChunk.h"
#include "atn/ATN.h"
#include "Lexer.h"
#include "BailErrorStrategy.h"

#include "ListTokenSource.h"
#include "tree/pattern/TextChunk.h"
#include "ANTLRInputStream.h"
#include "support/Arrays.h"
#include "Exceptions.h"
#include "support/StringUtils.h"
#include "support/CPPUtils.h"

#include "tree/pattern/ParseTreePatternMatcher.h"

using namespace antlr4;
using namespace antlr4::tree;
using namespace antlr4::tree::pattern;
using namespace antlrcpp;

ParseTreePatternMatcher::CannotInvokeStartRule::CannotInvokeStartRule(const RuntimeException &e) : RuntimeException(e.what()) {
}

ParseTreePatternMatcher::CannotInvokeStartRule::~CannotInvokeStartRule() {
}

ParseTreePatternMatcher::StartRuleDoesNotConsumeFullPattern::~StartRuleDoesNotConsumeFullPattern() {
}

ParseTreePatternMatcher::ParseTreePatternMatcher(Lexer *lexer, Parser *parser) : _lexer(lexer), _parser(parser) {
  InitializeInstanceFields();
}

ParseTreePatternMatcher::~ParseTreePatternMatcher() {
}

void ParseTreePatternMatcher::setDelimiters(const std::string &start, const std::string &stop, const std::string &escapeLeft) {
  if (start.empty()) {
    throw IllegalArgumentException("start cannot be null or empty");
  }

  if (stop.empty()) {
    throw IllegalArgumentException("stop cannot be null or empty");
  }

 _start = start;
  _stop = stop;
  _escape = escapeLeft;
}

bool ParseTreePatternMatcher::matches(ParseTree *tree, const std::string &pattern, int patternRuleIndex) {
  ParseTreePattern p = compile(pattern, patternRuleIndex);
  return matches(tree, p);
}

bool ParseTreePatternMatcher::matches(ParseTree *tree, const ParseTreePattern &pattern) {
  std::map<std::string, std::vector<ParseTree *>> labels;
  ParseTree *mismatchedNode = matchImpl(tree, pattern.getPatternTree(), labels);
  return mismatchedNode == nullptr;
}

ParseTreeMatch ParseTreePatternMatcher::match(ParseTree *tree, const std::string &pattern, int patternRuleIndex) {
  ParseTreePattern p = compile(pattern, patternRuleIndex);
  return match(tree, p);
}

ParseTreeMatch ParseTreePatternMatcher::match(ParseTree *tree, const ParseTreePattern &pattern) {
  std::map<std::string, std::vector<ParseTree *>> labels;
  tree::ParseTree *mismatchedNode = matchImpl(tree, pattern.getPatternTree(), labels);
  return ParseTreeMatch(tree, pattern, labels, mismatchedNode);
}

ParseTreePattern ParseTreePatternMatcher::compile(const std::string &pattern, int patternRuleIndex) {
  ListTokenSource tokenSrc(tokenize(pattern));
  CommonTokenStream tokens(&tokenSrc);

  ParserInterpreter parserInterp(_parser->getGrammarFileName(), _parser->getVocabulary(),
                                 _parser->getRuleNames(), _parser->getATNWithBypassAlts(), &tokens);

  ParserRuleContext *tree = nullptr;
  try {
    parserInterp.setErrorHandler(std::make_shared<BailErrorStrategy>());
    tree = parserInterp.parse(patternRuleIndex);
  } catch (ParseCancellationException &e) {
#if defined(_MSC_FULL_VER) && _MSC_FULL_VER < 190023026
    // rethrow_if_nested is not available before VS 2015.
    throw e;
#else
    std::rethrow_if_nested(e); // Unwrap the nested exception.
#endif
  } catch (RecognitionException &re) {
    throw re;
#if defined(_MSC_FULL_VER) && _MSC_FULL_VER < 190023026
  } catch (std::exception &e) {
    // throw_with_nested is not available before VS 2015.
    throw e;
#else
  } catch (std::exception & /*e*/) {
    std::throw_with_nested((const char*)"Cannot invoke start rule"); // Wrap any other exception. We should however probably use one of the ANTLR exceptions here.
#endif
  }

  // Make sure tree pattern compilation checks for a complete parse
  if (tokens.LA(1) != Token::EOF) {
    throw StartRuleDoesNotConsumeFullPattern();
  }

  return ParseTreePattern(this, pattern, patternRuleIndex, tree);
}

Lexer* ParseTreePatternMatcher::getLexer() {
  return _lexer;
}

Parser* ParseTreePatternMatcher::getParser() {
  return _parser;
}

ParseTree* ParseTreePatternMatcher::matchImpl(ParseTree *tree, ParseTree *patternTree,
                                              std::map<std::string, std::vector<ParseTree *>> &labels) {
  if (tree == nullptr) {
    throw IllegalArgumentException("tree cannot be nul");
  }

  if (patternTree == nullptr) {
    throw IllegalArgumentException("patternTree cannot be nul");
  }

  // x and <ID>, x and y, or x and x; or could be mismatched types
  if (is<TerminalNode *>(tree) && is<TerminalNode *>(patternTree)) {
    TerminalNode *t1 = dynamic_cast<TerminalNode *>(tree);
    TerminalNode *t2 = dynamic_cast<TerminalNode *>(patternTree);

    ParseTree *mismatchedNode = nullptr;
    // both are tokens and they have same type
    if (t1->getSymbol()->getType() == t2->getSymbol()->getType()) {
      if (is<TokenTagToken *>(t2->getSymbol())) { // x and <ID>
        TokenTagToken *tokenTagToken = dynamic_cast<TokenTagToken *>(t2->getSymbol());

        // track label->list-of-nodes for both token name and label (if any)
        labels[tokenTagToken->getTokenName()].push_back(tree);
        if (tokenTagToken->getLabel() != "") {
          labels[tokenTagToken->getLabel()].push_back(tree);
        }
      } else if (t1->getText() == t2->getText()) {
        // x and x
      } else {
        // x and y
        if (mismatchedNode == nullptr) {
          mismatchedNode = t1;
        }
      }
    } else {
      if (mismatchedNode == nullptr) {
        mismatchedNode = t1;
      }
    }

    return mismatchedNode;
  }

  if (is<ParserRuleContext *>(tree) && is<ParserRuleContext *>(patternTree)) {
    ParserRuleContext *r1 = dynamic_cast<ParserRuleContext *>(tree);
    ParserRuleContext *r2 = dynamic_cast<ParserRuleContext *>(patternTree);
    ParseTree *mismatchedNode = nullptr;

    // (expr ...) and <expr>
    RuleTagToken *ruleTagToken = getRuleTagToken(r2);
    if (ruleTagToken != nullptr) {
      //ParseTreeMatch *m = nullptr; // unused?
      if (r1->getRuleIndex() == r2->getRuleIndex()) {
        // track label->list-of-nodes for both rule name and label (if any)
        labels[ruleTagToken->getRuleName()].push_back(tree);
        if (ruleTagToken->getLabel() != "") {
          labels[ruleTagToken->getLabel()].push_back(tree);
        }
      } else {
        if (!mismatchedNode) {
          mismatchedNode = r1;
        }
      }

      return mismatchedNode;
    }

    // (expr ...) and (expr ...)
    if (r1->children.size() != r2->children.size()) {
      if (mismatchedNode == nullptr) {
        mismatchedNode = r1;
      }

      return mismatchedNode;
    }

    std::size_t n = r1->children.size();
    for (size_t i = 0; i < n; i++) {
      ParseTree *childMatch = matchImpl(r1->children[i], patternTree->children[i], labels);
      if (childMatch) {
        return childMatch;
      }
    }

    return mismatchedNode;
  }

  // if nodes aren't both tokens or both rule nodes, can't match
  return tree;
}

RuleTagToken* ParseTreePatternMatcher::getRuleTagToken(ParseTree *t) {
  if (t->children.size() == 1 && is<TerminalNode *>(t->children[0])) {
    TerminalNode *c = dynamic_cast<TerminalNode *>(t->children[0]);
    if (is<RuleTagToken *>(c->getSymbol())) {
      return dynamic_cast<RuleTagToken *>(c->getSymbol());
    }
  }
  return nullptr;
}

std::vector<std::unique_ptr<Token>> ParseTreePatternMatcher::tokenize(const std::string &pattern) {
  // split pattern into chunks: sea (raw input) and islands (<ID>, <expr>)
  std::vector<Chunk> chunks = split(pattern);

  // create token stream from text and tags
  std::vector<std::unique_ptr<Token>> tokens;
  for (auto chunk : chunks) {
    if (is<TagChunk *>(&chunk)) {
      TagChunk &tagChunk = (TagChunk&)chunk;
      // add special rule token or conjure up new token from name
      if (isupper(tagChunk.getTag()[0])) {
        size_t ttype = _parser->getTokenType(tagChunk.getTag());
        if (ttype == Token::INVALID_TYPE) {
          throw IllegalArgumentException("Unknown token " + tagChunk.getTag() + " in pattern: " + pattern);
        }
        tokens.emplace_back(new TokenTagToken(tagChunk.getTag(), (int)ttype, tagChunk.getLabel()));
      } else if (islower(tagChunk.getTag()[0])) {
        size_t ruleIndex = _parser->getRuleIndex(tagChunk.getTag());
        if (ruleIndex == INVALID_INDEX) {
          throw IllegalArgumentException("Unknown rule " + tagChunk.getTag() + " in pattern: " + pattern);
        }
        size_t ruleImaginaryTokenType = _parser->getATNWithBypassAlts().ruleToTokenType[ruleIndex];
        tokens.emplace_back(new RuleTagToken(tagChunk.getTag(), ruleImaginaryTokenType, tagChunk.getLabel()));
      } else {
        throw IllegalArgumentException("invalid tag: " + tagChunk.getTag() + " in pattern: " + pattern);
      }
    } else {
      TextChunk &textChunk = (TextChunk&)chunk;
      ANTLRInputStream input(textChunk.getText());
      _lexer->setInputStream(&input);
      std::unique_ptr<Token> t(_lexer->nextToken());
      while (t->getType() != Token::EOF) {
        tokens.push_back(std::move(t));
        t = _lexer->nextToken();
      }
      _lexer->setInputStream(nullptr);
    }
  }

  return tokens;
}

std::vector<Chunk> ParseTreePatternMatcher::split(const std::string &pattern) {
  size_t p = 0;
  size_t n = pattern.length();
  std::vector<Chunk> chunks;

  // find all start and stop indexes first, then collect
  std::vector<size_t> starts;
  std::vector<size_t> stops;
  while (p < n) {
    if (p == pattern.find(_escape + _start,p)) {
      p += _escape.length() + _start.length();
    } else if (p == pattern.find(_escape + _stop,p)) {
      p += _escape.length() + _stop.length();
    } else if (p == pattern.find(_start,p)) {
      starts.push_back(p);
      p += _start.length();
    } else if (p == pattern.find(_stop,p)) {
      stops.push_back(p);
      p += _stop.length();
    } else {
      p++;
    }
  }

  if (starts.size() > stops.size()) {
    throw IllegalArgumentException("unterminated tag in pattern: " + pattern);
  }

  if (starts.size() < stops.size()) {
    throw IllegalArgumentException("missing start tag in pattern: " + pattern);
  }

  size_t ntags = starts.size();
  for (size_t i = 0; i < ntags; i++) {
    if (starts[i] >= stops[i]) {
      throw IllegalArgumentException("tag delimiters out of order in pattern: " + pattern);
    }
  }

  // collect into chunks now
  if (ntags == 0) {
    std::string text = pattern.substr(0, n);
    chunks.push_back(TextChunk(text));
  }

  if (ntags > 0 && starts[0] > 0) { // copy text up to first tag into chunks
    std::string text = pattern.substr(0, starts[0]);
    chunks.push_back(TextChunk(text));
  }

  for (size_t i = 0; i < ntags; i++) {
    // copy inside of <tag>
    std::string tag = pattern.substr(starts[i] + _start.length(), stops[i] - (starts[i] + _start.length()));
    std::string ruleOrToken = tag;
    std::string label = "";
    size_t colon = tag.find(':');
    if (colon != std::string::npos) {
      label = tag.substr(0,colon);
      ruleOrToken = tag.substr(colon + 1, tag.length() - (colon + 1));
    }
    chunks.push_back(TagChunk(label, ruleOrToken));
    if (i + 1 < ntags) {
      // copy from end of <tag> to start of next
      std::string text = pattern.substr(stops[i] + _stop.length(), starts[i + 1] - (stops[i] + _stop.length()));
      chunks.push_back(TextChunk(text));
    }
  }

  if (ntags > 0) {
    size_t afterLastTag = stops[ntags - 1] + _stop.length();
    if (afterLastTag < n) { // copy text from end of last tag to end
      std::string text = pattern.substr(afterLastTag, n - afterLastTag);
      chunks.push_back(TextChunk(text));
    }
  }

  // strip out all backslashes from text chunks but not tags
  for (size_t i = 0; i < chunks.size(); i++) {
    Chunk &c = chunks[i];
    if (is<TextChunk *>(&c)) {
      TextChunk &tc = (TextChunk&)c;
      std::string unescaped = tc.getText();
      unescaped.erase(std::remove(unescaped.begin(), unescaped.end(), '\\'), unescaped.end());
      if (unescaped.length() < tc.getText().length()) {
        chunks[i] = TextChunk(unescaped);
      }
    }
  }

  return chunks;
}

void ParseTreePatternMatcher::InitializeInstanceFields() {
  _start = "<";
  _stop = ">";
  _escape = "\\";
}
