﻿/* Copyright (c) 2012-2017 The ANTLR Project. All rights reserved.
 * Use of this file is governed by the BSD 3-clause license that
 * can be found in the LICENSE.txt file in the project root.
 */

#pragma once

#include "atn/Transition.h"

namespace antlr4 {
namespace atn {

  class ANTLR4CPP_PUBLIC RuleTransition : public Transition {
  public:
    /// Ptr to the rule definition object for this rule ref.
    const size_t ruleIndex; // no Rule object at runtime

    const int precedence;

    /// What node to begin computations following ref to rule.
    ATNState *followState;

    /// @deprecated Use
    /// <seealso cref="#RuleTransition(RuleStartState, size_t, int, ATNState)"/> instead.
    RuleTransition(RuleStartState *ruleStart, size_t ruleIndex, ATNState *followState);

    RuleTransition(RuleStartState *ruleStart, size_t ruleIndex, int precedence, ATNState *followState);
    RuleTransition(RuleTransition const&) = delete;
    RuleTransition& operator=(RuleTransition const&) = delete;

    virtual SerializationType getSerializationType() const override;

    virtual bool isEpsilon() const override;
    virtual bool matches(size_t symbol, size_t minVocabSymbol, size_t maxVocabSymbol) const override;

    virtual std::string toString() const override;
  };

} // namespace atn
} // namespace antlr4
﻿/* Copyright (c) 2012-2017 The ANTLR Project. All rights reserved.
 * Use of this file is governed by the BSD 3-clause license that
 * can be found in the LICENSE.txt file in the project root.
 */

#include "atn/RuleStartState.h"
#include "atn/RuleTransition.h"

using namespace antlr4::atn;

RuleTransition::RuleTransition(RuleStartState *ruleStart, size_t ruleIndex, ATNState *followState)
  : RuleTransition(ruleStart, ruleIndex, 0, followState) {
}

RuleTransition::RuleTransition(RuleStartState *ruleStart, size_t ruleIndex, int precedence, ATNState *followState)
  : Transition(ruleStart), ruleIndex(ruleIndex), precedence(precedence) {
  this->followState = followState;
}

Transition::SerializationType RuleTransition::getSerializationType() const {
  return RULE;
}

bool RuleTransition::isEpsilon() const {
  return true;
}

bool RuleTransition::matches(size_t /*symbol*/, size_t /*minVocabSymbol*/, size_t /*maxVocabSymbol*/) const {
  return false;
}

std::string RuleTransition::toString() const {
  std::stringstream ss;
  ss << "RULE " << Transition::toString() << " { ruleIndex: " << ruleIndex << ", precedence: " << precedence <<
    ", followState: " << std::hex << followState << " }";
  return ss.str();
}
