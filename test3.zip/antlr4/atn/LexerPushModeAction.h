/* Copyright (c) 2012-2017 The ANTLR Project. All rights reserved.
 * Use of this file is governed by the BSD 3-clause license that
 * can be found in the LICENSE.txt file in the project root.
 */

#pragma once

#include "atn/LexerAction.h"
#include "atn/LexerActionType.h"

namespace antlr4 {
namespace atn {

  /// <summary>
  /// Implements the {@code pushMode} lexer action by calling
  /// <seealso cref="Lexer#pushMode"/> with the assigned mode.
  ///
  /// @author Sam Harwell
  /// @since 4.2
  /// </summary>
  class ANTLR4CPP_PUBLIC LexerPushModeAction final : public LexerAction {
  public:
    /// <summary>
    /// Constructs a new {@code pushMode} action with the specified mode value. </summary>
    /// <param name="mode"> The mode value to pass to <seealso cref="Lexer#pushMode"/>. </param>
    LexerPushModeAction(int mode);

    /// <summary>
    /// Get the lexer mode this action should transition the lexer to.
    /// </summary>
    /// <returns> The lexer mode for this {@code pushMode} command. </returns>
    int getMode() const;

    /// <summary>
    /// {@inheritDoc} </summary>
    /// <returns> This method returns <seealso cref="LexerActionType#PUSH_MODE"/>. </returns>
    virtual LexerActionType getActionType() const override;

    /// <summary>
    /// {@inheritDoc} </summary>
    /// <returns> This method returns {@code false}. </returns>
    virtual bool isPositionDependent() const override;

    /// <summary>
    /// {@inheritDoc}
    ///
    /// <para>This action is implemented by calling <seealso cref="Lexer#pushMode"/> with the
    /// value provided by <seealso cref="#getMode"/>.</para>
    /// </summary>
    virtual void execute(Lexer *lexer) override;

    virtual size_t hashCode() const override;
    virtual bool operator == (const LexerAction &obj) const override;
    virtual std::string toString() const override;

  private:
    const int _mode;
  };

} // namespace atn
} // namespace antlr4
/* Copyright (c) 2012-2017 The ANTLR Project. All rights reserved.
 * Use of this file is governed by the BSD 3-clause license that
 * can be found in the LICENSE.txt file in the project root.
 */

#include "misc/MurmurHash.h"
#include "Lexer.h"

#include "atn/LexerPushModeAction.h"

using namespace antlr4;
using namespace antlr4::atn;
using namespace antlr4::misc;

LexerPushModeAction::LexerPushModeAction(int mode) : _mode(mode) {
}

int LexerPushModeAction::getMode() const {
  return _mode;
}

LexerActionType LexerPushModeAction::getActionType() const {
  return LexerActionType::PUSH_MODE;
}

bool LexerPushModeAction::isPositionDependent() const {
  return false;
}

void LexerPushModeAction::execute(Lexer *lexer) {
  lexer->pushMode(_mode);
}

size_t LexerPushModeAction::hashCode() const {
  size_t hash = MurmurHash::initialize();
  hash = MurmurHash::update(hash, static_cast<size_t>(getActionType()));
  hash = MurmurHash::update(hash, _mode);
  return MurmurHash::finish(hash, 2);
}

bool LexerPushModeAction::operator == (const LexerAction &obj) const {
  if (&obj == this) {
    return true;
  }

  const LexerPushModeAction *action = dynamic_cast<const LexerPushModeAction *>(&obj);
  if (action == nullptr) {
    return false;
  }

  return _mode == action->_mode;
}

std::string LexerPushModeAction::toString() const {
  return "pushMode(" + std::to_string(_mode) + ")";
}
