#pragma once
#ifndef MC_OUTLINE_LISTENER_H
#define MC_OUTLINE_LISTENER_H

#include "common/features/outline/OutlineListener.h"

#include <Grammar_WithConceptsAntlrBaseListener.h>

using common::OutlineListener;

namespace monticore {
	class MCOutlineListener : public OutlineListener, public Grammar_WithConceptsAntlrBaseListener {};
}

#endif 