#pragma once
#ifndef COMMON_OUTLINE_LISTENER_H
#define COMMON_OUTLINE_LISTENER_H

#include "OutlineItem.h"
#include <emscripten/val.h>

using std::stack;
using emscripten::val;

namespace common {
    class OutlineListener {
        protected:
            stack<OutlineItem*> items;
        
        public:
            virtual ~OutlineListener();

            virtual val getOutline() const;
    };
}

#endif 

using common::OutlineListener;

OutlineListener::~OutlineListener() {
    while(this->items.empty() == false) {
        OutlineItem* item = this->items.top();
        
        //this->items.pop();
        delete item;
    }
}

val OutlineListener::getOutline() const {
    val result = val::array();

    if(this->items.size() > 0) {
        val item = this->items.top()->toJSON();
        result.set(0, item);
    }

    return result;
}