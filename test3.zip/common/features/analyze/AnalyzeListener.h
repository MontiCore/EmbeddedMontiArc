#pragma once
#ifndef COMMON_ANALYZE_LISTENER_H
#define COMMON_ANALYZE_LISTENER_H

#include <antlr4-runtime.h>
#include <emscripten/val.h>

#include "common/features/parse/SyntaxError.h"

using antlr4::ANTLRErrorListener;
using antlr4::Recognizer;
using antlr4::Token;
using antlr4::Parser;
using antlr4::atn::ATNConfigSet;
using antlr4::dfa::DFA;

using antlrcpp::BitSet;

using std::string;
using std::exception_ptr;
using std::list;

using emscripten::val;
using common::SyntaxError;

namespace common {
    class AnalyzeListener : public ANTLRErrorListener {
        private:
            list<SyntaxError*> errors;

        public:
            virtual ~AnalyzeListener();

            virtual void syntaxError(Recognizer *recognizer, Token *offendingSymbol, size_t line,
                size_t charPositionInLine, const string &msg, exception_ptr e) override;
            virtual void reportAmbiguity(Parser *recognizer, const DFA &dfa, size_t startIndex, size_t stopIndex, bool exact,
                const BitSet &ambigAlts, ATNConfigSet *configs) override;
            virtual void reportAttemptingFullContext(Parser *recognizer, const DFA &dfa, size_t startIndex, size_t stopIndex,
                const BitSet &conflictingAlts, ATNConfigSet *configs) override;
            virtual void reportContextSensitivity(Parser *recognizer, const DFA &dfa, size_t startIndex, size_t stopIndex,
                size_t prediction, ATNConfigSet *configs) override;
            
            virtual val getAnalyzes() const;
    };
}

#endif 

using common::AnalyzeListener;
using common::Position;
using common::SyntaxError;

using antlr4::Recognizer;
using antlr4::Token;
using antlr4::Parser;
using antlr4::atn::ATNConfigSet;
using antlr4::dfa::DFA;

using antlrcpp::BitSet;

using emscripten::val;

using std::string;
using std::list;
using std::exception_ptr;

AnalyzeListener::~AnalyzeListener() {
    for(SyntaxError* const &i : this->errors) {
        this->errors.remove(i);
        delete i;
    }
}

void AnalyzeListener::syntaxError(Recognizer *recognizer, Token *offendingSymbol, size_t line,
        size_t charPositionInLine, const string &msg, exception_ptr e) {
    size_t endColumn = charPositionInLine + offendingSymbol->getText().length();
    Position* position = new Position(line, line, charPositionInLine, endColumn); 
    SyntaxError* error = new SyntaxError(position, msg);

    this->errors.push_back(error);
}

void AnalyzeListener::reportAmbiguity(Parser *recognizer, const DFA &dfa, size_t startIndex, size_t stopIndex, bool exact,
        const BitSet &ambigAlts, ATNConfigSet *configs) {}

void AnalyzeListener::reportAttemptingFullContext(Parser *recognizer, const DFA &dfa, size_t startIndex, size_t stopIndex,
        const BitSet &conflictingAlts, ATNConfigSet *configs) {}

void AnalyzeListener::reportContextSensitivity(Parser *recognizer, const DFA &dfa, size_t startIndex, size_t stopIndex,
        size_t prediction, ATNConfigSet *configs) {}

val AnalyzeListener::getAnalyzes() const {
    val result = val::array();
    int index = 0;

    for(SyntaxError* const &i : this->errors) {
        result.set(index, i->toJSON());
        index++;
    }

    return result;
}