 .table {
        display: table;
        border-collapse: separate;
        border-spacing: 10px 50px;
    }
    .tableRow {
        display: table-row;
    }
    .tableCell {
        display: table-cell;
        vertical-align: top;
    }
    .box {
        border: 10px solid rgba(238, 238, 238, 0.6);
        background-color: rgba(238, 238, 238, 0.2);
    }