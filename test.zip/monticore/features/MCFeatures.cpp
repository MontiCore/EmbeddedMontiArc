#include <antlr4-runtime.h>

#include <emscripten.h>
#include <emscripten/val.h>
#include <emscripten/bind.h>

#include "MCFeatures.h"

#include <Grammar_WithConceptsAntlrLexer.h>
#include <Grammar_WithConceptsAntlrParser.h>

#include "common/features/analyze/AnalyzeListener.h"
#include "common/features/parse/ParseResultCache.h"
#include "common/features/parse/ParseResult.h"

#include "monticore/features/outline/MCOutlineListener.h"

using std::string;
using std::wstring;

using emscripten::val;
using emscripten::function;

using common::AnalyzeListener;
using common::ParseResultCache;
using common::ParseResult;

using monticore::MCFeatures;
using monticore::MCOutlineListener;

using antlr4::tree::ParseTreeWalker;
using antlr4::ANTLRInputStream;
using antlr4::CommonTokenStream;

using antlrcpp::ws2s;

using MCGrammarContext = Grammar_WithConceptsAntlrParser::MCGrammarContext;

void MCFeatures::parse(const wstring &docValue) {
    string input = ws2s(docValue);

    ANTLRInputStream stream(input);
    Grammar_WithConceptsAntlrLexer lexer(&stream);
    CommonTokenStream tokens(&lexer);
    Grammar_WithConceptsAntlrParser parser(&tokens);

    AnalyzeListener* analyzeListener = new AnalyzeListener();
    MCOutlineListener* outlineListener = new MCOutlineListener();

    parser.addErrorListener(analyzeListener);

    MCGrammarContext* ctx = parser.mCGrammar();

    ParseTreeWalker::DEFAULT.walk(outlineListener, ctx);

    ParseResult* result = new ParseResult(analyzeListener, outlineListener);

    ParseResultCache::set(result);
}

val MCFeatures::analyze() {
    ParseResult* result = ParseResultCache::get();
    AnalyzeListener* listener = result->getAnalyzeListener();

    return listener->getAnalyzes();
}

val MCFeatures::outline() {
    ParseResult* result = ParseResultCache::get();
    OutlineListener* listener = result->getOutlineListener();

    return listener->getOutline();
}

EMSCRIPTEN_BINDINGS(mcfeatures) {
    function("parse", &(MCFeatures::parse));
    function("analyze", &(MCFeatures::analyze));
    function("outline", &(MCFeatures::outline));
}