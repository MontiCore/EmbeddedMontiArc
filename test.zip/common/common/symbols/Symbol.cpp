#include "Symbol.h"

using common::Symbol;
using common::Position;

using std::string;
using std::shared_ptr;

Symbol::Symbol(string identifier, string package, string kind, shared_ptr<Position> position) {
	this->identifier = identifier;
	this->package = package;
	this->kind = kind;
	this->position = position;
}

Symbol::~Symbol() = default;

string Symbol::getIdentifier() const {
	return this->identifier;
}

string Symbol::getPackage() const {
	return this->package;
}

string Symbol::getKind() const {
	return this->kind;
}

shared_ptr<Position> Symbol::getPosition() const {
	return this->position;
}

val Symbol::toSQL() const {
	val result = val::object();

	val identifier = val(this->identifier);
	val package = val(this->package);
	val kind = val(this->kind);
	val position = this->position->toJSON();

	result.set("identifier", identifier);
	result.set("package", package);
	result.set("kind", kind);
	result.set("position", position);

	return result;
}