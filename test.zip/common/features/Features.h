#pragma once
#ifndef COMMON_FEATURES_H
#define COMMON_FEATURES_H

#include <emscripten/val.h>

using emscripten::val;
using std::string;
using EmbeddedMontiArcMathAntlrParser::EMAMCompilationUnitContext;

namespace common {
    class Features {
        public:
            virtual EMAMCompilationUnitContext* parse(const string &input) = 0;
            virtual val analyze(const string &input) = 0;
    };
}

#endif