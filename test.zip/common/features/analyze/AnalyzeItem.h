#pragma once
#ifndef COMMON_ANALYZE_ITEM_H
#define COMMON_ANALYZE_ITEM_H

#include <iostream>
#include <emscripten/val.h>

#include "common/features/shared/Position.h"

using emscripten::val;
using std::string;

namespace common {
    class AnalyzeItem {
        protected:
            Position* position;
            string type;
            string message;
        public:
            AnalyzeItem(Position* position, string type, string message);
            virtual ~AnalyzeItem();
            virtual Position* getPosition() const;
            virtual string getType() const;
            virtual string getMessage() const;
            virtual val toJSON() const;
            virtual string toString() const;
    };
}

#endif