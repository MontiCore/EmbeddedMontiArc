#pragma once
#ifndef COMMON_POSITION_H
#define COMMON_POSITION_H

#include <iostream>
#include <emscripten/val.h>
#include <misc/Interval.h>

using antlr4::misc::Interval;
using emscripten::val;
using std::string;

namespace common {
    class Position {
        private:
            Interval* line;
            Interval* column;
            virtual int getStartLineAsInt() const;
            virtual int getEndLineAsInt() const;
            virtual int getStartColumnAsInt() const;
            virtual int getEndColumnAsInt() const;
        public:
            Position();
            Position(Interval* line, Interval* column);
            Position(size_t startLine, size_t endLine, size_t startColumn, size_t endColumn);
            virtual ~Position();
            
            virtual void setLineInterval(Interval* line);
            virtual Interval* getLineInterval() const;

            virtual void setColumnInterval(Interval* column);
            virtual Interval* getColumnInterval() const;

            virtual void setStartLine(size_t startLine);
            virtual size_t getStartLine() const;

            virtual void setEndLine(size_t endLine);
            virtual size_t getEndLine() const;

            virtual void setStartColumn(size_t startColumn);
            virtual size_t getStartColumn() const;

            virtual void setEndColumn(size_t endColumn);
            virtual size_t getEndColumn() const;

            virtual val toJSON() const;
            virtual string toString() const;
    };
}

#endif