#pragma once
#ifndef COMMON_PARSE_RESULT_CACHE_H
#define COMMON_PARSE_RESULT_CACHE_H

#include "ParseResult.h"

namespace common {
    class ParseResultCache {
        private:
            ParseResultCache();

            ParseResult* result;
        public:
            virtual ~ParseResultCache();

            static ParseResultCache& getInstance();

            static void set(ParseResult* result);
            virtual void doSet(ParseResult* result);

            static ParseResult* get(); 
            virtual ParseResult* doGet();
    };
}

#endif