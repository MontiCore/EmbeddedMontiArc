
// Generated from Grammar_WithConceptsAntlr.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"




class  Grammar_WithConceptsAntlrLexer : public antlr4::Lexer {
public:
  enum {
    T__0 = 1, T__1 = 2, T__2 = 3, T__3 = 4, T__4 = 5, T__5 = 6, T__6 = 7, 
    T__7 = 8, T__8 = 9, T__9 = 10, T__10 = 11, T__11 = 12, T__12 = 13, T__13 = 14, 
    T__14 = 15, T__15 = 16, T__16 = 17, T__17 = 18, T__18 = 19, T__19 = 20, 
    T__20 = 21, T__21 = 22, T__22 = 23, T__23 = 24, T__24 = 25, T__25 = 26, 
    T__26 = 27, T__27 = 28, T__28 = 29, T__29 = 30, T__30 = 31, T__31 = 32, 
    T__32 = 33, T__33 = 34, T__34 = 35, T__35 = 36, T__36 = 37, T__37 = 38, 
    T__38 = 39, T__39 = 40, T__40 = 41, T__41 = 42, T__42 = 43, T__43 = 44, 
    T__44 = 45, T__45 = 46, T__46 = 47, T__47 = 48, T__48 = 49, T__49 = 50, 
    T__50 = 51, T__51 = 52, T__52 = 53, T__53 = 54, T__54 = 55, T__55 = 56, 
    T__56 = 57, T__57 = 58, T__58 = 59, T__59 = 60, T__60 = 61, T__61 = 62, 
    T__62 = 63, T__63 = 64, T__64 = 65, T__65 = 66, T__66 = 67, T__67 = 68, 
    T__68 = 69, T__69 = 70, T__70 = 71, T__71 = 72, T__72 = 73, T__73 = 74, 
    T__74 = 75, T__75 = 76, T__76 = 77, T__77 = 78, T__78 = 79, AT = 80, 
    PIPEPIPE = 81, POINTPOINT = 82, ANDAND = 83, LTEQUALS = 84, PIPEEQUALS = 85, 
    STAREQUALS = 86, ANDEQUALS = 87, LBRACK = 88, RBRACK = 89, ROOF = 90, 
    ROOFEQUALS = 91, PLUSPLUS = 92, MINUSMINUS = 93, EQUALSEQUALS = 94, 
    EXCLAMATIONMARK = 95, GTGTGTEQUALS = 96, PERCENT = 97, AND = 98, LPAREN = 99, 
    RPAREN = 100, STAR = 101, PLUS = 102, COMMA = 103, MINUS = 104, POINT = 105, 
    POINTPOINTPOINT = 106, SLASHEQUALS = 107, SLASH = 108, MINUSEQUALS = 109, 
    MINUSGT = 110, PLUSEQUALS = 111, PERCENTEQUALS = 112, COLON = 113, LCURLY = 114, 
    SEMI = 115, LT = 116, PIPE = 117, EXCLAMATIONMARKEQUALS = 118, RCURLY = 119, 
    EQUALS = 120, GTGTEQUALS = 121, LTLTEQUALS = 122, GT = 123, TILDE = 124, 
    QUESTION = 125, GTEQUALS = 126, Name = 127, WS = 128, SL_COMMENT = 129, 
    ML_COMMENT = 130, Num_Int = 131, Num_Long = 132, Num_Float = 133, Num_Double = 134, 
    Char = 135, String = 136
  };

  Grammar_WithConceptsAntlrLexer(antlr4::CharStream *input);
  ~Grammar_WithConceptsAntlrLexer();






  virtual std::string getGrammarFileName() const override;
  virtual const std::vector<std::string>& getRuleNames() const override;

  virtual const std::vector<std::string>& getChannelNames() const override;
  virtual const std::vector<std::string>& getModeNames() const override;
  virtual const std::vector<std::string>& getTokenNames() const override; // deprecated, use vocabulary instead
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;

  virtual const std::vector<uint16_t> getSerializedATN() const override;
  virtual const antlr4::atn::ATN& getATN() const override;

  virtual bool sempred(antlr4::RuleContext *_localctx, size_t ruleIndex, size_t predicateIndex) override;

private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;
  static std::vector<std::string> _channelNames;
  static std::vector<std::string> _modeNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;


  // Individual action functions triggered by action() above.

  // Individual semantic predicate functions triggered by sempred() above.
  bool ML_COMMENTSempred(antlr4::RuleContext *_localctx, size_t predicateIndex);

  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

