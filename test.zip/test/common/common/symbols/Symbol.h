#pragma once
#ifndef COMMON_SYMBOL_H
#define COMMON_SYMBOL_H

#include <iostream>
#include <emscripten/val.h>

#include "common/features/shared/Position.h"

using common::Position;

using emscripten::val;

using std::string;
using std::shared_ptr;

namespace common {
	class Symbol {
		protected:
			string identifier;
			string package;
			string kind;
			shared_ptr<Position> position;
		public:
			Symbol(string, string, string, shared_ptr<Position>);
			virtual ~Symbol();

			virtual string getIdentifier() const;
			virtual string getPackage() const;
			virtual string getKind() const;
			virtual shared_ptr<Position> getPosition() const;

			virtual val toSQL() const;
	};
}

#endif