#include "AnalyzeListener.h"

using common::AnalyzeListener;
using common::Position;
using common::SyntaxError;

using antlr4::Recognizer;
using antlr4::Token;
using antlr4::Parser;
using antlr4::atn::ATNConfigSet;
using antlr4::dfa::DFA;

using antlrcpp::BitSet;

using emscripten::val;

using std::string;
using std::list;
using std::exception_ptr;

AnalyzeListener::~AnalyzeListener() {
    for(SyntaxError* const &i : this->errors) {
        this->errors.remove(i);
        delete i;
    }
}

void AnalyzeListener::syntaxError(Recognizer *recognizer, Token *offendingSymbol, size_t line,
        size_t charPositionInLine, const string &msg, exception_ptr e) {
    size_t endColumn = charPositionInLine + offendingSymbol->getText().length();
    Position* position = new Position(line, line, charPositionInLine, endColumn); 
    SyntaxError* error = new SyntaxError(position, msg);

    this->errors.push_back(error);
}

void AnalyzeListener::reportAmbiguity(Parser *recognizer, const DFA &dfa, size_t startIndex, size_t stopIndex, bool exact,
        const BitSet &ambigAlts, ATNConfigSet *configs) {}

void AnalyzeListener::reportAttemptingFullContext(Parser *recognizer, const DFA &dfa, size_t startIndex, size_t stopIndex,
        const BitSet &conflictingAlts, ATNConfigSet *configs) {}

void AnalyzeListener::reportContextSensitivity(Parser *recognizer, const DFA &dfa, size_t startIndex, size_t stopIndex,
        size_t prediction, ATNConfigSet *configs) {}

val AnalyzeListener::getAnalyzes() const {
    val result = val::array();
    int index = 0;

    for(SyntaxError* const &i : this->errors) {
        result.set(index, i->toJSON());
        index++;
    }

    return result;
}