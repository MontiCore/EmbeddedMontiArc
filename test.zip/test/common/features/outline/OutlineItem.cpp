#include "OutlineItem.h"

using common::OutlineItem;
using common::Position;

using std::string;
using std::stringstream;
using std::list;

using emscripten::val;

OutlineItem::OutlineItem() : OutlineItem::OutlineItem("", "", nullptr, nullptr, list<OutlineItem*>(), true) {}

OutlineItem::OutlineItem(string icon, string name, Position* position, Position* displayPosition, list<OutlineItem*> items, bool unordered) {
    this->icon = icon;
    this->name = name;
    this->position = position;
    this->displayPosition = displayPosition;
    this->items = items;
    this->unordered = unordered;
}

OutlineItem::~OutlineItem() {
    delete this->position;
    delete this->displayPosition;
}

string OutlineItem::getIcon() const {
    return this->icon;
}

string OutlineItem::getName() const {
    return this->name;
}

Position* OutlineItem::getPosition() const {
    return this->position;
}

void OutlineItem::setPosition(Position* position) {
    this->position = position;
}

Position* OutlineItem::getDisplayPosition() const {
    return this->displayPosition;
}

void OutlineItem::setDisplayPosition(Position* displayPosition) {
    this->displayPosition = displayPosition;
} 

list<OutlineItem*> OutlineItem::getItems() const {
    return this->items;
}

void OutlineItem::addItem(OutlineItem* item) {
    this->items.push_back(item);
}

bool OutlineItem::isUnordered() const {
    return this->unordered;
}

val OutlineItem::toJSON() const {
    val item = val::object();
    val items = val::array();
    
    string icon = this->getIcon();
    string name = this->getName();

    val position = this->getPosition()->toJSON();
    val displayPosition = this->getDisplayPosition()->toJSON();

    int index = 0;

    for(OutlineItem* const &i : this->items) {
        items.set(index, i->toJSON());
        index++;
    }

    bool unordered = this->isUnordered();

    item.set("icon", val(icon));
    item.set("name", val(name));
    item.set("pos", position);
    item.set("displayPos", displayPosition);
    item.set("items", items);
    item.set("isUnordered", val(unordered));

    return item;
}

string OutlineItem::toString() const {
    stringstream stream;
    stringstream items;

    stream << "{";
    stream << "icon:" + this->getIcon();
    stream << ",";
    stream << "name:" + this->getName();
    stream << ",";
    stream << "position:" + this->getPosition()->toString();
    stream << ",";
    stream << "displayPosition:" + this->getDisplayPosition()->toString();
    stream << ",";

    items << "[";
    for(OutlineItem* const &i : this->items) {
        items << i->toString();
        items << ",";
    }
    items << "]";

    stream << "items:" + items.str();
    stream << ",";
    stream << "unordered:";
    stream << (this->isUnordered() ? "true" : "false");
    stream << "}";
    
    return stream.str();
}