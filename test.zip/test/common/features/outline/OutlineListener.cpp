#include "OutlineListener.h"

using common::OutlineListener;

OutlineListener::~OutlineListener() {
    while(this->items.empty() == false) {
        OutlineItem* item = this->items.top();
        
        //this->items.pop();
        delete item;
    }
}

val OutlineListener::getOutline() const {
    val result = val::array();

    if(this->items.size() > 0) {
        val item = this->items.top()->toJSON();
        result.set(0, item);
    }

    return result;
}