#pragma once
#ifndef COMMON_OUTLINE_LISTENER_H
#define COMMON_OUTLINE_LISTENER_H

#include "OutlineItem.h"
#include <emscripten/val.h>

using std::stack;
using emscripten::val;

namespace common {
    class OutlineListener {
        protected:
            stack<OutlineItem*> items;
        
        public:
            virtual ~OutlineListener();

            virtual val getOutline() const;
    };
}

#endif