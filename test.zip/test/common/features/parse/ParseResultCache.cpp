#include "ParseResultCache.h"

using common::ParseResultCache;
using common::ParseResult;

ParseResultCache::ParseResultCache() {}

ParseResultCache::~ParseResultCache() {
    //delete this->result;
}

ParseResultCache& ParseResultCache::getInstance() {
    static ParseResultCache INSTANCE;
    return INSTANCE;
}

void ParseResultCache::set(ParseResult* result) {
    ParseResultCache::getInstance().doSet(result);
}

void ParseResultCache::doSet(ParseResult* result) {
    //delete this->result;
    this->result = result;
}

ParseResult* ParseResultCache::get() {
    return ParseResultCache::getInstance().doGet();
}

ParseResult* ParseResultCache::doGet() {
    return this->result;
}