#include "ParseResult.h"

using common::ParseResult;
using common::AnalyzeListener;
using common::OutlineListener;

ParseResult::ParseResult(AnalyzeListener* analyzeListener, OutlineListener* outlineListener) {
    this->analyzeListener = analyzeListener;
    this->outlineListener = outlineListener;
}

ParseResult::~ParseResult() {
    //delete this->analyzeListener;
    //delete this->outlineListener;
}

AnalyzeListener* ParseResult::getAnalyzeListener() {
    return this->analyzeListener;
}

OutlineListener* ParseResult::getOutlineListener() {
    return this->outlineListener;
}