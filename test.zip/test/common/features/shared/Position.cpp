#include "Position.h"

using common::Position;
using antlr4::misc::Interval;
using std::string;
using std::to_string;
using std::stringstream;
using emscripten::val;

Position::Position() : Position::Position(0,0,0,0) {}

Position::Position(Interval* line, Interval* column) {
    this->line = line;
    this->column = column;
}

Position::Position(size_t startLine, size_t endLine, size_t startColumn, size_t endColumn) {
    this->line = new Interval(startLine, endLine);
    this->column = new Interval(startColumn, endColumn);
}

Position::~Position() {
    delete this->line;
    delete this->column;
}

void Position::setLineInterval(Interval* line) {
    this->line = line;
}

Interval* Position::getLineInterval() const {
    return this->line;
}

void Position::setColumnInterval(Interval* column) {
    this->column = column;
}

Interval* Position::getColumnInterval() const {
    return this->column;
}

void Position::setStartLine(size_t startLine) {
    this->line->a = startLine;
}

size_t Position::getStartLine() const {
    Interval* interval = this->getLineInterval();
    return (size_t)interval->a;
}

void Position::setEndLine(size_t endLine) {
    this->line->b = endLine;
}

size_t Position::getEndLine() const {
    Interval* interval = this->getLineInterval();
    return (size_t)interval->b;
}

void Position::setStartColumn(size_t startColumn) {
    this->column->a = startColumn;
}

size_t Position::getStartColumn() const {
    Interval* interval = this->getColumnInterval();
    return (size_t)interval->a;
}

void Position::setEndColumn(size_t endColumn) {
    this->column->b = endColumn;
}

size_t Position::getEndColumn() const {
    Interval* interval = this->getColumnInterval();
    return (size_t)interval->b;
}

int Position::getStartLineAsInt() const {
    size_t startLine = this->getStartLine();
    return static_cast<int>(startLine);
}

int Position::getEndLineAsInt() const {
    size_t endLine = this->getEndLine();
    return static_cast<int>(endLine);
}

int Position::getStartColumnAsInt() const {
    size_t startColumn = this->getStartColumn();
    return static_cast<int>(startColumn);
}

int Position::getEndColumnAsInt() const {
    size_t endColumn = this->getEndColumn();
    return static_cast<int>(endColumn);
}

string Position::toString() const {
    stringstream stream;

    int startLine = this->getStartLineAsInt();
    int endLine = this->getEndLineAsInt();
    int startColumn = this->getStartColumnAsInt();
    int endColumn = this->getEndColumnAsInt();

    stream << "{";
    stream << "sl:" + to_string(startLine);
    stream << ",";
    stream << "el:" + to_string(endLine);
    stream << ",";
    stream << "sc:" + to_string(startColumn);
    stream << ",";
    stream << "ec:" + to_string(endColumn);
    stream << "}";

    return stream.str();
}

val Position::toJSON() const {
    val position = val::object();
    
    int startLine = this->getStartLineAsInt();
    int endLine = this->getEndLineAsInt();
    int startColumn = this->getStartColumnAsInt();
    int endColumn = this->getEndColumnAsInt();
    
    position.set("sl", val(startLine - 1));
    position.set("el", val(endLine - 1));
    position.set("sc", val(startColumn));
    position.set("ec", val(endColumn));

    return position;
}