#pragma once
#ifndef MC_FEATURES_H
#define MC_FEATURES_H

#include <emscripten/val.h>

//#include "common/Features.h"

using emscripten::val;

using std::string;
using std::wstring;

namespace monticore {
	class MCFeatures /*: common::Features*/ {
		public:
			//virtual val analyze(const string &input) const;
			static void parse(const wstring& docValue);
			static val analyze();
			static val outline();
	};
}

#endif