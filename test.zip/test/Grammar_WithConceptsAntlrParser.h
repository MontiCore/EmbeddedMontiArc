
// Generated from Grammar_WithConceptsAntlr.g4 by ANTLR 4.7.1

#pragma once


#include "antlr4-runtime.h"




class  Grammar_WithConceptsAntlrParser : public antlr4::Parser {
public:
  enum {
    T__0 = 1, T__1 = 2, T__2 = 3, T__3 = 4, T__4 = 5, T__5 = 6, T__6 = 7, 
    T__7 = 8, T__8 = 9, T__9 = 10, T__10 = 11, T__11 = 12, T__12 = 13, T__13 = 14, 
    T__14 = 15, T__15 = 16, T__16 = 17, T__17 = 18, T__18 = 19, T__19 = 20, 
    T__20 = 21, T__21 = 22, T__22 = 23, T__23 = 24, T__24 = 25, T__25 = 26, 
    T__26 = 27, T__27 = 28, T__28 = 29, T__29 = 30, T__30 = 31, T__31 = 32, 
    T__32 = 33, T__33 = 34, T__34 = 35, T__35 = 36, T__36 = 37, T__37 = 38, 
    T__38 = 39, T__39 = 40, T__40 = 41, T__41 = 42, T__42 = 43, T__43 = 44, 
    T__44 = 45, T__45 = 46, T__46 = 47, T__47 = 48, T__48 = 49, T__49 = 50, 
    T__50 = 51, T__51 = 52, T__52 = 53, T__53 = 54, T__54 = 55, T__55 = 56, 
    T__56 = 57, T__57 = 58, T__58 = 59, T__59 = 60, T__60 = 61, T__61 = 62, 
    T__62 = 63, T__63 = 64, T__64 = 65, T__65 = 66, T__66 = 67, T__67 = 68, 
    T__68 = 69, T__69 = 70, T__70 = 71, T__71 = 72, T__72 = 73, T__73 = 74, 
    T__74 = 75, T__75 = 76, T__76 = 77, T__77 = 78, T__78 = 79, AT = 80, 
    PIPEPIPE = 81, POINTPOINT = 82, ANDAND = 83, LTEQUALS = 84, PIPEEQUALS = 85, 
    STAREQUALS = 86, ANDEQUALS = 87, LBRACK = 88, RBRACK = 89, ROOF = 90, 
    ROOFEQUALS = 91, PLUSPLUS = 92, MINUSMINUS = 93, EQUALSEQUALS = 94, 
    EXCLAMATIONMARK = 95, GTGTGTEQUALS = 96, PERCENT = 97, AND = 98, LPAREN = 99, 
    RPAREN = 100, STAR = 101, PLUS = 102, COMMA = 103, MINUS = 104, POINT = 105, 
    POINTPOINTPOINT = 106, SLASHEQUALS = 107, SLASH = 108, MINUSEQUALS = 109, 
    MINUSGT = 110, PLUSEQUALS = 111, PERCENTEQUALS = 112, COLON = 113, LCURLY = 114, 
    SEMI = 115, LT = 116, PIPE = 117, EXCLAMATIONMARKEQUALS = 118, RCURLY = 119, 
    EQUALS = 120, GTGTEQUALS = 121, LTLTEQUALS = 122, GT = 123, TILDE = 124, 
    QUESTION = 125, GTEQUALS = 126, Name = 127, WS = 128, SL_COMMENT = 129, 
    ML_COMMENT = 130, Num_Int = 131, Num_Long = 132, Num_Float = 133, Num_Double = 134, 
    Char = 135, String = 136
  };

  enum {
    RuleConceptAntlr_eof = 0, RuleConceptAntlr = 1, RuleAntlrParserAction_eof = 2, 
    RuleAntlrParserAction = 3, RuleAntlrLexerAction_eof = 4, RuleAntlrLexerAction = 5, 
    RuleJavaCode_eof = 6, RuleJavaCode = 7, RuleNullLiteral_eof = 8, RuleNullLiteral = 9, 
    RuleBooleanLiteral_eof = 10, RuleBooleanLiteral = 11, RuleCharLiteral_eof = 12, 
    RuleCharLiteral = 13, RuleStringLiteral_eof = 14, RuleStringLiteral = 15, 
    RuleIntLiteral_eof = 16, RuleIntLiteral = 17, RuleSignedIntLiteral_eof = 18, 
    RuleSignedIntLiteral = 19, RuleLongLiteral_eof = 20, RuleLongLiteral = 21, 
    RuleSignedLongLiteral_eof = 22, RuleSignedLongLiteral = 23, RuleFloatLiteral_eof = 24, 
    RuleFloatLiteral = 25, RuleSignedFloatLiteral_eof = 26, RuleSignedFloatLiteral = 27, 
    RuleDoubleLiteral_eof = 28, RuleDoubleLiteral = 29, RuleSignedDoubleLiteral_eof = 30, 
    RuleSignedDoubleLiteral = 31, RuleQualifiedName_eof = 32, RuleQualifiedName = 33, 
    RuleComplexArrayType_eof = 34, RuleComplexArrayType = 35, RulePrimitiveArrayType_eof = 36, 
    RulePrimitiveArrayType = 37, RuleVoidType_eof = 38, RuleVoidType = 39, 
    RulePrimitiveType_eof = 40, RulePrimitiveType = 41, RuleSimpleReferenceType_eof = 42, 
    RuleSimpleReferenceType = 43, RuleComplexReferenceType_eof = 44, RuleComplexReferenceType = 45, 
    RuleTypeArguments_eof = 46, RuleTypeArguments = 47, RuleWildcardType_eof = 48, 
    RuleWildcardType = 49, RuleTypeParameters_eof = 50, RuleTypeParameters = 51, 
    RuleTypeVariableDeclaration_eof = 52, RuleTypeVariableDeclaration = 53, 
    RuleImportStatement_eof = 54, RuleImportStatement = 55, RuleTypeCastExpression_eof = 56, 
    RuleTypeCastExpression = 57, RulePrefixExpression_eof = 58, RulePrefixExpression = 59, 
    RuleBooleanNotExpression_eof = 60, RuleBooleanNotExpression = 61, RuleLogicalNotExpression_eof = 62, 
    RuleLogicalNotExpression = 63, RuleBracketExpression_eof = 64, RuleBracketExpression = 65, 
    RulePrimaryThisExpression_eof = 66, RulePrimaryThisExpression = 67, 
    RulePrimarySuperExpression_eof = 68, RulePrimarySuperExpression = 69, 
    RuleLiteralExpression_eof = 70, RuleLiteralExpression = 71, RuleNameExpression_eof = 72, 
    RuleNameExpression = 73, RuleClassExpression_eof = 74, RuleClassExpression = 75, 
    RulePrimaryGenericInvocationExpression_eof = 76, RulePrimaryGenericInvocationExpression = 77, 
    RuleGenericInvocationSuffix_eof = 78, RuleGenericInvocationSuffix = 79, 
    RuleSuperSuffix_eof = 80, RuleSuperSuffix = 81, RuleArguments_eof = 82, 
    RuleArguments = 83, RuleCompilationUnit_eof = 84, RuleCompilationUnit = 85, 
    RulePackageDeclaration_eof = 86, RulePackageDeclaration = 87, RuleImportDeclaration_eof = 88, 
    RuleImportDeclaration = 89, RulePrimitiveModifier_eof = 90, RulePrimitiveModifier = 91, 
    RuleEmptyDeclaration_eof = 92, RuleEmptyDeclaration = 93, RuleClassDeclaration_eof = 94, 
    RuleClassDeclaration = 95, RuleClassBody_eof = 96, RuleClassBody = 97, 
    RuleInterfaceDeclaration_eof = 98, RuleInterfaceDeclaration = 99, RuleInterfaceBody_eof = 100, 
    RuleInterfaceBody = 101, RuleEnumDeclaration_eof = 102, RuleEnumDeclaration = 103, 
    RuleEnumConstantDeclaration_eof = 104, RuleEnumConstantDeclaration = 105, 
    RuleEnumBody_eof = 106, RuleEnumBody = 107, RuleClassBlock_eof = 108, 
    RuleClassBlock = 109, RuleMethodDeclaration_eof = 110, RuleMethodDeclaration = 111, 
    RuleConstructorDeclaration_eof = 112, RuleConstructorDeclaration = 113, 
    RuleFieldDeclaration_eof = 114, RuleFieldDeclaration = 115, RuleConstDeclaration_eof = 116, 
    RuleConstDeclaration = 117, RuleConstantDeclarator_eof = 118, RuleConstantDeclarator = 119, 
    RuleInterfaceMethodDeclaration_eof = 120, RuleInterfaceMethodDeclaration = 121, 
    RuleMethodSignature_eof = 122, RuleMethodSignature = 123, RuleR__throws_eof = 124, 
    RuleR__throws = 125, RuleVariableDeclarator_eof = 126, RuleVariableDeclarator = 127, 
    RuleDeclaratorId_eof = 128, RuleDeclaratorId = 129, RuleVariableInititializerOrExpression_eof = 130, 
    RuleVariableInititializerOrExpression = 131, RuleArrayInitializer_eof = 132, 
    RuleArrayInitializer = 133, RuleFormalParameters_eof = 134, RuleFormalParameters = 135, 
    RuleFormalParameterListing_eof = 136, RuleFormalParameterListing = 137, 
    RuleFormalParameter_eof = 138, RuleFormalParameter = 139, RuleLastFormalParameter_eof = 140, 
    RuleLastFormalParameter = 141, RuleAnnotation_eof = 142, RuleAnnotation = 143, 
    RuleAnnotationPairArguments_eof = 144, RuleAnnotationPairArguments = 145, 
    RuleElementValuePair_eof = 146, RuleElementValuePair = 147, RuleElementValueOrExpr_eof = 148, 
    RuleElementValueOrExpr = 149, RuleElementValueArrayInitializer_eof = 150, 
    RuleElementValueArrayInitializer = 151, RuleAnnotationTypeDeclaration_eof = 152, 
    RuleAnnotationTypeDeclaration = 153, RuleAnnotationTypeBody_eof = 154, 
    RuleAnnotationTypeBody = 155, RuleAnnotationMethod_eof = 156, RuleAnnotationMethod = 157, 
    RuleAnnotationConstant_eof = 158, RuleAnnotationConstant = 159, RuleDefaultValue_eof = 160, 
    RuleDefaultValue = 161, RuleLocalVariableDeclarationStatement_eof = 162, 
    RuleLocalVariableDeclarationStatement = 163, RuleLocalVariableDeclaration_eof = 164, 
    RuleLocalVariableDeclaration = 165, RuleJavaBlock_eof = 166, RuleJavaBlock = 167, 
    RuleAssertStatement_eof = 168, RuleAssertStatement = 169, RuleIfStatement_eof = 170, 
    RuleIfStatement = 171, RuleForStatement_eof = 172, RuleForStatement = 173, 
    RuleCommonForControl_eof = 174, RuleCommonForControl = 175, RuleForInitByExpressions_eof = 176, 
    RuleForInitByExpressions = 177, RuleEnhancedForControl_eof = 178, RuleEnhancedForControl = 179, 
    RuleWhileStatement_eof = 180, RuleWhileStatement = 181, RuleDoWhileStatement_eof = 182, 
    RuleDoWhileStatement = 183, RuleTryStatement_eof = 184, RuleTryStatement = 185, 
    RuleCatchExceptionsHandler_eof = 186, RuleCatchExceptionsHandler = 187, 
    RuleFinallyBlockOnlyHandler_eof = 188, RuleFinallyBlockOnlyHandler = 189, 
    RuleTryStatementWithResources_eof = 190, RuleTryStatementWithResources = 191, 
    RuleResource_eof = 192, RuleResource = 193, RuleIdentifierAndTypeArgument_eof = 194, 
    RuleIdentifierAndTypeArgument = 195, RuleCatchClause_eof = 196, RuleCatchClause = 197, 
    RuleCatchType_eof = 198, RuleCatchType = 199, RuleSwitchStatement_eof = 200, 
    RuleSwitchStatement = 201, RuleSynchronizedStatement_eof = 202, RuleSynchronizedStatement = 203, 
    RuleReturnStatement_eof = 204, RuleReturnStatement = 205, RuleThrowStatement_eof = 206, 
    RuleThrowStatement = 207, RuleBreakStatement_eof = 208, RuleBreakStatement = 209, 
    RuleContinueStatement_eof = 210, RuleContinueStatement = 211, RuleEmptyStatement_eof = 212, 
    RuleEmptyStatement = 213, RuleExpressionStatement_eof = 214, RuleExpressionStatement = 215, 
    RuleASTStatement_eof = 216, RuleASTStatement = 217, RuleLabeledStatement_eof = 218, 
    RuleLabeledStatement = 219, RuleSwitchBlockStatementGroup_eof = 220, 
    RuleSwitchBlockStatementGroup = 221, RuleConstantExpressionSwitchLabel_eof = 222, 
    RuleConstantExpressionSwitchLabel = 223, RuleEnumConstantSwitchLabel_eof = 224, 
    RuleEnumConstantSwitchLabel = 225, RuleDefaultSwitchLabel_eof = 226, 
    RuleDefaultSwitchLabel = 227, RuleCreatorExpression_eof = 228, RuleCreatorExpression = 229, 
    RuleAnonymousClass_eof = 230, RuleAnonymousClass = 231, RuleArrayCreator_eof = 232, 
    RuleArrayCreator = 233, RuleArrayDimensionByInitializer_eof = 234, RuleArrayDimensionByInitializer = 235, 
    RuleArrayDimensionByExpression_eof = 236, RuleArrayDimensionByExpression = 237, 
    RuleCreatedName_eof = 238, RuleCreatedName = 239, RuleInnerCreator_eof = 240, 
    RuleInnerCreator = 241, RuleClassCreatorRest_eof = 242, RuleClassCreatorRest = 243, 
    RuleMCGrammar_eof = 244, RuleMCGrammar = 245, RuleMCImportStatement_eof = 246, 
    RuleMCImportStatement = 247, RuleGrammarReference_eof = 248, RuleGrammarReference = 249, 
    RuleGrammarOption_eof = 250, RuleGrammarOption = 251, RuleFollowOption_eof = 252, 
    RuleFollowOption = 253, RuleAntlrOption_eof = 254, RuleAntlrOption = 255, 
    RuleStartRule_eof = 256, RuleStartRule = 257, RuleLexProd_eof = 258, 
    RuleLexProd = 259, RuleEnumProd_eof = 260, RuleEnumProd = 261, RuleExternalProd_eof = 262, 
    RuleExternalProd = 263, RuleInterfaceProd_eof = 264, RuleInterfaceProd = 265, 
    RuleAbstractProd_eof = 266, RuleAbstractProd = 267, RuleClassProd_eof = 268, 
    RuleClassProd = 269, RuleCard_eof = 270, RuleCard = 271, RuleRuleReference_eof = 272, 
    RuleRuleReference = 273, RuleAlt_eof = 274, RuleAlt = 275, RuleNonTerminalSeparator_eof = 276, 
    RuleNonTerminalSeparator = 277, RuleBlock_eof = 278, RuleBlock = 279, 
    RuleOption_eof = 280, RuleOption = 281, RuleOptionValue_eof = 282, RuleOptionValue = 283, 
    RuleNonTerminal_eof = 284, RuleNonTerminal = 285, RuleTerminal_eof = 286, 
    RuleTerminal = 287, RuleConstant_eof = 288, RuleConstant = 289, RuleConstantGroup_eof = 290, 
    RuleConstantGroup = 291, RuleEof_eof = 292, RuleEof = 293, RuleMCAnything_eof = 294, 
    RuleMCAnything = 295, RuleAnything_eof = 296, RuleAnything = 297, RuleSemanticpredicateOrAction_eof = 298, 
    RuleSemanticpredicateOrAction = 299, RuleConcept_eof = 300, RuleConcept_ = 301, 
    RuleASTRule_eof = 302, RuleASTRule = 303, RuleMethod_eof = 304, RuleMethod = 305, 
    RuleMethodParameter_eof = 306, RuleMethodParameter = 307, RuleAttributeInAST_eof = 308, 
    RuleAttributeInAST = 309, RuleGenericType_eof = 310, RuleGenericType = 311, 
    RuleLexAlt_eof = 312, RuleLexAlt = 313, RuleLexBlock_eof = 314, RuleLexBlock = 315, 
    RuleLexCharRange_eof = 316, RuleLexCharRange = 317, RuleLexChar_eof = 318, 
    RuleLexChar = 319, RuleLexAnyChar_eof = 320, RuleLexAnyChar = 321, RuleLexString_eof = 322, 
    RuleLexString = 323, RuleLexActionOrPredicate_eof = 324, RuleLexActionOrPredicate = 325, 
    RuleLexNonTerminal_eof = 326, RuleLexNonTerminal = 327, RuleLexSimpleIteration_eof = 328, 
    RuleLexSimpleIteration = 329, RuleLexOption_eof = 330, RuleLexOption = 331, 
    RuleSymbolDefinition_eof = 332, RuleSymbolDefinition = 333, RuleAction_eof = 334, 
    RuleAction = 335, RuleExpressionPredicate_eof = 336, RuleExpressionPredicate = 337, 
    RuleMCConcept_eof = 338, RuleMCConcept = 339, RuleLiteral_eof = 340, 
    RuleLiteral = 341, RuleSignedLiteral_eof = 342, RuleSignedLiteral = 343, 
    RuleNumericLiteral_eof = 344, RuleNumericLiteral = 345, RuleSignedNumericLiteral_eof = 346, 
    RuleSignedNumericLiteral = 347, RuleType_eof = 348, RuleType = 349, 
    RuleReferenceType_eof = 350, RuleReferenceType = 351, RuleTypeArgument_eof = 352, 
    RuleTypeArgument = 353, RuleReturnType_eof = 354, RuleReturnType = 355, 
    RuleArrayType_eof = 356, RuleArrayType = 357, RuleExpression_eof = 358, 
    RuleExpression = 359, RuleModifier_eof = 360, RuleModifier = 361, RuleTypeDeclaration_eof = 362, 
    RuleTypeDeclaration = 363, RuleClassBodyDeclaration_eof = 364, RuleClassBodyDeclaration = 365, 
    RuleInterfaceBodyDeclaration_eof = 366, RuleInterfaceBodyDeclaration = 367, 
    RuleClassMemberDeclaration_eof = 368, RuleClassMemberDeclaration = 369, 
    RuleMethodBody_eof = 370, RuleMethodBody = 371, RuleConstructorBody_eof = 372, 
    RuleConstructorBody = 373, RuleInterfaceMemberDeclaration_eof = 374, 
    RuleInterfaceMemberDeclaration = 375, RuleVariableInitializer_eof = 376, 
    RuleVariableInitializer = 377, RuleAnnotationArguments_eof = 378, RuleAnnotationArguments = 379, 
    RuleElementValue_eof = 380, RuleElementValue = 381, RuleAnnotationTypeElementDeclaration_eof = 382, 
    RuleAnnotationTypeElementDeclaration = 383, RuleBlockStatement_eof = 384, 
    RuleBlockStatement = 385, RuleStatement_eof = 386, RuleStatement = 387, 
    RuleForControl_eof = 388, RuleForControl = 389, RuleForInit_eof = 390, 
    RuleForInit = 391, RuleExceptionHandler_eof = 392, RuleExceptionHandler = 393, 
    RuleFinallyBlock_eof = 394, RuleFinallyBlock = 395, RuleSwitchLabel_eof = 396, 
    RuleSwitchLabel = 397, RuleCreator_eof = 398, RuleCreator = 399, RuleArrayDimensionSpecifier_eof = 400, 
    RuleArrayDimensionSpecifier = 401, RuleProd_eof = 402, RuleProd = 403, 
    RuleParserProd_eof = 404, RuleParserProd = 405, RuleRuleComponent_eof = 406, 
    RuleRuleComponent = 407, RuleITerminal_eof = 408, RuleITerminal = 409, 
    RuleLexComponent_eof = 410, RuleLexComponent = 411
  };

  Grammar_WithConceptsAntlrParser(antlr4::TokenStream *input);
  ~Grammar_WithConceptsAntlrParser();

  virtual std::string getGrammarFileName() const override;
  virtual const antlr4::atn::ATN& getATN() const override { return _atn; };
  virtual const std::vector<std::string>& getTokenNames() const override { return _tokenNames; }; // deprecated: use vocabulary instead.
  virtual const std::vector<std::string>& getRuleNames() const override;
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;


  class ConceptAntlr_eofContext;
  class ConceptAntlrContext;
  class AntlrParserAction_eofContext;
  class AntlrParserActionContext;
  class AntlrLexerAction_eofContext;
  class AntlrLexerActionContext;
  class JavaCode_eofContext;
  class JavaCodeContext;
  class NullLiteral_eofContext;
  class NullLiteralContext;
  class BooleanLiteral_eofContext;
  class BooleanLiteralContext;
  class CharLiteral_eofContext;
  class CharLiteralContext;
  class StringLiteral_eofContext;
  class StringLiteralContext;
  class IntLiteral_eofContext;
  class IntLiteralContext;
  class SignedIntLiteral_eofContext;
  class SignedIntLiteralContext;
  class LongLiteral_eofContext;
  class LongLiteralContext;
  class SignedLongLiteral_eofContext;
  class SignedLongLiteralContext;
  class FloatLiteral_eofContext;
  class FloatLiteralContext;
  class SignedFloatLiteral_eofContext;
  class SignedFloatLiteralContext;
  class DoubleLiteral_eofContext;
  class DoubleLiteralContext;
  class SignedDoubleLiteral_eofContext;
  class SignedDoubleLiteralContext;
  class QualifiedName_eofContext;
  class QualifiedNameContext;
  class ComplexArrayType_eofContext;
  class ComplexArrayTypeContext;
  class PrimitiveArrayType_eofContext;
  class PrimitiveArrayTypeContext;
  class VoidType_eofContext;
  class VoidTypeContext;
  class PrimitiveType_eofContext;
  class PrimitiveTypeContext;
  class SimpleReferenceType_eofContext;
  class SimpleReferenceTypeContext;
  class ComplexReferenceType_eofContext;
  class ComplexReferenceTypeContext;
  class TypeArguments_eofContext;
  class TypeArgumentsContext;
  class WildcardType_eofContext;
  class WildcardTypeContext;
  class TypeParameters_eofContext;
  class TypeParametersContext;
  class TypeVariableDeclaration_eofContext;
  class TypeVariableDeclarationContext;
  class ImportStatement_eofContext;
  class ImportStatementContext;
  class TypeCastExpression_eofContext;
  class TypeCastExpressionContext;
  class PrefixExpression_eofContext;
  class PrefixExpressionContext;
  class BooleanNotExpression_eofContext;
  class BooleanNotExpressionContext;
  class LogicalNotExpression_eofContext;
  class LogicalNotExpressionContext;
  class BracketExpression_eofContext;
  class BracketExpressionContext;
  class PrimaryThisExpression_eofContext;
  class PrimaryThisExpressionContext;
  class PrimarySuperExpression_eofContext;
  class PrimarySuperExpressionContext;
  class LiteralExpression_eofContext;
  class LiteralExpressionContext;
  class NameExpression_eofContext;
  class NameExpressionContext;
  class ClassExpression_eofContext;
  class ClassExpressionContext;
  class PrimaryGenericInvocationExpression_eofContext;
  class PrimaryGenericInvocationExpressionContext;
  class GenericInvocationSuffix_eofContext;
  class GenericInvocationSuffixContext;
  class SuperSuffix_eofContext;
  class SuperSuffixContext;
  class Arguments_eofContext;
  class ArgumentsContext;
  class CompilationUnit_eofContext;
  class CompilationUnitContext;
  class PackageDeclaration_eofContext;
  class PackageDeclarationContext;
  class ImportDeclaration_eofContext;
  class ImportDeclarationContext;
  class PrimitiveModifier_eofContext;
  class PrimitiveModifierContext;
  class EmptyDeclaration_eofContext;
  class EmptyDeclarationContext;
  class ClassDeclaration_eofContext;
  class ClassDeclarationContext;
  class ClassBody_eofContext;
  class ClassBodyContext;
  class InterfaceDeclaration_eofContext;
  class InterfaceDeclarationContext;
  class InterfaceBody_eofContext;
  class InterfaceBodyContext;
  class EnumDeclaration_eofContext;
  class EnumDeclarationContext;
  class EnumConstantDeclaration_eofContext;
  class EnumConstantDeclarationContext;
  class EnumBody_eofContext;
  class EnumBodyContext;
  class ClassBlock_eofContext;
  class ClassBlockContext;
  class MethodDeclaration_eofContext;
  class MethodDeclarationContext;
  class ConstructorDeclaration_eofContext;
  class ConstructorDeclarationContext;
  class FieldDeclaration_eofContext;
  class FieldDeclarationContext;
  class ConstDeclaration_eofContext;
  class ConstDeclarationContext;
  class ConstantDeclarator_eofContext;
  class ConstantDeclaratorContext;
  class InterfaceMethodDeclaration_eofContext;
  class InterfaceMethodDeclarationContext;
  class MethodSignature_eofContext;
  class MethodSignatureContext;
  class R__throws_eofContext;
  class R__throwsContext;
  class VariableDeclarator_eofContext;
  class VariableDeclaratorContext;
  class DeclaratorId_eofContext;
  class DeclaratorIdContext;
  class VariableInititializerOrExpression_eofContext;
  class VariableInititializerOrExpressionContext;
  class ArrayInitializer_eofContext;
  class ArrayInitializerContext;
  class FormalParameters_eofContext;
  class FormalParametersContext;
  class FormalParameterListing_eofContext;
  class FormalParameterListingContext;
  class FormalParameter_eofContext;
  class FormalParameterContext;
  class LastFormalParameter_eofContext;
  class LastFormalParameterContext;
  class Annotation_eofContext;
  class AnnotationContext;
  class AnnotationPairArguments_eofContext;
  class AnnotationPairArgumentsContext;
  class ElementValuePair_eofContext;
  class ElementValuePairContext;
  class ElementValueOrExpr_eofContext;
  class ElementValueOrExprContext;
  class ElementValueArrayInitializer_eofContext;
  class ElementValueArrayInitializerContext;
  class AnnotationTypeDeclaration_eofContext;
  class AnnotationTypeDeclarationContext;
  class AnnotationTypeBody_eofContext;
  class AnnotationTypeBodyContext;
  class AnnotationMethod_eofContext;
  class AnnotationMethodContext;
  class AnnotationConstant_eofContext;
  class AnnotationConstantContext;
  class DefaultValue_eofContext;
  class DefaultValueContext;
  class LocalVariableDeclarationStatement_eofContext;
  class LocalVariableDeclarationStatementContext;
  class LocalVariableDeclaration_eofContext;
  class LocalVariableDeclarationContext;
  class JavaBlock_eofContext;
  class JavaBlockContext;
  class AssertStatement_eofContext;
  class AssertStatementContext;
  class IfStatement_eofContext;
  class IfStatementContext;
  class ForStatement_eofContext;
  class ForStatementContext;
  class CommonForControl_eofContext;
  class CommonForControlContext;
  class ForInitByExpressions_eofContext;
  class ForInitByExpressionsContext;
  class EnhancedForControl_eofContext;
  class EnhancedForControlContext;
  class WhileStatement_eofContext;
  class WhileStatementContext;
  class DoWhileStatement_eofContext;
  class DoWhileStatementContext;
  class TryStatement_eofContext;
  class TryStatementContext;
  class CatchExceptionsHandler_eofContext;
  class CatchExceptionsHandlerContext;
  class FinallyBlockOnlyHandler_eofContext;
  class FinallyBlockOnlyHandlerContext;
  class TryStatementWithResources_eofContext;
  class TryStatementWithResourcesContext;
  class Resource_eofContext;
  class ResourceContext;
  class IdentifierAndTypeArgument_eofContext;
  class IdentifierAndTypeArgumentContext;
  class CatchClause_eofContext;
  class CatchClauseContext;
  class CatchType_eofContext;
  class CatchTypeContext;
  class SwitchStatement_eofContext;
  class SwitchStatementContext;
  class SynchronizedStatement_eofContext;
  class SynchronizedStatementContext;
  class ReturnStatement_eofContext;
  class ReturnStatementContext;
  class ThrowStatement_eofContext;
  class ThrowStatementContext;
  class BreakStatement_eofContext;
  class BreakStatementContext;
  class ContinueStatement_eofContext;
  class ContinueStatementContext;
  class EmptyStatement_eofContext;
  class EmptyStatementContext;
  class ExpressionStatement_eofContext;
  class ExpressionStatementContext;
  class ASTStatement_eofContext;
  class ASTStatementContext;
  class LabeledStatement_eofContext;
  class LabeledStatementContext;
  class SwitchBlockStatementGroup_eofContext;
  class SwitchBlockStatementGroupContext;
  class ConstantExpressionSwitchLabel_eofContext;
  class ConstantExpressionSwitchLabelContext;
  class EnumConstantSwitchLabel_eofContext;
  class EnumConstantSwitchLabelContext;
  class DefaultSwitchLabel_eofContext;
  class DefaultSwitchLabelContext;
  class CreatorExpression_eofContext;
  class CreatorExpressionContext;
  class AnonymousClass_eofContext;
  class AnonymousClassContext;
  class ArrayCreator_eofContext;
  class ArrayCreatorContext;
  class ArrayDimensionByInitializer_eofContext;
  class ArrayDimensionByInitializerContext;
  class ArrayDimensionByExpression_eofContext;
  class ArrayDimensionByExpressionContext;
  class CreatedName_eofContext;
  class CreatedNameContext;
  class InnerCreator_eofContext;
  class InnerCreatorContext;
  class ClassCreatorRest_eofContext;
  class ClassCreatorRestContext;
  class MCGrammar_eofContext;
  class MCGrammarContext;
  class MCImportStatement_eofContext;
  class MCImportStatementContext;
  class GrammarReference_eofContext;
  class GrammarReferenceContext;
  class GrammarOption_eofContext;
  class GrammarOptionContext;
  class FollowOption_eofContext;
  class FollowOptionContext;
  class AntlrOption_eofContext;
  class AntlrOptionContext;
  class StartRule_eofContext;
  class StartRuleContext;
  class LexProd_eofContext;
  class LexProdContext;
  class EnumProd_eofContext;
  class EnumProdContext;
  class ExternalProd_eofContext;
  class ExternalProdContext;
  class InterfaceProd_eofContext;
  class InterfaceProdContext;
  class AbstractProd_eofContext;
  class AbstractProdContext;
  class ClassProd_eofContext;
  class ClassProdContext;
  class Card_eofContext;
  class CardContext;
  class RuleReference_eofContext;
  class RuleReferenceContext;
  class Alt_eofContext;
  class AltContext;
  class NonTerminalSeparator_eofContext;
  class NonTerminalSeparatorContext;
  class Block_eofContext;
  class BlockContext;
  class Option_eofContext;
  class OptionContext;
  class OptionValue_eofContext;
  class OptionValueContext;
  class NonTerminal_eofContext;
  class NonTerminalContext;
  class Terminal_eofContext;
  class TerminalContext;
  class Constant_eofContext;
  class ConstantContext;
  class ConstantGroup_eofContext;
  class ConstantGroupContext;
  class Eof_eofContext;
  class EofContext;
  class MCAnything_eofContext;
  class MCAnythingContext;
  class Anything_eofContext;
  class AnythingContext;
  class SemanticpredicateOrAction_eofContext;
  class SemanticpredicateOrActionContext;
  class Concept_eofContext;
  class Concept_Context;
  class ASTRule_eofContext;
  class ASTRuleContext;
  class Method_eofContext;
  class MethodContext;
  class MethodParameter_eofContext;
  class MethodParameterContext;
  class AttributeInAST_eofContext;
  class AttributeInASTContext;
  class GenericType_eofContext;
  class GenericTypeContext;
  class LexAlt_eofContext;
  class LexAltContext;
  class LexBlock_eofContext;
  class LexBlockContext;
  class LexCharRange_eofContext;
  class LexCharRangeContext;
  class LexChar_eofContext;
  class LexCharContext;
  class LexAnyChar_eofContext;
  class LexAnyCharContext;
  class LexString_eofContext;
  class LexStringContext;
  class LexActionOrPredicate_eofContext;
  class LexActionOrPredicateContext;
  class LexNonTerminal_eofContext;
  class LexNonTerminalContext;
  class LexSimpleIteration_eofContext;
  class LexSimpleIterationContext;
  class LexOption_eofContext;
  class LexOptionContext;
  class SymbolDefinition_eofContext;
  class SymbolDefinitionContext;
  class Action_eofContext;
  class ActionContext;
  class ExpressionPredicate_eofContext;
  class ExpressionPredicateContext;
  class MCConcept_eofContext;
  class MCConceptContext;
  class Literal_eofContext;
  class LiteralContext;
  class SignedLiteral_eofContext;
  class SignedLiteralContext;
  class NumericLiteral_eofContext;
  class NumericLiteralContext;
  class SignedNumericLiteral_eofContext;
  class SignedNumericLiteralContext;
  class Type_eofContext;
  class TypeContext;
  class ReferenceType_eofContext;
  class ReferenceTypeContext;
  class TypeArgument_eofContext;
  class TypeArgumentContext;
  class ReturnType_eofContext;
  class ReturnTypeContext;
  class ArrayType_eofContext;
  class ArrayTypeContext;
  class Expression_eofContext;
  class ExpressionContext;
  class Modifier_eofContext;
  class ModifierContext;
  class TypeDeclaration_eofContext;
  class TypeDeclarationContext;
  class ClassBodyDeclaration_eofContext;
  class ClassBodyDeclarationContext;
  class InterfaceBodyDeclaration_eofContext;
  class InterfaceBodyDeclarationContext;
  class ClassMemberDeclaration_eofContext;
  class ClassMemberDeclarationContext;
  class MethodBody_eofContext;
  class MethodBodyContext;
  class ConstructorBody_eofContext;
  class ConstructorBodyContext;
  class InterfaceMemberDeclaration_eofContext;
  class InterfaceMemberDeclarationContext;
  class VariableInitializer_eofContext;
  class VariableInitializerContext;
  class AnnotationArguments_eofContext;
  class AnnotationArgumentsContext;
  class ElementValue_eofContext;
  class ElementValueContext;
  class AnnotationTypeElementDeclaration_eofContext;
  class AnnotationTypeElementDeclarationContext;
  class BlockStatement_eofContext;
  class BlockStatementContext;
  class Statement_eofContext;
  class StatementContext;
  class ForControl_eofContext;
  class ForControlContext;
  class ForInit_eofContext;
  class ForInitContext;
  class ExceptionHandler_eofContext;
  class ExceptionHandlerContext;
  class FinallyBlock_eofContext;
  class FinallyBlockContext;
  class SwitchLabel_eofContext;
  class SwitchLabelContext;
  class Creator_eofContext;
  class CreatorContext;
  class ArrayDimensionSpecifier_eofContext;
  class ArrayDimensionSpecifierContext;
  class Prod_eofContext;
  class ProdContext;
  class ParserProd_eofContext;
  class ParserProdContext;
  class RuleComponent_eofContext;
  class RuleComponentContext;
  class ITerminal_eofContext;
  class ITerminalContext;
  class LexComponent_eofContext;
  class LexComponentContext; 

  class  ConceptAntlr_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ConceptAntlrContext *tmp = nullptr;;
    ConceptAntlr_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ConceptAntlrContext *conceptAntlr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConceptAntlr_eofContext* conceptAntlr_eof();

  class  ConceptAntlrContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AntlrParserActionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::AntlrLexerActionContext *tmp1 = nullptr;;
    ConceptAntlrContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<AntlrParserActionContext *> antlrParserAction();
    AntlrParserActionContext* antlrParserAction(size_t i);
    std::vector<AntlrLexerActionContext *> antlrLexerAction();
    AntlrLexerActionContext* antlrLexerAction(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConceptAntlrContext* conceptAntlr();

  class  AntlrParserAction_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AntlrParserActionContext *tmp = nullptr;;
    AntlrParserAction_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AntlrParserActionContext *antlrParserAction();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AntlrParserAction_eofContext* antlrParserAction_eof();

  class  AntlrParserActionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::JavaCodeContext *tmp0 = nullptr;;
    AntlrParserActionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    JavaCodeContext *javaCode();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AntlrParserActionContext* antlrParserAction();

  class  AntlrLexerAction_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AntlrLexerActionContext *tmp = nullptr;;
    AntlrLexerAction_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AntlrLexerActionContext *antlrLexerAction();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AntlrLexerAction_eofContext* antlrLexerAction_eof();

  class  AntlrLexerActionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::JavaCodeContext *tmp0 = nullptr;;
    AntlrLexerActionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    JavaCodeContext *javaCode();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AntlrLexerActionContext* antlrLexerAction();

  class  JavaCode_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::JavaCodeContext *tmp = nullptr;;
    JavaCode_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    JavaCodeContext *javaCode();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  JavaCode_eofContext* javaCode_eof();

  class  JavaCodeContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassMemberDeclarationContext *tmp0 = nullptr;;
    JavaCodeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<ClassMemberDeclarationContext *> classMemberDeclaration();
    ClassMemberDeclarationContext* classMemberDeclaration(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  JavaCodeContext* javaCode();

  class  NullLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::NullLiteralContext *tmp = nullptr;;
    NullLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    NullLiteralContext *nullLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  NullLiteral_eofContext* nullLiteral_eof();

  class  NullLiteralContext : public antlr4::ParserRuleContext {
  public:
    NullLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  NullLiteralContext* nullLiteral();

  class  BooleanLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::BooleanLiteralContext *tmp = nullptr;;
    BooleanLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    BooleanLiteralContext *booleanLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  BooleanLiteral_eofContext* booleanLiteral_eof();

  class  BooleanLiteralContext : public antlr4::ParserRuleContext {
  public:
    BooleanLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  BooleanLiteralContext* booleanLiteral();

  class  CharLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CharLiteralContext *tmp = nullptr;;
    CharLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    CharLiteralContext *charLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CharLiteral_eofContext* charLiteral_eof();

  class  CharLiteralContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    CharLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Char();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CharLiteralContext* charLiteral();

  class  StringLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::StringLiteralContext *tmp = nullptr;;
    StringLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    StringLiteralContext *stringLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  StringLiteral_eofContext* stringLiteral_eof();

  class  StringLiteralContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    StringLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *String();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  StringLiteralContext* stringLiteral();

  class  IntLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::IntLiteralContext *tmp = nullptr;;
    IntLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    IntLiteralContext *intLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  IntLiteral_eofContext* intLiteral_eof();

  class  IntLiteralContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    IntLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Num_Int();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  IntLiteralContext* intLiteral();

  class  SignedIntLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SignedIntLiteralContext *tmp = nullptr;;
    SignedIntLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SignedIntLiteralContext *signedIntLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedIntLiteral_eofContext* signedIntLiteral_eof();

  class  SignedIntLiteralContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    SignedIntLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *MINUS();
    antlr4::tree::TerminalNode *Num_Int();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedIntLiteralContext* signedIntLiteral();

  class  LongLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LongLiteralContext *tmp = nullptr;;
    LongLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LongLiteralContext *longLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LongLiteral_eofContext* longLiteral_eof();

  class  LongLiteralContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    LongLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Num_Long();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LongLiteralContext* longLiteral();

  class  SignedLongLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SignedLongLiteralContext *tmp = nullptr;;
    SignedLongLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SignedLongLiteralContext *signedLongLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedLongLiteral_eofContext* signedLongLiteral_eof();

  class  SignedLongLiteralContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    SignedLongLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *MINUS();
    antlr4::tree::TerminalNode *Num_Long();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedLongLiteralContext* signedLongLiteral();

  class  FloatLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FloatLiteralContext *tmp = nullptr;;
    FloatLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    FloatLiteralContext *floatLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FloatLiteral_eofContext* floatLiteral_eof();

  class  FloatLiteralContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    FloatLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Num_Float();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FloatLiteralContext* floatLiteral();

  class  SignedFloatLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SignedFloatLiteralContext *tmp = nullptr;;
    SignedFloatLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SignedFloatLiteralContext *signedFloatLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedFloatLiteral_eofContext* signedFloatLiteral_eof();

  class  SignedFloatLiteralContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    SignedFloatLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *MINUS();
    antlr4::tree::TerminalNode *Num_Float();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedFloatLiteralContext* signedFloatLiteral();

  class  DoubleLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::DoubleLiteralContext *tmp = nullptr;;
    DoubleLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    DoubleLiteralContext *doubleLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  DoubleLiteral_eofContext* doubleLiteral_eof();

  class  DoubleLiteralContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    DoubleLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Num_Double();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  DoubleLiteralContext* doubleLiteral();

  class  SignedDoubleLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SignedDoubleLiteralContext *tmp = nullptr;;
    SignedDoubleLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SignedDoubleLiteralContext *signedDoubleLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedDoubleLiteral_eofContext* signedDoubleLiteral_eof();

  class  SignedDoubleLiteralContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    SignedDoubleLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *MINUS();
    antlr4::tree::TerminalNode *Num_Double();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedDoubleLiteralContext* signedDoubleLiteral();

  class  QualifiedName_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::QualifiedNameContext *tmp = nullptr;;
    QualifiedName_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    QualifiedNameContext *qualifiedName();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  QualifiedName_eofContext* qualifiedName_eof();

  class  QualifiedNameContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    QualifiedNameContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);
    std::vector<antlr4::tree::TerminalNode *> POINT();
    antlr4::tree::TerminalNode* POINT(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  QualifiedNameContext* qualifiedName();

  class  ComplexArrayType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ComplexArrayTypeContext *tmp = nullptr;;
    ComplexArrayType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ComplexArrayTypeContext *complexArrayType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ComplexArrayType_eofContext* complexArrayType_eof();

  class  ComplexArrayTypeContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ComplexReferenceTypeContext *tmp0 = nullptr;;
    ComplexArrayTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ComplexReferenceTypeContext *complexReferenceType();
    std::vector<antlr4::tree::TerminalNode *> LBRACK();
    antlr4::tree::TerminalNode* LBRACK(size_t i);
    std::vector<antlr4::tree::TerminalNode *> RBRACK();
    antlr4::tree::TerminalNode* RBRACK(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ComplexArrayTypeContext* complexArrayType();

  class  PrimitiveArrayType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimitiveArrayTypeContext *tmp = nullptr;;
    PrimitiveArrayType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    PrimitiveArrayTypeContext *primitiveArrayType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimitiveArrayType_eofContext* primitiveArrayType_eof();

  class  PrimitiveArrayTypeContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimitiveTypeContext *tmp0 = nullptr;;
    PrimitiveArrayTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PrimitiveTypeContext *primitiveType();
    std::vector<antlr4::tree::TerminalNode *> LBRACK();
    antlr4::tree::TerminalNode* LBRACK(size_t i);
    std::vector<antlr4::tree::TerminalNode *> RBRACK();
    antlr4::tree::TerminalNode* RBRACK(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimitiveArrayTypeContext* primitiveArrayType();

  class  VoidType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::VoidTypeContext *tmp = nullptr;;
    VoidType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    VoidTypeContext *voidType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  VoidType_eofContext* voidType_eof();

  class  VoidTypeContext : public antlr4::ParserRuleContext {
  public:
    VoidTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  VoidTypeContext* voidType();

  class  PrimitiveType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimitiveTypeContext *tmp = nullptr;;
    PrimitiveType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    PrimitiveTypeContext *primitiveType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimitiveType_eofContext* primitiveType_eof();

  class  PrimitiveTypeContext : public antlr4::ParserRuleContext {
  public:
    PrimitiveTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimitiveTypeContext* primitiveType();

  class  SimpleReferenceType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SimpleReferenceTypeContext *tmp = nullptr;;
    SimpleReferenceType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SimpleReferenceTypeContext *simpleReferenceType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SimpleReferenceType_eofContext* simpleReferenceType_eof();

  class  SimpleReferenceTypeContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeArgumentsContext *tmp2 = nullptr;;
    SimpleReferenceTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);
    std::vector<antlr4::tree::TerminalNode *> POINT();
    antlr4::tree::TerminalNode* POINT(size_t i);
    TypeArgumentsContext *typeArguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SimpleReferenceTypeContext* simpleReferenceType();

  class  ComplexReferenceType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ComplexReferenceTypeContext *tmp = nullptr;;
    ComplexReferenceType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ComplexReferenceTypeContext *complexReferenceType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ComplexReferenceType_eofContext* complexReferenceType_eof();

  class  ComplexReferenceTypeContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SimpleReferenceTypeContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::SimpleReferenceTypeContext *tmp1 = nullptr;;
    ComplexReferenceTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<SimpleReferenceTypeContext *> simpleReferenceType();
    SimpleReferenceTypeContext* simpleReferenceType(size_t i);
    std::vector<antlr4::tree::TerminalNode *> POINT();
    antlr4::tree::TerminalNode* POINT(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ComplexReferenceTypeContext* complexReferenceType();

  class  TypeArguments_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeArgumentsContext *tmp = nullptr;;
    TypeArguments_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    TypeArgumentsContext *typeArguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeArguments_eofContext* typeArguments_eof();

  class  TypeArgumentsContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeArgumentContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeArgumentContext *tmp1 = nullptr;;
    TypeArgumentsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LT();
    antlr4::tree::TerminalNode *GT();
    std::vector<TypeArgumentContext *> typeArgument();
    TypeArgumentContext* typeArgument(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeArgumentsContext* typeArguments();

  class  WildcardType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::WildcardTypeContext *tmp = nullptr;;
    WildcardType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    WildcardTypeContext *wildcardType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  WildcardType_eofContext* wildcardType_eof();

  class  WildcardTypeContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp1 = nullptr;;
    WildcardTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *QUESTION();
    TypeContext *type();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  WildcardTypeContext* wildcardType();

  class  TypeParameters_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeParametersContext *tmp = nullptr;;
    TypeParameters_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    TypeParametersContext *typeParameters();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeParameters_eofContext* typeParameters_eof();

  class  TypeParametersContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeVariableDeclarationContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeVariableDeclarationContext *tmp1 = nullptr;;
    TypeParametersContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LT();
    antlr4::tree::TerminalNode *GT();
    std::vector<TypeVariableDeclarationContext *> typeVariableDeclaration();
    TypeVariableDeclarationContext* typeVariableDeclaration(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeParametersContext* typeParameters();

  class  TypeVariableDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeVariableDeclarationContext *tmp = nullptr;;
    TypeVariableDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    TypeVariableDeclarationContext *typeVariableDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeVariableDeclaration_eofContext* typeVariableDeclaration_eof();

  class  TypeVariableDeclarationContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ComplexReferenceTypeContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::ComplexReferenceTypeContext *tmp2 = nullptr;;
    TypeVariableDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Name();
    std::vector<ComplexReferenceTypeContext *> complexReferenceType();
    ComplexReferenceTypeContext* complexReferenceType(size_t i);
    std::vector<antlr4::tree::TerminalNode *> AND();
    antlr4::tree::TerminalNode* AND(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeVariableDeclarationContext* typeVariableDeclaration();

  class  ImportStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ImportStatementContext *tmp = nullptr;;
    ImportStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ImportStatementContext *importStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ImportStatement_eofContext* importStatement_eof();

  class  ImportStatementContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    ImportStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    std::vector<antlr4::tree::TerminalNode *> POINT();
    antlr4::tree::TerminalNode* POINT(size_t i);
    antlr4::tree::TerminalNode *STAR();
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ImportStatementContext* importStatement();

  class  TypeCastExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeCastExpressionContext *tmp = nullptr;;
    TypeCastExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    TypeCastExpressionContext *typeCastExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeCastExpression_eofContext* typeCastExpression_eof();

  class  TypeCastExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp1 = nullptr;;
    TypeCastExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    TypeContext *type();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeCastExpressionContext* typeCastExpression();

  class  PrefixExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrefixExpressionContext *tmp = nullptr;;
    PrefixExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    PrefixExpressionContext *prefixExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrefixExpression_eofContext* prefixExpression_eof();

  class  PrefixExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    PrefixExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *PLUS();
    antlr4::tree::TerminalNode *MINUS();
    antlr4::tree::TerminalNode *PLUSPLUS();
    antlr4::tree::TerminalNode *MINUSMINUS();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrefixExpressionContext* prefixExpression();

  class  BooleanNotExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::BooleanNotExpressionContext *tmp = nullptr;;
    BooleanNotExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    BooleanNotExpressionContext *booleanNotExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  BooleanNotExpression_eofContext* booleanNotExpression_eof();

  class  BooleanNotExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    BooleanNotExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *TILDE();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  BooleanNotExpressionContext* booleanNotExpression();

  class  LogicalNotExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LogicalNotExpressionContext *tmp = nullptr;;
    LogicalNotExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LogicalNotExpressionContext *logicalNotExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LogicalNotExpression_eofContext* logicalNotExpression_eof();

  class  LogicalNotExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    LogicalNotExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EXCLAMATIONMARK();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LogicalNotExpressionContext* logicalNotExpression();

  class  BracketExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::BracketExpressionContext *tmp = nullptr;;
    BracketExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    BracketExpressionContext *bracketExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  BracketExpression_eofContext* bracketExpression_eof();

  class  BracketExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    BracketExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  BracketExpressionContext* bracketExpression();

  class  PrimaryThisExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimaryThisExpressionContext *tmp = nullptr;;
    PrimaryThisExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    PrimaryThisExpressionContext *primaryThisExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimaryThisExpression_eofContext* primaryThisExpression_eof();

  class  PrimaryThisExpressionContext : public antlr4::ParserRuleContext {
  public:
    PrimaryThisExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimaryThisExpressionContext* primaryThisExpression();

  class  PrimarySuperExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimarySuperExpressionContext *tmp = nullptr;;
    PrimarySuperExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    PrimarySuperExpressionContext *primarySuperExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimarySuperExpression_eofContext* primarySuperExpression_eof();

  class  PrimarySuperExpressionContext : public antlr4::ParserRuleContext {
  public:
    PrimarySuperExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimarySuperExpressionContext* primarySuperExpression();

  class  LiteralExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LiteralExpressionContext *tmp = nullptr;;
    LiteralExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LiteralExpressionContext *literalExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LiteralExpression_eofContext* literalExpression_eof();

  class  LiteralExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LiteralContext *tmp0 = nullptr;;
    LiteralExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LiteralContext *literal();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LiteralExpressionContext* literalExpression();

  class  NameExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::NameExpressionContext *tmp = nullptr;;
    NameExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    NameExpressionContext *nameExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  NameExpression_eofContext* nameExpression_eof();

  class  NameExpressionContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    NameExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  NameExpressionContext* nameExpression();

  class  ClassExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassExpressionContext *tmp = nullptr;;
    ClassExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ClassExpressionContext *classExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassExpression_eofContext* classExpression_eof();

  class  ClassExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ReturnTypeContext *tmp0 = nullptr;;
    ClassExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *POINT();
    ReturnTypeContext *returnType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassExpressionContext* classExpression();

  class  PrimaryGenericInvocationExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimaryGenericInvocationExpressionContext *tmp = nullptr;;
    PrimaryGenericInvocationExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    PrimaryGenericInvocationExpressionContext *primaryGenericInvocationExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimaryGenericInvocationExpression_eofContext* primaryGenericInvocationExpression_eof();

  class  PrimaryGenericInvocationExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeArgumentsContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericInvocationSuffixContext *tmp1 = nullptr;;
    PrimaryGenericInvocationExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeArgumentsContext *typeArguments();
    GenericInvocationSuffixContext *genericInvocationSuffix();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimaryGenericInvocationExpressionContext* primaryGenericInvocationExpression();

  class  GenericInvocationSuffix_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::GenericInvocationSuffixContext *tmp = nullptr;;
    GenericInvocationSuffix_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    GenericInvocationSuffixContext *genericInvocationSuffix();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  GenericInvocationSuffix_eofContext* genericInvocationSuffix_eof();

  class  GenericInvocationSuffixContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SuperSuffixContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ArgumentsContext *tmp1 = nullptr;;
    antlr4::Token *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::ArgumentsContext *tmp3 = nullptr;;
    GenericInvocationSuffixContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    SuperSuffixContext *superSuffix();
    ArgumentsContext *arguments();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  GenericInvocationSuffixContext* genericInvocationSuffix();

  class  SuperSuffix_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SuperSuffixContext *tmp = nullptr;;
    SuperSuffix_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SuperSuffixContext *superSuffix();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SuperSuffix_eofContext* superSuffix_eof();

  class  SuperSuffixContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArgumentsContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeArgumentsContext *tmp1 = nullptr;;
    antlr4::Token *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::ArgumentsContext *tmp3 = nullptr;;
    SuperSuffixContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ArgumentsContext *arguments();
    antlr4::tree::TerminalNode *POINT();
    antlr4::tree::TerminalNode *Name();
    TypeArgumentsContext *typeArguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SuperSuffixContext* superSuffix();

  class  Arguments_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArgumentsContext *tmp = nullptr;;
    Arguments_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ArgumentsContext *arguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Arguments_eofContext* arguments_eof();

  class  ArgumentsContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp1 = nullptr;;
    ArgumentsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    std::vector<ExpressionContext *> expression();
    ExpressionContext* expression(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArgumentsContext* arguments();

  class  CompilationUnit_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CompilationUnitContext *tmp = nullptr;;
    CompilationUnit_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    CompilationUnitContext *compilationUnit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CompilationUnit_eofContext* compilationUnit_eof();

  class  CompilationUnitContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PackageDeclarationContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ImportDeclarationContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeDeclarationContext *tmp2 = nullptr;;
    CompilationUnitContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    PackageDeclarationContext *packageDeclaration();
    std::vector<ImportDeclarationContext *> importDeclaration();
    ImportDeclarationContext* importDeclaration(size_t i);
    std::vector<TypeDeclarationContext *> typeDeclaration();
    TypeDeclarationContext* typeDeclaration(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CompilationUnitContext* compilationUnit();

  class  PackageDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PackageDeclarationContext *tmp = nullptr;;
    PackageDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    PackageDeclarationContext *packageDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PackageDeclaration_eofContext* packageDeclaration_eof();

  class  PackageDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::QualifiedNameContext *tmp1 = nullptr;;
    PackageDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    QualifiedNameContext *qualifiedName();
    std::vector<AnnotationContext *> annotation();
    AnnotationContext* annotation(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PackageDeclarationContext* packageDeclaration();

  class  ImportDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ImportDeclarationContext *tmp = nullptr;;
    ImportDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ImportDeclarationContext *importDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ImportDeclaration_eofContext* importDeclaration_eof();

  class  ImportDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::QualifiedNameContext *tmp0 = nullptr;;
    ImportDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    QualifiedNameContext *qualifiedName();
    antlr4::tree::TerminalNode *POINT();
    antlr4::tree::TerminalNode *STAR();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ImportDeclarationContext* importDeclaration();

  class  PrimitiveModifier_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimitiveModifierContext *tmp = nullptr;;
    PrimitiveModifier_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    PrimitiveModifierContext *primitiveModifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimitiveModifier_eofContext* primitiveModifier_eof();

  class  PrimitiveModifierContext : public antlr4::ParserRuleContext {
  public:
    PrimitiveModifierContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  PrimitiveModifierContext* primitiveModifier();

  class  EmptyDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::EmptyDeclarationContext *tmp = nullptr;;
    EmptyDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    EmptyDeclarationContext *emptyDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EmptyDeclaration_eofContext* emptyDeclaration_eof();

  class  EmptyDeclarationContext : public antlr4::ParserRuleContext {
  public:
    EmptyDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EmptyDeclarationContext* emptyDeclaration();

  class  ClassDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassDeclarationContext *tmp = nullptr;;
    ClassDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ClassDeclarationContext *classDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassDeclaration_eofContext* classDeclaration_eof();

  class  ClassDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ModifierContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeParametersContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp5 = nullptr;;
    Grammar_WithConceptsAntlrParser::ClassBodyContext *tmp6 = nullptr;;
    ClassDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ClassBodyContext *classBody();
    antlr4::tree::TerminalNode *Name();
    std::vector<ModifierContext *> modifier();
    ModifierContext* modifier(size_t i);
    TypeParametersContext *typeParameters();
    std::vector<TypeContext *> type();
    TypeContext* type(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassDeclarationContext* classDeclaration();

  class  ClassBody_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassBodyContext *tmp = nullptr;;
    ClassBody_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ClassBodyContext *classBody();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassBody_eofContext* classBody_eof();

  class  ClassBodyContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassBodyDeclarationContext *tmp0 = nullptr;;
    ClassBodyContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<ClassBodyDeclarationContext *> classBodyDeclaration();
    ClassBodyDeclarationContext* classBodyDeclaration(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassBodyContext* classBody();

  class  InterfaceDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::InterfaceDeclarationContext *tmp = nullptr;;
    InterfaceDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    InterfaceDeclarationContext *interfaceDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceDeclaration_eofContext* interfaceDeclaration_eof();

  class  InterfaceDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ModifierContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeParametersContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::InterfaceBodyContext *tmp5 = nullptr;;
    InterfaceDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    InterfaceBodyContext *interfaceBody();
    antlr4::tree::TerminalNode *Name();
    std::vector<ModifierContext *> modifier();
    ModifierContext* modifier(size_t i);
    TypeParametersContext *typeParameters();
    std::vector<TypeContext *> type();
    TypeContext* type(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceDeclarationContext* interfaceDeclaration();

  class  InterfaceBody_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::InterfaceBodyContext *tmp = nullptr;;
    InterfaceBody_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    InterfaceBodyContext *interfaceBody();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceBody_eofContext* interfaceBody_eof();

  class  InterfaceBodyContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::InterfaceBodyDeclarationContext *tmp0 = nullptr;;
    InterfaceBodyContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<InterfaceBodyDeclarationContext *> interfaceBodyDeclaration();
    InterfaceBodyDeclarationContext* interfaceBodyDeclaration(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceBodyContext* interfaceBody();

  class  EnumDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::EnumDeclarationContext *tmp = nullptr;;
    EnumDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    EnumDeclarationContext *enumDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnumDeclaration_eofContext* enumDeclaration_eof();

  class  EnumDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ModifierContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::EnumConstantDeclarationContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::EnumConstantDeclarationContext *tmp5 = nullptr;;
    Grammar_WithConceptsAntlrParser::EnumBodyContext *tmp6 = nullptr;;
    EnumDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    antlr4::tree::TerminalNode *Name();
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);
    std::vector<ModifierContext *> modifier();
    ModifierContext* modifier(size_t i);
    std::vector<EnumConstantDeclarationContext *> enumConstantDeclaration();
    EnumConstantDeclarationContext* enumConstantDeclaration(size_t i);
    EnumBodyContext *enumBody();
    std::vector<TypeContext *> type();
    TypeContext* type(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnumDeclarationContext* enumDeclaration();

  class  EnumConstantDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::EnumConstantDeclarationContext *tmp = nullptr;;
    EnumConstantDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    EnumConstantDeclarationContext *enumConstantDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnumConstantDeclaration_eofContext* enumConstantDeclaration_eof();

  class  EnumConstantDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::ArgumentsContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::ClassBodyContext *tmp3 = nullptr;;
    EnumConstantDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Name();
    std::vector<AnnotationContext *> annotation();
    AnnotationContext* annotation(size_t i);
    ArgumentsContext *arguments();
    ClassBodyContext *classBody();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnumConstantDeclarationContext* enumConstantDeclaration();

  class  EnumBody_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::EnumBodyContext *tmp = nullptr;;
    EnumBody_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    EnumBodyContext *enumBody();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnumBody_eofContext* enumBody_eof();

  class  EnumBodyContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassBodyDeclarationContext *tmp0 = nullptr;;
    EnumBodyContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    std::vector<ClassBodyDeclarationContext *> classBodyDeclaration();
    ClassBodyDeclarationContext* classBodyDeclaration(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnumBodyContext* enumBody();

  class  ClassBlock_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassBlockContext *tmp = nullptr;;
    ClassBlock_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ClassBlockContext *classBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassBlock_eofContext* classBlock_eof();

  class  ClassBlockContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::JavaBlockContext *tmp0 = nullptr;;
    ClassBlockContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    JavaBlockContext *javaBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassBlockContext* classBlock();

  class  MethodDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MethodDeclarationContext *tmp = nullptr;;
    MethodDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    MethodDeclarationContext *methodDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MethodDeclaration_eofContext* methodDeclaration_eof();

  class  MethodDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MethodSignatureContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::MethodBodyContext *tmp1 = nullptr;;
    MethodDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    MethodSignatureContext *methodSignature();
    antlr4::tree::TerminalNode *SEMI();
    MethodBodyContext *methodBody();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MethodDeclarationContext* methodDeclaration();

  class  ConstructorDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ConstructorDeclarationContext *tmp = nullptr;;
    ConstructorDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ConstructorDeclarationContext *constructorDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstructorDeclaration_eofContext* constructorDeclaration_eof();

  class  ConstructorDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ModifierContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeParametersContext *tmp1 = nullptr;;
    antlr4::Token *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::FormalParametersContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::R__throwsContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::ConstructorBodyContext *tmp5 = nullptr;;
    ConstructorDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    FormalParametersContext *formalParameters();
    ConstructorBodyContext *constructorBody();
    antlr4::tree::TerminalNode *Name();
    std::vector<ModifierContext *> modifier();
    ModifierContext* modifier(size_t i);
    TypeParametersContext *typeParameters();
    R__throwsContext *r__throws();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstructorDeclarationContext* constructorDeclaration();

  class  FieldDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FieldDeclarationContext *tmp = nullptr;;
    FieldDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    FieldDeclarationContext *fieldDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FieldDeclaration_eofContext* fieldDeclaration_eof();

  class  FieldDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ModifierContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::VariableDeclaratorContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::VariableDeclaratorContext *tmp3 = nullptr;;
    FieldDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    TypeContext *type();
    std::vector<VariableDeclaratorContext *> variableDeclarator();
    VariableDeclaratorContext* variableDeclarator(size_t i);
    std::vector<ModifierContext *> modifier();
    ModifierContext* modifier(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FieldDeclarationContext* fieldDeclaration();

  class  ConstDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ConstDeclarationContext *tmp = nullptr;;
    ConstDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ConstDeclarationContext *constDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstDeclaration_eofContext* constDeclaration_eof();

  class  ConstDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ModifierContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::ConstantDeclaratorContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::ConstantDeclaratorContext *tmp3 = nullptr;;
    ConstDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    TypeContext *type();
    std::vector<ConstantDeclaratorContext *> constantDeclarator();
    ConstantDeclaratorContext* constantDeclarator(size_t i);
    std::vector<ModifierContext *> modifier();
    ModifierContext* modifier(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstDeclarationContext* constDeclaration();

  class  ConstantDeclarator_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ConstantDeclaratorContext *tmp = nullptr;;
    ConstantDeclarator_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ConstantDeclaratorContext *constantDeclarator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstantDeclarator_eofContext* constantDeclarator_eof();

  class  ConstantDeclaratorContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::VariableInititializerOrExpressionContext *tmp1 = nullptr;;
    ConstantDeclaratorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EQUALS();
    VariableInititializerOrExpressionContext *variableInititializerOrExpression();
    antlr4::tree::TerminalNode *Name();
    std::vector<antlr4::tree::TerminalNode *> LBRACK();
    antlr4::tree::TerminalNode* LBRACK(size_t i);
    std::vector<antlr4::tree::TerminalNode *> RBRACK();
    antlr4::tree::TerminalNode* RBRACK(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstantDeclaratorContext* constantDeclarator();

  class  InterfaceMethodDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::InterfaceMethodDeclarationContext *tmp = nullptr;;
    InterfaceMethodDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    InterfaceMethodDeclarationContext *interfaceMethodDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceMethodDeclaration_eofContext* interfaceMethodDeclaration_eof();

  class  InterfaceMethodDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MethodSignatureContext *tmp0 = nullptr;;
    InterfaceMethodDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    MethodSignatureContext *methodSignature();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceMethodDeclarationContext* interfaceMethodDeclaration();

  class  MethodSignature_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MethodSignatureContext *tmp = nullptr;;
    MethodSignature_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    MethodSignatureContext *methodSignature();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MethodSignature_eofContext* methodSignature_eof();

  class  MethodSignatureContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ModifierContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeParametersContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::ReturnTypeContext *tmp2 = nullptr;;
    antlr4::Token *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::FormalParametersContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::R__throwsContext *tmp5 = nullptr;;
    MethodSignatureContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ReturnTypeContext *returnType();
    FormalParametersContext *formalParameters();
    antlr4::tree::TerminalNode *Name();
    std::vector<antlr4::tree::TerminalNode *> LBRACK();
    antlr4::tree::TerminalNode* LBRACK(size_t i);
    std::vector<antlr4::tree::TerminalNode *> RBRACK();
    antlr4::tree::TerminalNode* RBRACK(size_t i);
    std::vector<ModifierContext *> modifier();
    ModifierContext* modifier(size_t i);
    TypeParametersContext *typeParameters();
    R__throwsContext *r__throws();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MethodSignatureContext* methodSignature();

  class  R__throws_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::R__throwsContext *tmp = nullptr;;
    R__throws_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    R__throwsContext *r__throws();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  R__throws_eofContext* r__throws_eof();

  class  R__throwsContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::QualifiedNameContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::QualifiedNameContext *tmp1 = nullptr;;
    R__throwsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<QualifiedNameContext *> qualifiedName();
    QualifiedNameContext* qualifiedName(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  R__throwsContext* r__throws();

  class  VariableDeclarator_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::VariableDeclaratorContext *tmp = nullptr;;
    VariableDeclarator_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    VariableDeclaratorContext *variableDeclarator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  VariableDeclarator_eofContext* variableDeclarator_eof();

  class  VariableDeclaratorContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::DeclaratorIdContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::VariableInititializerOrExpressionContext *tmp1 = nullptr;;
    VariableDeclaratorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    DeclaratorIdContext *declaratorId();
    antlr4::tree::TerminalNode *EQUALS();
    VariableInititializerOrExpressionContext *variableInititializerOrExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  VariableDeclaratorContext* variableDeclarator();

  class  DeclaratorId_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::DeclaratorIdContext *tmp = nullptr;;
    DeclaratorId_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    DeclaratorIdContext *declaratorId();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  DeclaratorId_eofContext* declaratorId_eof();

  class  DeclaratorIdContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    DeclaratorIdContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Name();
    std::vector<antlr4::tree::TerminalNode *> LBRACK();
    antlr4::tree::TerminalNode* LBRACK(size_t i);
    std::vector<antlr4::tree::TerminalNode *> RBRACK();
    antlr4::tree::TerminalNode* RBRACK(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  DeclaratorIdContext* declaratorId();

  class  VariableInititializerOrExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::VariableInititializerOrExpressionContext *tmp = nullptr;;
    VariableInititializerOrExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    VariableInititializerOrExpressionContext *variableInititializerOrExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  VariableInititializerOrExpression_eofContext* variableInititializerOrExpression_eof();

  class  VariableInititializerOrExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::VariableInitializerContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp1 = nullptr;;
    VariableInititializerOrExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    VariableInitializerContext *variableInitializer();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  VariableInititializerOrExpressionContext* variableInititializerOrExpression();

  class  ArrayInitializer_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArrayInitializerContext *tmp = nullptr;;
    ArrayInitializer_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ArrayInitializerContext *arrayInitializer();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayInitializer_eofContext* arrayInitializer_eof();

  class  ArrayInitializerContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::VariableInititializerOrExpressionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::VariableInititializerOrExpressionContext *tmp1 = nullptr;;
    ArrayInitializerContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);
    std::vector<VariableInititializerOrExpressionContext *> variableInititializerOrExpression();
    VariableInititializerOrExpressionContext* variableInititializerOrExpression(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayInitializerContext* arrayInitializer();

  class  FormalParameters_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FormalParametersContext *tmp = nullptr;;
    FormalParameters_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    FormalParametersContext *formalParameters();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FormalParameters_eofContext* formalParameters_eof();

  class  FormalParametersContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FormalParameterListingContext *tmp0 = nullptr;;
    FormalParametersContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    FormalParameterListingContext *formalParameterListing();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FormalParametersContext* formalParameters();

  class  FormalParameterListing_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FormalParameterListingContext *tmp = nullptr;;
    FormalParameterListing_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    FormalParameterListingContext *formalParameterListing();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FormalParameterListing_eofContext* formalParameterListing_eof();

  class  FormalParameterListingContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FormalParameterContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::FormalParameterContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::LastFormalParameterContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::LastFormalParameterContext *tmp3 = nullptr;;
    FormalParameterListingContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<FormalParameterContext *> formalParameter();
    FormalParameterContext* formalParameter(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);
    LastFormalParameterContext *lastFormalParameter();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FormalParameterListingContext* formalParameterListing();

  class  FormalParameter_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FormalParameterContext *tmp = nullptr;;
    FormalParameter_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    FormalParameterContext *formalParameter();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FormalParameter_eofContext* formalParameter_eof();

  class  FormalParameterContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimitiveModifierContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::DeclaratorIdContext *tmp2 = nullptr;;
    FormalParameterContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeContext *type();
    DeclaratorIdContext *declaratorId();
    std::vector<PrimitiveModifierContext *> primitiveModifier();
    PrimitiveModifierContext* primitiveModifier(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FormalParameterContext* formalParameter();

  class  LastFormalParameter_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LastFormalParameterContext *tmp = nullptr;;
    LastFormalParameter_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LastFormalParameterContext *lastFormalParameter();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LastFormalParameter_eofContext* lastFormalParameter_eof();

  class  LastFormalParameterContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimitiveModifierContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::DeclaratorIdContext *tmp2 = nullptr;;
    LastFormalParameterContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *POINTPOINTPOINT();
    TypeContext *type();
    DeclaratorIdContext *declaratorId();
    std::vector<PrimitiveModifierContext *> primitiveModifier();
    PrimitiveModifierContext* primitiveModifier(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LastFormalParameterContext* lastFormalParameter();

  class  Annotation_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationContext *tmp = nullptr;;
    Annotation_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AnnotationContext *annotation();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Annotation_eofContext* annotation_eof();

  class  AnnotationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::QualifiedNameContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::AnnotationArgumentsContext *tmp1 = nullptr;;
    AnnotationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *AT();
    QualifiedNameContext *qualifiedName();
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    AnnotationArgumentsContext *annotationArguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationContext* annotation();

  class  AnnotationPairArguments_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationPairArgumentsContext *tmp = nullptr;;
    AnnotationPairArguments_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AnnotationPairArgumentsContext *annotationPairArguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationPairArguments_eofContext* annotationPairArguments_eof();

  class  AnnotationPairArgumentsContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ElementValuePairContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ElementValuePairContext *tmp1 = nullptr;;
    AnnotationPairArgumentsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<ElementValuePairContext *> elementValuePair();
    ElementValuePairContext* elementValuePair(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationPairArgumentsContext* annotationPairArguments();

  class  ElementValuePair_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ElementValuePairContext *tmp = nullptr;;
    ElementValuePair_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ElementValuePairContext *elementValuePair();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ElementValuePair_eofContext* elementValuePair_eof();

  class  ElementValuePairContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ElementValueOrExprContext *tmp1 = nullptr;;
    ElementValuePairContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EQUALS();
    ElementValueOrExprContext *elementValueOrExpr();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ElementValuePairContext* elementValuePair();

  class  ElementValueOrExpr_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ElementValueOrExprContext *tmp = nullptr;;
    ElementValueOrExpr_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ElementValueOrExprContext *elementValueOrExpr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ElementValueOrExpr_eofContext* elementValueOrExpr_eof();

  class  ElementValueOrExprContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ElementValueContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp1 = nullptr;;
    ElementValueOrExprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ElementValueContext *elementValue();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ElementValueOrExprContext* elementValueOrExpr();

  class  ElementValueArrayInitializer_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ElementValueArrayInitializerContext *tmp = nullptr;;
    ElementValueArrayInitializer_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ElementValueArrayInitializerContext *elementValueArrayInitializer();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ElementValueArrayInitializer_eofContext* elementValueArrayInitializer_eof();

  class  ElementValueArrayInitializerContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ElementValueOrExprContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ElementValueOrExprContext *tmp1 = nullptr;;
    ElementValueArrayInitializerContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);
    std::vector<ElementValueOrExprContext *> elementValueOrExpr();
    ElementValueOrExprContext* elementValueOrExpr(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ElementValueArrayInitializerContext* elementValueArrayInitializer();

  class  AnnotationTypeDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationTypeDeclarationContext *tmp = nullptr;;
    AnnotationTypeDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AnnotationTypeDeclarationContext *annotationTypeDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationTypeDeclaration_eofContext* annotationTypeDeclaration_eof();

  class  AnnotationTypeDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ModifierContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::AnnotationTypeBodyContext *tmp2 = nullptr;;
    AnnotationTypeDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *AT();
    AnnotationTypeBodyContext *annotationTypeBody();
    antlr4::tree::TerminalNode *Name();
    std::vector<ModifierContext *> modifier();
    ModifierContext* modifier(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationTypeDeclarationContext* annotationTypeDeclaration();

  class  AnnotationTypeBody_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationTypeBodyContext *tmp = nullptr;;
    AnnotationTypeBody_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AnnotationTypeBodyContext *annotationTypeBody();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationTypeBody_eofContext* annotationTypeBody_eof();

  class  AnnotationTypeBodyContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationTypeElementDeclarationContext *tmp0 = nullptr;;
    AnnotationTypeBodyContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<AnnotationTypeElementDeclarationContext *> annotationTypeElementDeclaration();
    AnnotationTypeElementDeclarationContext* annotationTypeElementDeclaration(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationTypeBodyContext* annotationTypeBody();

  class  AnnotationMethod_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationMethodContext *tmp = nullptr;;
    AnnotationMethod_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AnnotationMethodContext *annotationMethod();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationMethod_eofContext* annotationMethod_eof();

  class  AnnotationMethodContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ModifierContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp1 = nullptr;;
    antlr4::Token *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::DefaultValueContext *tmp3 = nullptr;;
    AnnotationMethodContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    antlr4::tree::TerminalNode *SEMI();
    TypeContext *type();
    antlr4::tree::TerminalNode *Name();
    std::vector<ModifierContext *> modifier();
    ModifierContext* modifier(size_t i);
    DefaultValueContext *defaultValue();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationMethodContext* annotationMethod();

  class  AnnotationConstant_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationConstantContext *tmp = nullptr;;
    AnnotationConstant_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AnnotationConstantContext *annotationConstant();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationConstant_eofContext* annotationConstant_eof();

  class  AnnotationConstantContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ModifierContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::VariableDeclaratorContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::VariableDeclaratorContext *tmp3 = nullptr;;
    AnnotationConstantContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    TypeContext *type();
    std::vector<VariableDeclaratorContext *> variableDeclarator();
    VariableDeclaratorContext* variableDeclarator(size_t i);
    std::vector<ModifierContext *> modifier();
    ModifierContext* modifier(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationConstantContext* annotationConstant();

  class  DefaultValue_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::DefaultValueContext *tmp = nullptr;;
    DefaultValue_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    DefaultValueContext *defaultValue();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  DefaultValue_eofContext* defaultValue_eof();

  class  DefaultValueContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ElementValueOrExprContext *tmp0 = nullptr;;
    DefaultValueContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ElementValueOrExprContext *elementValueOrExpr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  DefaultValueContext* defaultValue();

  class  LocalVariableDeclarationStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LocalVariableDeclarationStatementContext *tmp = nullptr;;
    LocalVariableDeclarationStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LocalVariableDeclarationStatementContext *localVariableDeclarationStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LocalVariableDeclarationStatement_eofContext* localVariableDeclarationStatement_eof();

  class  LocalVariableDeclarationStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LocalVariableDeclarationContext *tmp0 = nullptr;;
    LocalVariableDeclarationStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    LocalVariableDeclarationContext *localVariableDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LocalVariableDeclarationStatementContext* localVariableDeclarationStatement();

  class  LocalVariableDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LocalVariableDeclarationContext *tmp = nullptr;;
    LocalVariableDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LocalVariableDeclarationContext *localVariableDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LocalVariableDeclaration_eofContext* localVariableDeclaration_eof();

  class  LocalVariableDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimitiveModifierContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::VariableDeclaratorContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::VariableDeclaratorContext *tmp3 = nullptr;;
    LocalVariableDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeContext *type();
    std::vector<VariableDeclaratorContext *> variableDeclarator();
    VariableDeclaratorContext* variableDeclarator(size_t i);
    std::vector<PrimitiveModifierContext *> primitiveModifier();
    PrimitiveModifierContext* primitiveModifier(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LocalVariableDeclarationContext* localVariableDeclaration();

  class  JavaBlock_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::JavaBlockContext *tmp = nullptr;;
    JavaBlock_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    JavaBlockContext *javaBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  JavaBlock_eofContext* javaBlock_eof();

  class  JavaBlockContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::BlockStatementContext *tmp0 = nullptr;;
    JavaBlockContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<BlockStatementContext *> blockStatement();
    BlockStatementContext* blockStatement(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  JavaBlockContext* javaBlock();

  class  AssertStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AssertStatementContext *tmp = nullptr;;
    AssertStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AssertStatementContext *assertStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AssertStatement_eofContext* assertStatement_eof();

  class  AssertStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp1 = nullptr;;
    AssertStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    std::vector<ExpressionContext *> expression();
    ExpressionContext* expression(size_t i);
    antlr4::tree::TerminalNode *COLON();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AssertStatementContext* assertStatement();

  class  IfStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::IfStatementContext *tmp = nullptr;;
    IfStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    IfStatementContext *ifStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  IfStatement_eofContext* ifStatement_eof();

  class  IfStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::StatementContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::StatementContext *tmp2 = nullptr;;
    IfStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    ExpressionContext *expression();
    std::vector<StatementContext *> statement();
    StatementContext* statement(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  IfStatementContext* ifStatement();

  class  ForStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ForStatementContext *tmp = nullptr;;
    ForStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ForStatementContext *forStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ForStatement_eofContext* forStatement_eof();

  class  ForStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ForControlContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::StatementContext *tmp1 = nullptr;;
    ForStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    ForControlContext *forControl();
    StatementContext *statement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ForStatementContext* forStatement();

  class  CommonForControl_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CommonForControlContext *tmp = nullptr;;
    CommonForControl_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    CommonForControlContext *commonForControl();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CommonForControl_eofContext* commonForControl_eof();

  class  CommonForControlContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ForInitContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp3 = nullptr;;
    CommonForControlContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<antlr4::tree::TerminalNode *> SEMI();
    antlr4::tree::TerminalNode* SEMI(size_t i);
    ForInitContext *forInit();
    std::vector<ExpressionContext *> expression();
    ExpressionContext* expression(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CommonForControlContext* commonForControl();

  class  ForInitByExpressions_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ForInitByExpressionsContext *tmp = nullptr;;
    ForInitByExpressions_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ForInitByExpressionsContext *forInitByExpressions();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ForInitByExpressions_eofContext* forInitByExpressions_eof();

  class  ForInitByExpressionsContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp1 = nullptr;;
    ForInitByExpressionsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<ExpressionContext *> expression();
    ExpressionContext* expression(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ForInitByExpressionsContext* forInitByExpressions();

  class  EnhancedForControl_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::EnhancedForControlContext *tmp = nullptr;;
    EnhancedForControl_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    EnhancedForControlContext *enhancedForControl();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnhancedForControl_eofContext* enhancedForControl_eof();

  class  EnhancedForControlContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FormalParameterContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp1 = nullptr;;
    EnhancedForControlContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COLON();
    FormalParameterContext *formalParameter();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnhancedForControlContext* enhancedForControl();

  class  WhileStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::WhileStatementContext *tmp = nullptr;;
    WhileStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    WhileStatementContext *whileStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  WhileStatement_eofContext* whileStatement_eof();

  class  WhileStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::StatementContext *tmp1 = nullptr;;
    WhileStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    ExpressionContext *expression();
    StatementContext *statement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  WhileStatementContext* whileStatement();

  class  DoWhileStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::DoWhileStatementContext *tmp = nullptr;;
    DoWhileStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    DoWhileStatementContext *doWhileStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  DoWhileStatement_eofContext* doWhileStatement_eof();

  class  DoWhileStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::StatementContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp1 = nullptr;;
    DoWhileStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    antlr4::tree::TerminalNode *SEMI();
    StatementContext *statement();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  DoWhileStatementContext* doWhileStatement();

  class  TryStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TryStatementContext *tmp = nullptr;;
    TryStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    TryStatementContext *tryStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TryStatement_eofContext* tryStatement_eof();

  class  TryStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::JavaBlockContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExceptionHandlerContext *tmp1 = nullptr;;
    TryStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    JavaBlockContext *javaBlock();
    ExceptionHandlerContext *exceptionHandler();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TryStatementContext* tryStatement();

  class  CatchExceptionsHandler_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CatchExceptionsHandlerContext *tmp = nullptr;;
    CatchExceptionsHandler_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    CatchExceptionsHandlerContext *catchExceptionsHandler();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CatchExceptionsHandler_eofContext* catchExceptionsHandler_eof();

  class  CatchExceptionsHandlerContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CatchClauseContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::FinallyBlockContext *tmp1 = nullptr;;
    CatchExceptionsHandlerContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<CatchClauseContext *> catchClause();
    CatchClauseContext* catchClause(size_t i);
    FinallyBlockContext *finallyBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CatchExceptionsHandlerContext* catchExceptionsHandler();

  class  FinallyBlockOnlyHandler_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FinallyBlockOnlyHandlerContext *tmp = nullptr;;
    FinallyBlockOnlyHandler_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    FinallyBlockOnlyHandlerContext *finallyBlockOnlyHandler();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FinallyBlockOnlyHandler_eofContext* finallyBlockOnlyHandler_eof();

  class  FinallyBlockOnlyHandlerContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FinallyBlockContext *tmp0 = nullptr;;
    FinallyBlockOnlyHandlerContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    FinallyBlockContext *finallyBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FinallyBlockOnlyHandlerContext* finallyBlockOnlyHandler();

  class  TryStatementWithResources_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TryStatementWithResourcesContext *tmp = nullptr;;
    TryStatementWithResources_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    TryStatementWithResourcesContext *tryStatementWithResources();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TryStatementWithResources_eofContext* tryStatementWithResources_eof();

  class  TryStatementWithResourcesContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ResourceContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ResourceContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::JavaBlockContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::CatchClauseContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::FinallyBlockContext *tmp4 = nullptr;;
    TryStatementWithResourcesContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    JavaBlockContext *javaBlock();
    std::vector<ResourceContext *> resource();
    ResourceContext* resource(size_t i);
    std::vector<antlr4::tree::TerminalNode *> SEMI();
    antlr4::tree::TerminalNode* SEMI(size_t i);
    std::vector<CatchClauseContext *> catchClause();
    CatchClauseContext* catchClause(size_t i);
    FinallyBlockContext *finallyBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TryStatementWithResourcesContext* tryStatementWithResources();

  class  Resource_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ResourceContext *tmp = nullptr;;
    Resource_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ResourceContext *resource();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Resource_eofContext* resource_eof();

  class  ResourceContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimitiveModifierContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::DeclaratorIdContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp3 = nullptr;;
    ResourceContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EQUALS();
    TypeContext *type();
    DeclaratorIdContext *declaratorId();
    ExpressionContext *expression();
    std::vector<PrimitiveModifierContext *> primitiveModifier();
    PrimitiveModifierContext* primitiveModifier(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ResourceContext* resource();

  class  IdentifierAndTypeArgument_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::IdentifierAndTypeArgumentContext *tmp = nullptr;;
    IdentifierAndTypeArgument_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    IdentifierAndTypeArgumentContext *identifierAndTypeArgument();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  IdentifierAndTypeArgument_eofContext* identifierAndTypeArgument_eof();

  class  IdentifierAndTypeArgumentContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeArgumentsContext *tmp1 = nullptr;;
    IdentifierAndTypeArgumentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Name();
    TypeArgumentsContext *typeArguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  IdentifierAndTypeArgumentContext* identifierAndTypeArgument();

  class  CatchClause_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CatchClauseContext *tmp = nullptr;;
    CatchClause_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    CatchClauseContext *catchClause();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CatchClause_eofContext* catchClause_eof();

  class  CatchClauseContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimitiveModifierContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::CatchTypeContext *tmp1 = nullptr;;
    antlr4::Token *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::JavaBlockContext *tmp3 = nullptr;;
    CatchClauseContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    CatchTypeContext *catchType();
    JavaBlockContext *javaBlock();
    antlr4::tree::TerminalNode *Name();
    std::vector<PrimitiveModifierContext *> primitiveModifier();
    PrimitiveModifierContext* primitiveModifier(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CatchClauseContext* catchClause();

  class  CatchType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CatchTypeContext *tmp = nullptr;;
    CatchType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    CatchTypeContext *catchType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CatchType_eofContext* catchType_eof();

  class  CatchTypeContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::QualifiedNameContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::QualifiedNameContext *tmp1 = nullptr;;
    CatchTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<QualifiedNameContext *> qualifiedName();
    QualifiedNameContext* qualifiedName(size_t i);
    std::vector<antlr4::tree::TerminalNode *> PIPE();
    antlr4::tree::TerminalNode* PIPE(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CatchTypeContext* catchType();

  class  SwitchStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SwitchStatementContext *tmp = nullptr;;
    SwitchStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SwitchStatementContext *switchStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SwitchStatement_eofContext* switchStatement_eof();

  class  SwitchStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::SwitchBlockStatementGroupContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::SwitchLabelContext *tmp2 = nullptr;;
    SwitchStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    ExpressionContext *expression();
    std::vector<SwitchBlockStatementGroupContext *> switchBlockStatementGroup();
    SwitchBlockStatementGroupContext* switchBlockStatementGroup(size_t i);
    std::vector<SwitchLabelContext *> switchLabel();
    SwitchLabelContext* switchLabel(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SwitchStatementContext* switchStatement();

  class  SynchronizedStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SynchronizedStatementContext *tmp = nullptr;;
    SynchronizedStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SynchronizedStatementContext *synchronizedStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SynchronizedStatement_eofContext* synchronizedStatement_eof();

  class  SynchronizedStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::JavaBlockContext *tmp1 = nullptr;;
    SynchronizedStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    ExpressionContext *expression();
    JavaBlockContext *javaBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SynchronizedStatementContext* synchronizedStatement();

  class  ReturnStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ReturnStatementContext *tmp = nullptr;;
    ReturnStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ReturnStatementContext *returnStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ReturnStatement_eofContext* returnStatement_eof();

  class  ReturnStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    ReturnStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ReturnStatementContext* returnStatement();

  class  ThrowStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ThrowStatementContext *tmp = nullptr;;
    ThrowStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ThrowStatementContext *throwStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ThrowStatement_eofContext* throwStatement_eof();

  class  ThrowStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    ThrowStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ThrowStatementContext* throwStatement();

  class  BreakStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::BreakStatementContext *tmp = nullptr;;
    BreakStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    BreakStatementContext *breakStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  BreakStatement_eofContext* breakStatement_eof();

  class  BreakStatementContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    BreakStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  BreakStatementContext* breakStatement();

  class  ContinueStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ContinueStatementContext *tmp = nullptr;;
    ContinueStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ContinueStatementContext *continueStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ContinueStatement_eofContext* continueStatement_eof();

  class  ContinueStatementContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    ContinueStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ContinueStatementContext* continueStatement();

  class  EmptyStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::EmptyStatementContext *tmp = nullptr;;
    EmptyStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    EmptyStatementContext *emptyStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EmptyStatement_eofContext* emptyStatement_eof();

  class  EmptyStatementContext : public antlr4::ParserRuleContext {
  public:
    EmptyStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EmptyStatementContext* emptyStatement();

  class  ExpressionStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionStatementContext *tmp = nullptr;;
    ExpressionStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ExpressionStatementContext *expressionStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ExpressionStatement_eofContext* expressionStatement_eof();

  class  ExpressionStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    ExpressionStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ExpressionStatementContext* expressionStatement();

  class  ASTStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ASTStatementContext *tmp = nullptr;;
    ASTStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ASTStatementContext *aSTStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ASTStatement_eofContext* aSTStatement_eof();

  class  ASTStatementContext : public antlr4::ParserRuleContext {
  public:
    ASTStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ASTStatementContext* aSTStatement();

  class  LabeledStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LabeledStatementContext *tmp = nullptr;;
    LabeledStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LabeledStatementContext *labeledStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LabeledStatement_eofContext* labeledStatement_eof();

  class  LabeledStatementContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::StatementContext *tmp1 = nullptr;;
    LabeledStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COLON();
    StatementContext *statement();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LabeledStatementContext* labeledStatement();

  class  SwitchBlockStatementGroup_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SwitchBlockStatementGroupContext *tmp = nullptr;;
    SwitchBlockStatementGroup_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SwitchBlockStatementGroupContext *switchBlockStatementGroup();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SwitchBlockStatementGroup_eofContext* switchBlockStatementGroup_eof();

  class  SwitchBlockStatementGroupContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SwitchLabelContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::BlockStatementContext *tmp1 = nullptr;;
    SwitchBlockStatementGroupContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<SwitchLabelContext *> switchLabel();
    SwitchLabelContext* switchLabel(size_t i);
    std::vector<BlockStatementContext *> blockStatement();
    BlockStatementContext* blockStatement(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SwitchBlockStatementGroupContext* switchBlockStatementGroup();

  class  ConstantExpressionSwitchLabel_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ConstantExpressionSwitchLabelContext *tmp = nullptr;;
    ConstantExpressionSwitchLabel_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ConstantExpressionSwitchLabelContext *constantExpressionSwitchLabel();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstantExpressionSwitchLabel_eofContext* constantExpressionSwitchLabel_eof();

  class  ConstantExpressionSwitchLabelContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    ConstantExpressionSwitchLabelContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COLON();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstantExpressionSwitchLabelContext* constantExpressionSwitchLabel();

  class  EnumConstantSwitchLabel_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::EnumConstantSwitchLabelContext *tmp = nullptr;;
    EnumConstantSwitchLabel_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    EnumConstantSwitchLabelContext *enumConstantSwitchLabel();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnumConstantSwitchLabel_eofContext* enumConstantSwitchLabel_eof();

  class  EnumConstantSwitchLabelContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    EnumConstantSwitchLabelContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COLON();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnumConstantSwitchLabelContext* enumConstantSwitchLabel();

  class  DefaultSwitchLabel_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::DefaultSwitchLabelContext *tmp = nullptr;;
    DefaultSwitchLabel_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    DefaultSwitchLabelContext *defaultSwitchLabel();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  DefaultSwitchLabel_eofContext* defaultSwitchLabel_eof();

  class  DefaultSwitchLabelContext : public antlr4::ParserRuleContext {
  public:
    DefaultSwitchLabelContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COLON();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  DefaultSwitchLabelContext* defaultSwitchLabel();

  class  CreatorExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CreatorExpressionContext *tmp = nullptr;;
    CreatorExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    CreatorExpressionContext *creatorExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CreatorExpression_eofContext* creatorExpression_eof();

  class  CreatorExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CreatorContext *tmp0 = nullptr;;
    CreatorExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    CreatorContext *creator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CreatorExpressionContext* creatorExpression();

  class  AnonymousClass_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnonymousClassContext *tmp = nullptr;;
    AnonymousClass_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AnonymousClassContext *anonymousClass();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnonymousClass_eofContext* anonymousClass_eof();

  class  AnonymousClassContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeArgumentsContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::CreatedNameContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::ClassCreatorRestContext *tmp2 = nullptr;;
    AnonymousClassContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    CreatedNameContext *createdName();
    ClassCreatorRestContext *classCreatorRest();
    TypeArgumentsContext *typeArguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnonymousClassContext* anonymousClass();

  class  ArrayCreator_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArrayCreatorContext *tmp = nullptr;;
    ArrayCreator_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ArrayCreatorContext *arrayCreator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayCreator_eofContext* arrayCreator_eof();

  class  ArrayCreatorContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CreatedNameContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ArrayDimensionSpecifierContext *tmp1 = nullptr;;
    ArrayCreatorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    CreatedNameContext *createdName();
    ArrayDimensionSpecifierContext *arrayDimensionSpecifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayCreatorContext* arrayCreator();

  class  ArrayDimensionByInitializer_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArrayDimensionByInitializerContext *tmp = nullptr;;
    ArrayDimensionByInitializer_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ArrayDimensionByInitializerContext *arrayDimensionByInitializer();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayDimensionByInitializer_eofContext* arrayDimensionByInitializer_eof();

  class  ArrayDimensionByInitializerContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArrayInitializerContext *tmp0 = nullptr;;
    ArrayDimensionByInitializerContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ArrayInitializerContext *arrayInitializer();
    std::vector<antlr4::tree::TerminalNode *> LBRACK();
    antlr4::tree::TerminalNode* LBRACK(size_t i);
    std::vector<antlr4::tree::TerminalNode *> RBRACK();
    antlr4::tree::TerminalNode* RBRACK(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayDimensionByInitializerContext* arrayDimensionByInitializer();

  class  ArrayDimensionByExpression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArrayDimensionByExpressionContext *tmp = nullptr;;
    ArrayDimensionByExpression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ArrayDimensionByExpressionContext *arrayDimensionByExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayDimensionByExpression_eofContext* arrayDimensionByExpression_eof();

  class  ArrayDimensionByExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    ArrayDimensionByExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<antlr4::tree::TerminalNode *> LBRACK();
    antlr4::tree::TerminalNode* LBRACK(size_t i);
    std::vector<antlr4::tree::TerminalNode *> RBRACK();
    antlr4::tree::TerminalNode* RBRACK(size_t i);
    std::vector<ExpressionContext *> expression();
    ExpressionContext* expression(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayDimensionByExpressionContext* arrayDimensionByExpression();

  class  CreatedName_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CreatedNameContext *tmp = nullptr;;
    CreatedName_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    CreatedNameContext *createdName();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CreatedName_eofContext* createdName_eof();

  class  CreatedNameContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::IdentifierAndTypeArgumentContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::IdentifierAndTypeArgumentContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::PrimitiveTypeContext *tmp2 = nullptr;;
    CreatedNameContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<IdentifierAndTypeArgumentContext *> identifierAndTypeArgument();
    IdentifierAndTypeArgumentContext* identifierAndTypeArgument(size_t i);
    std::vector<antlr4::tree::TerminalNode *> POINT();
    antlr4::tree::TerminalNode* POINT(size_t i);
    PrimitiveTypeContext *primitiveType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CreatedNameContext* createdName();

  class  InnerCreator_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::InnerCreatorContext *tmp = nullptr;;
    InnerCreator_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    InnerCreatorContext *innerCreator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InnerCreator_eofContext* innerCreator_eof();

  class  InnerCreatorContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeArgumentsContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeArgumentsContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::ClassCreatorRestContext *tmp3 = nullptr;;
    InnerCreatorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ClassCreatorRestContext *classCreatorRest();
    antlr4::tree::TerminalNode *Name();
    std::vector<TypeArgumentsContext *> typeArguments();
    TypeArgumentsContext* typeArguments(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InnerCreatorContext* innerCreator();

  class  ClassCreatorRest_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassCreatorRestContext *tmp = nullptr;;
    ClassCreatorRest_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ClassCreatorRestContext *classCreatorRest();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassCreatorRest_eofContext* classCreatorRest_eof();

  class  ClassCreatorRestContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArgumentsContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ClassBodyContext *tmp1 = nullptr;;
    ClassCreatorRestContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ArgumentsContext *arguments();
    ClassBodyContext *classBody();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassCreatorRestContext* classCreatorRest();

  class  MCGrammar_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MCGrammarContext *tmp = nullptr;;
    MCGrammar_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    MCGrammarContext *mCGrammar();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MCGrammar_eofContext* mCGrammar_eof();

  class  MCGrammarContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::MCImportStatementContext *tmp2 = nullptr;;
    antlr4::Token *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::GrammarReferenceContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::GrammarReferenceContext *tmp5 = nullptr;;
    Grammar_WithConceptsAntlrParser::GrammarOptionContext *tmp6 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexProdContext *tmp7 = nullptr;;
    Grammar_WithConceptsAntlrParser::ClassProdContext *tmp8 = nullptr;;
    Grammar_WithConceptsAntlrParser::EnumProdContext *tmp9 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExternalProdContext *tmp10 = nullptr;;
    Grammar_WithConceptsAntlrParser::InterfaceProdContext *tmp11 = nullptr;;
    Grammar_WithConceptsAntlrParser::AbstractProdContext *tmp12 = nullptr;;
    Grammar_WithConceptsAntlrParser::ASTRuleContext *tmp13 = nullptr;;
    Grammar_WithConceptsAntlrParser::Concept_Context *tmp14 = nullptr;;
    Grammar_WithConceptsAntlrParser::StartRuleContext *tmp15 = nullptr;;
    MCGrammarContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    antlr4::tree::TerminalNode *SEMI();
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);
    std::vector<MCImportStatementContext *> mCImportStatement();
    MCImportStatementContext* mCImportStatement(size_t i);
    std::vector<GrammarOptionContext *> grammarOption();
    GrammarOptionContext* grammarOption(size_t i);
    std::vector<LexProdContext *> lexProd();
    LexProdContext* lexProd(size_t i);
    std::vector<ClassProdContext *> classProd();
    ClassProdContext* classProd(size_t i);
    std::vector<EnumProdContext *> enumProd();
    EnumProdContext* enumProd(size_t i);
    std::vector<ExternalProdContext *> externalProd();
    ExternalProdContext* externalProd(size_t i);
    std::vector<InterfaceProdContext *> interfaceProd();
    InterfaceProdContext* interfaceProd(size_t i);
    std::vector<AbstractProdContext *> abstractProd();
    AbstractProdContext* abstractProd(size_t i);
    std::vector<ASTRuleContext *> aSTRule();
    ASTRuleContext* aSTRule(size_t i);
    std::vector<Concept_Context *> concept_();
    Concept_Context* concept_(size_t i);
    std::vector<StartRuleContext *> startRule();
    StartRuleContext* startRule(size_t i);
    std::vector<GrammarReferenceContext *> grammarReference();
    GrammarReferenceContext* grammarReference(size_t i);
    std::vector<antlr4::tree::TerminalNode *> POINT();
    antlr4::tree::TerminalNode* POINT(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MCGrammarContext* mCGrammar();

  class  MCImportStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MCImportStatementContext *tmp = nullptr;;
    MCImportStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    MCImportStatementContext *mCImportStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MCImportStatement_eofContext* mCImportStatement_eof();

  class  MCImportStatementContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    MCImportStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    std::vector<antlr4::tree::TerminalNode *> POINT();
    antlr4::tree::TerminalNode* POINT(size_t i);
    antlr4::tree::TerminalNode *STAR();
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MCImportStatementContext* mCImportStatement();

  class  GrammarReference_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::GrammarReferenceContext *tmp = nullptr;;
    GrammarReference_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    GrammarReferenceContext *grammarReference();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  GrammarReference_eofContext* grammarReference_eof();

  class  GrammarReferenceContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    GrammarReferenceContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);
    std::vector<antlr4::tree::TerminalNode *> POINT();
    antlr4::tree::TerminalNode* POINT(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  GrammarReferenceContext* grammarReference();

  class  GrammarOption_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::GrammarOptionContext *tmp = nullptr;;
    GrammarOption_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    GrammarOptionContext *grammarOption();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  GrammarOption_eofContext* grammarOption_eof();

  class  GrammarOptionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FollowOptionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::AntlrOptionContext *tmp1 = nullptr;;
    GrammarOptionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<FollowOptionContext *> followOption();
    FollowOptionContext* followOption(size_t i);
    std::vector<AntlrOptionContext *> antlrOption();
    AntlrOptionContext* antlrOption(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  GrammarOptionContext* grammarOption();

  class  FollowOption_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FollowOptionContext *tmp = nullptr;;
    FollowOption_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    FollowOptionContext *followOption();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FollowOption_eofContext* followOption_eof();

  class  FollowOptionContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::AltContext *tmp1 = nullptr;;
    FollowOptionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    AltContext *alt();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FollowOptionContext* followOption();

  class  AntlrOption_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AntlrOptionContext *tmp = nullptr;;
    AntlrOption_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AntlrOptionContext *antlrOption();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AntlrOption_eofContext* antlrOption_eof();

  class  AntlrOptionContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    antlr4::Token *tmp2 = nullptr;;
    AntlrOptionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);
    antlr4::tree::TerminalNode *EQUALS();
    antlr4::tree::TerminalNode *String();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AntlrOptionContext* antlrOption();

  class  StartRule_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::StartRuleContext *tmp = nullptr;;
    StartRule_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    StartRuleContext *startRule();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  StartRule_eofContext* startRule_eof();

  class  StartRuleContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    StartRuleContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  StartRuleContext* startRule();

  class  LexProd_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexProdContext *tmp = nullptr;;
    LexProd_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexProdContext *lexProd();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexProd_eofContext* lexProd_eof();

  class  LexProdContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexOptionContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::ActionContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::ActionContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexAltContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexAltContext *tmp5 = nullptr;;
    antlr4::Token *tmp6 = nullptr;;
    Grammar_WithConceptsAntlrParser::ActionContext *tmp7 = nullptr;;
    antlr4::Token *tmp8 = nullptr;;
    antlr4::Token *tmp9 = nullptr;;
    antlr4::Token *tmp10 = nullptr;;
    Grammar_WithConceptsAntlrParser::ActionContext *tmp11 = nullptr;;
    LexProdContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *EQUALS();
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);
    std::vector<antlr4::tree::TerminalNode *> LCURLY();
    antlr4::tree::TerminalNode* LCURLY(size_t i);
    std::vector<antlr4::tree::TerminalNode *> RCURLY();
    antlr4::tree::TerminalNode* RCURLY(size_t i);
    std::vector<LexAltContext *> lexAlt();
    LexAltContext* lexAlt(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COLON();
    antlr4::tree::TerminalNode* COLON(size_t i);
    LexOptionContext *lexOption();
    std::vector<ActionContext *> action();
    ActionContext* action(size_t i);
    std::vector<antlr4::tree::TerminalNode *> PIPE();
    antlr4::tree::TerminalNode* PIPE(size_t i);
    std::vector<antlr4::tree::TerminalNode *> MINUSGT();
    antlr4::tree::TerminalNode* MINUSGT(size_t i);
    std::vector<antlr4::tree::TerminalNode *> POINT();
    antlr4::tree::TerminalNode* POINT(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexProdContext* lexProd();

  class  EnumProd_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::EnumProdContext *tmp = nullptr;;
    EnumProd_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    EnumProdContext *enumProd();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnumProd_eofContext* enumProd_eof();

  class  EnumProdContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ConstantContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::ConstantContext *tmp2 = nullptr;;
    EnumProdContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EQUALS();
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *Name();
    std::vector<ConstantContext *> constant();
    ConstantContext* constant(size_t i);
    std::vector<antlr4::tree::TerminalNode *> PIPE();
    antlr4::tree::TerminalNode* PIPE(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EnumProdContext* enumProd();

  class  ExternalProd_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExternalProdContext *tmp = nullptr;;
    ExternalProd_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ExternalProdContext *externalProd();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ExternalProd_eofContext* externalProd_eof();

  class  ExternalProdContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SymbolDefinitionContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp2 = nullptr;;
    ExternalProdContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *Name();
    std::vector<SymbolDefinitionContext *> symbolDefinition();
    SymbolDefinitionContext* symbolDefinition(size_t i);
    GenericTypeContext *genericType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ExternalProdContext* externalProd();

  class  InterfaceProd_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::InterfaceProdContext *tmp = nullptr;;
    InterfaceProd_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    InterfaceProdContext *interfaceProd();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceProd_eofContext* interfaceProd_eof();

  class  InterfaceProdContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SymbolDefinitionContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::RuleReferenceContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::RuleReferenceContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp5 = nullptr;;
    Grammar_WithConceptsAntlrParser::AltContext *tmp6 = nullptr;;
    Grammar_WithConceptsAntlrParser::AltContext *tmp7 = nullptr;;
    InterfaceProdContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *Name();
    antlr4::tree::TerminalNode *EQUALS();
    std::vector<SymbolDefinitionContext *> symbolDefinition();
    SymbolDefinitionContext* symbolDefinition(size_t i);
    std::vector<RuleReferenceContext *> ruleReference();
    RuleReferenceContext* ruleReference(size_t i);
    std::vector<GenericTypeContext *> genericType();
    GenericTypeContext* genericType(size_t i);
    std::vector<AltContext *> alt();
    AltContext* alt(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);
    std::vector<antlr4::tree::TerminalNode *> PIPE();
    antlr4::tree::TerminalNode* PIPE(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceProdContext* interfaceProd();

  class  AbstractProd_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AbstractProdContext *tmp = nullptr;;
    AbstractProd_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AbstractProdContext *abstractProd();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AbstractProd_eofContext* abstractProd_eof();

  class  AbstractProdContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SymbolDefinitionContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::RuleReferenceContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::RuleReferenceContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::RuleReferenceContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::RuleReferenceContext *tmp5 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp6 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp7 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp8 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp9 = nullptr;;
    Grammar_WithConceptsAntlrParser::AltContext *tmp10 = nullptr;;
    Grammar_WithConceptsAntlrParser::AltContext *tmp11 = nullptr;;
    AbstractProdContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *Name();
    antlr4::tree::TerminalNode *EQUALS();
    std::vector<SymbolDefinitionContext *> symbolDefinition();
    SymbolDefinitionContext* symbolDefinition(size_t i);
    std::vector<RuleReferenceContext *> ruleReference();
    RuleReferenceContext* ruleReference(size_t i);
    std::vector<GenericTypeContext *> genericType();
    GenericTypeContext* genericType(size_t i);
    std::vector<AltContext *> alt();
    AltContext* alt(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);
    std::vector<antlr4::tree::TerminalNode *> PIPE();
    antlr4::tree::TerminalNode* PIPE(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AbstractProdContext* abstractProd();

  class  ClassProd_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassProdContext *tmp = nullptr;;
    ClassProd_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ClassProdContext *classProd();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassProd_eofContext* classProd_eof();

  class  ClassProdContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SymbolDefinitionContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::RuleReferenceContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::RuleReferenceContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::RuleReferenceContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::RuleReferenceContext *tmp5 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp6 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp7 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp8 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp9 = nullptr;;
    Grammar_WithConceptsAntlrParser::ActionContext *tmp10 = nullptr;;
    Grammar_WithConceptsAntlrParser::AltContext *tmp11 = nullptr;;
    Grammar_WithConceptsAntlrParser::AltContext *tmp12 = nullptr;;
    ClassProdContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *Name();
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    antlr4::tree::TerminalNode *EQUALS();
    std::vector<SymbolDefinitionContext *> symbolDefinition();
    SymbolDefinitionContext* symbolDefinition(size_t i);
    ActionContext *action();
    std::vector<RuleReferenceContext *> ruleReference();
    RuleReferenceContext* ruleReference(size_t i);
    std::vector<GenericTypeContext *> genericType();
    GenericTypeContext* genericType(size_t i);
    std::vector<AltContext *> alt();
    AltContext* alt(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);
    std::vector<antlr4::tree::TerminalNode *> PIPE();
    antlr4::tree::TerminalNode* PIPE(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassProdContext* classProd();

  class  Card_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CardContext *tmp = nullptr;;
    Card_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    CardContext *card();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Card_eofContext* card_eof();

  class  CardContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    antlr4::Token *tmp2 = nullptr;;
    CardContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *STAR();
    std::vector<antlr4::tree::TerminalNode *> EQUALS();
    antlr4::tree::TerminalNode* EQUALS(size_t i);
    std::vector<antlr4::tree::TerminalNode *> Num_Int();
    antlr4::tree::TerminalNode* Num_Int(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CardContext* card();

  class  RuleReference_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::RuleReferenceContext *tmp = nullptr;;
    RuleReference_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    RuleReferenceContext *ruleReference();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  RuleReference_eofContext* ruleReference_eof();

  class  RuleReferenceContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SemanticpredicateOrActionContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    antlr4::Token *tmp2 = nullptr;;
    RuleReferenceContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Name();
    antlr4::tree::TerminalNode *LT();
    antlr4::tree::TerminalNode *GT();
    SemanticpredicateOrActionContext *semanticpredicateOrAction();
    antlr4::tree::TerminalNode *Num_Int();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  RuleReferenceContext* ruleReference();

  class  Alt_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AltContext *tmp = nullptr;;
    Alt_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AltContext *alt();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Alt_eofContext* alt_eof();

  class  AltContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::RuleComponentContext *tmp0 = nullptr;;
    AltContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<RuleComponentContext *> ruleComponent();
    RuleComponentContext* ruleComponent(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AltContext* alt();

  class  NonTerminalSeparator_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::NonTerminalSeparatorContext *tmp = nullptr;;
    NonTerminalSeparator_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    NonTerminalSeparatorContext *nonTerminalSeparator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  NonTerminalSeparator_eofContext* nonTerminalSeparator_eof();

  class  NonTerminalSeparatorContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    antlr4::Token *tmp2 = nullptr;;
    NonTerminalSeparatorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *PIPEPIPE();
    antlr4::tree::TerminalNode *RPAREN();
    antlr4::tree::TerminalNode *STAR();
    antlr4::tree::TerminalNode *PLUS();
    antlr4::tree::TerminalNode *COLON();
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);
    antlr4::tree::TerminalNode *AND();
    antlr4::tree::TerminalNode *String();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  NonTerminalSeparatorContext* nonTerminalSeparator();

  class  Block_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::BlockContext *tmp = nullptr;;
    Block_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    BlockContext *block();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Block_eofContext* block_eof();

  class  BlockContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::OptionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ActionContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::ActionContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::AltContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::AltContext *tmp4 = nullptr;;
    BlockContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    antlr4::tree::TerminalNode *COLON();
    std::vector<AltContext *> alt();
    AltContext* alt(size_t i);
    antlr4::tree::TerminalNode *QUESTION();
    antlr4::tree::TerminalNode *STAR();
    antlr4::tree::TerminalNode *PLUS();
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<antlr4::tree::TerminalNode *> PIPE();
    antlr4::tree::TerminalNode* PIPE(size_t i);
    OptionContext *option();
    ActionContext *action();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  BlockContext* block();

  class  Option_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::OptionContext *tmp = nullptr;;
    Option_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    OptionContext *option();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Option_eofContext* option_eof();

  class  OptionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::OptionValueContext *tmp0 = nullptr;;
    OptionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<OptionValueContext *> optionValue();
    OptionValueContext* optionValue(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  OptionContext* option();

  class  OptionValue_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::OptionValueContext *tmp = nullptr;;
    OptionValue_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    OptionValueContext *optionValue();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  OptionValue_eofContext* optionValue_eof();

  class  OptionValueContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    OptionValueContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EQUALS();
    antlr4::tree::TerminalNode *SEMI();
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  OptionValueContext* optionValue();

  class  NonTerminal_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::NonTerminalContext *tmp = nullptr;;
    NonTerminal_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    NonTerminalContext *nonTerminal();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  NonTerminal_eofContext* nonTerminal_eof();

  class  NonTerminalContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    antlr4::Token *tmp2 = nullptr;;
    NonTerminalContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COLON();
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);
    antlr4::tree::TerminalNode *AT();
    std::vector<antlr4::tree::TerminalNode *> AND();
    antlr4::tree::TerminalNode* AND(size_t i);
    std::vector<antlr4::tree::TerminalNode *> QUESTION();
    antlr4::tree::TerminalNode* QUESTION(size_t i);
    std::vector<antlr4::tree::TerminalNode *> STAR();
    antlr4::tree::TerminalNode* STAR(size_t i);
    std::vector<antlr4::tree::TerminalNode *> PLUS();
    antlr4::tree::TerminalNode* PLUS(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  NonTerminalContext* nonTerminal();

  class  Terminal_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TerminalContext *tmp = nullptr;;
    Terminal_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    TerminalContext *terminal();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Terminal_eofContext* terminal_eof();

  class  TerminalContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    TerminalContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COLON();
    antlr4::tree::TerminalNode *String();
    std::vector<antlr4::tree::TerminalNode *> QUESTION();
    antlr4::tree::TerminalNode* QUESTION(size_t i);
    std::vector<antlr4::tree::TerminalNode *> STAR();
    antlr4::tree::TerminalNode* STAR(size_t i);
    std::vector<antlr4::tree::TerminalNode *> PLUS();
    antlr4::tree::TerminalNode* PLUS(size_t i);
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TerminalContext* terminal();

  class  Constant_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ConstantContext *tmp = nullptr;;
    Constant_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ConstantContext *constant();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Constant_eofContext* constant_eof();

  class  ConstantContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    ConstantContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *COLON();
    antlr4::tree::TerminalNode *String();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstantContext* constant();

  class  ConstantGroup_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ConstantGroupContext *tmp = nullptr;;
    ConstantGroup_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ConstantGroupContext *constantGroup();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstantGroup_eofContext* constantGroup_eof();

  class  ConstantGroupContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ConstantContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::ConstantContext *tmp2 = nullptr;;
    ConstantGroupContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LBRACK();
    antlr4::tree::TerminalNode *RBRACK();
    std::vector<ConstantContext *> constant();
    ConstantContext* constant(size_t i);
    antlr4::tree::TerminalNode *COLON();
    std::vector<antlr4::tree::TerminalNode *> PIPE();
    antlr4::tree::TerminalNode* PIPE(size_t i);
    antlr4::tree::TerminalNode *QUESTION();
    antlr4::tree::TerminalNode *STAR();
    antlr4::tree::TerminalNode *PLUS();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstantGroupContext* constantGroup();

  class  Eof_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::EofContext *tmp = nullptr;;
    Eof_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    EofContext *eof();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Eof_eofContext* eof_eof();

  class  EofContext : public antlr4::ParserRuleContext {
  public:
    EofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  EofContext* eof();

  class  MCAnything_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MCAnythingContext *tmp = nullptr;;
    MCAnything_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    MCAnythingContext *mCAnything();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MCAnything_eofContext* mCAnything_eof();

  class  MCAnythingContext : public antlr4::ParserRuleContext {
  public:
    MCAnythingContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MCAnythingContext* mCAnything();

  class  Anything_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnythingContext *tmp = nullptr;;
    Anything_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AnythingContext *anything();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Anything_eofContext* anything_eof();

  class  AnythingContext : public antlr4::ParserRuleContext {
  public:
    AnythingContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *POINT();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnythingContext* anything();

  class  SemanticpredicateOrAction_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SemanticpredicateOrActionContext *tmp = nullptr;;
    SemanticpredicateOrAction_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SemanticpredicateOrActionContext *semanticpredicateOrAction();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SemanticpredicateOrAction_eofContext* semanticpredicateOrAction_eof();

  class  SemanticpredicateOrActionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionPredicateContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ActionContext *tmp1 = nullptr;;
    SemanticpredicateOrActionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    antlr4::tree::TerminalNode *QUESTION();
    ExpressionPredicateContext *expressionPredicate();
    ActionContext *action();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SemanticpredicateOrActionContext* semanticpredicateOrAction();

  class  Concept_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::Concept_Context *tmp = nullptr;;
    Concept_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    Concept_Context *concept_();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Concept_eofContext* concept_eof();

  class  Concept_Context : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::MCConceptContext *tmp1 = nullptr;;
    Concept_Context(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    MCConceptContext *mCConcept();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Concept_Context* concept_();

  class  ASTRule_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ASTRuleContext *tmp = nullptr;;
    ASTRule_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ASTRuleContext *aSTRule();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ASTRule_eofContext* aSTRule_eof();

  class  ASTRuleContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::MethodContext *tmp5 = nullptr;;
    Grammar_WithConceptsAntlrParser::AttributeInASTContext *tmp6 = nullptr;;
    ASTRuleContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *Name();
    antlr4::tree::TerminalNode *EQUALS();
    std::vector<GenericTypeContext *> genericType();
    GenericTypeContext* genericType(size_t i);
    std::vector<MethodContext *> method();
    MethodContext* method(size_t i);
    std::vector<AttributeInASTContext *> attributeInAST();
    AttributeInASTContext* attributeInAST(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ASTRuleContext* aSTRule();

  class  Method_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MethodContext *tmp = nullptr;;
    Method_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    MethodContext *method();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Method_eofContext* method_eof();

  class  MethodContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::MethodParameterContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::MethodParameterContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp5 = nullptr;;
    Grammar_WithConceptsAntlrParser::ActionContext *tmp6 = nullptr;;
    MethodContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<GenericTypeContext *> genericType();
    GenericTypeContext* genericType(size_t i);
    ActionContext *action();
    antlr4::tree::TerminalNode *Name();
    std::vector<MethodParameterContext *> methodParameter();
    MethodParameterContext* methodParameter(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MethodContext* method();

  class  MethodParameter_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MethodParameterContext *tmp = nullptr;;
    MethodParameter_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    MethodParameterContext *methodParameter();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MethodParameter_eofContext* methodParameter_eof();

  class  MethodParameterContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    MethodParameterContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    GenericTypeContext *genericType();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MethodParameterContext* methodParameter();

  class  AttributeInAST_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AttributeInASTContext *tmp = nullptr;;
    AttributeInAST_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AttributeInASTContext *attributeInAST();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AttributeInAST_eofContext* attributeInAST_eof();

  class  AttributeInASTContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::CardContext *tmp2 = nullptr;;
    AttributeInASTContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    GenericTypeContext *genericType();
    antlr4::tree::TerminalNode *COLON();
    CardContext *card();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AttributeInASTContext* attributeInAST();

  class  GenericType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp = nullptr;;
    GenericType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    GenericTypeContext *genericType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  GenericType_eofContext* genericType_eof();

  class  GenericTypeContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericTypeContext *tmp3 = nullptr;;
    GenericTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LT();
    antlr4::tree::TerminalNode *GT();
    std::vector<antlr4::tree::TerminalNode *> LBRACK();
    antlr4::tree::TerminalNode* LBRACK(size_t i);
    std::vector<antlr4::tree::TerminalNode *> RBRACK();
    antlr4::tree::TerminalNode* RBRACK(size_t i);
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);
    std::vector<antlr4::tree::TerminalNode *> POINT();
    antlr4::tree::TerminalNode* POINT(size_t i);
    std::vector<GenericTypeContext *> genericType();
    GenericTypeContext* genericType(size_t i);
    std::vector<antlr4::tree::TerminalNode *> COMMA();
    antlr4::tree::TerminalNode* COMMA(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  GenericTypeContext* genericType();

  class  LexAlt_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexAltContext *tmp = nullptr;;
    LexAlt_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexAltContext *lexAlt();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexAlt_eofContext* lexAlt_eof();

  class  LexAltContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexComponentContext *tmp0 = nullptr;;
    LexAltContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<LexComponentContext *> lexComponent();
    LexComponentContext* lexComponent(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexAltContext* lexAlt();

  class  LexBlock_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexBlockContext *tmp = nullptr;;
    LexBlock_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexBlockContext *lexBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexBlock_eofContext* lexBlock_eof();

  class  LexBlockContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexOptionContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::ActionContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::ActionContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexAltContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexAltContext *tmp4 = nullptr;;
    LexBlockContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    antlr4::tree::TerminalNode *TILDE();
    antlr4::tree::TerminalNode *COLON();
    std::vector<LexAltContext *> lexAlt();
    LexAltContext* lexAlt(size_t i);
    antlr4::tree::TerminalNode *QUESTION();
    antlr4::tree::TerminalNode *STAR();
    antlr4::tree::TerminalNode *PLUS();
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<antlr4::tree::TerminalNode *> PIPE();
    antlr4::tree::TerminalNode* PIPE(size_t i);
    LexOptionContext *lexOption();
    ActionContext *action();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexBlockContext* lexBlock();

  class  LexCharRange_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexCharRangeContext *tmp = nullptr;;
    LexCharRange_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexCharRangeContext *lexCharRange();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexCharRange_eofContext* lexCharRange_eof();

  class  LexCharRangeContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    LexCharRangeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *POINTPOINT();
    antlr4::tree::TerminalNode *TILDE();
    std::vector<antlr4::tree::TerminalNode *> Char();
    antlr4::tree::TerminalNode* Char(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexCharRangeContext* lexCharRange();

  class  LexChar_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexCharContext *tmp = nullptr;;
    LexChar_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexCharContext *lexChar();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexChar_eofContext* lexChar_eof();

  class  LexCharContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    LexCharContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *TILDE();
    antlr4::tree::TerminalNode *Char();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexCharContext* lexChar();

  class  LexAnyChar_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexAnyCharContext *tmp = nullptr;;
    LexAnyChar_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexAnyCharContext *lexAnyChar();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexAnyChar_eofContext* lexAnyChar_eof();

  class  LexAnyCharContext : public antlr4::ParserRuleContext {
  public:
    LexAnyCharContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *POINT();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexAnyCharContext* lexAnyChar();

  class  LexString_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexStringContext *tmp = nullptr;;
    LexString_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexStringContext *lexString();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexString_eofContext* lexString_eof();

  class  LexStringContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    LexStringContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *String();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexStringContext* lexString();

  class  LexActionOrPredicate_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexActionOrPredicateContext *tmp = nullptr;;
    LexActionOrPredicate_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexActionOrPredicateContext *lexActionOrPredicate();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexActionOrPredicate_eofContext* lexActionOrPredicate_eof();

  class  LexActionOrPredicateContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionPredicateContext *tmp0 = nullptr;;
    LexActionOrPredicateContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *RCURLY();
    antlr4::tree::TerminalNode *QUESTION();
    ExpressionPredicateContext *expressionPredicate();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexActionOrPredicateContext* lexActionOrPredicate();

  class  LexNonTerminal_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexNonTerminalContext *tmp = nullptr;;
    LexNonTerminal_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexNonTerminalContext *lexNonTerminal();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexNonTerminal_eofContext* lexNonTerminal_eof();

  class  LexNonTerminalContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    LexNonTerminalContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexNonTerminalContext* lexNonTerminal();

  class  LexSimpleIteration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexSimpleIterationContext *tmp = nullptr;;
    LexSimpleIteration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexSimpleIterationContext *lexSimpleIteration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexSimpleIteration_eofContext* lexSimpleIteration_eof();

  class  LexSimpleIterationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexNonTerminalContext *tmp0 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexStringContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexCharContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexAnyCharContext *tmp3 = nullptr;;
    LexSimpleIterationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<antlr4::tree::TerminalNode *> QUESTION();
    antlr4::tree::TerminalNode* QUESTION(size_t i);
    antlr4::tree::TerminalNode *STAR();
    antlr4::tree::TerminalNode *PLUS();
    LexNonTerminalContext *lexNonTerminal();
    LexStringContext *lexString();
    LexCharContext *lexChar();
    LexAnyCharContext *lexAnyChar();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexSimpleIterationContext* lexSimpleIteration();

  class  LexOption_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexOptionContext *tmp = nullptr;;
    LexOption_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexOptionContext *lexOption();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexOption_eofContext* lexOption_eof();

  class  LexOptionContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    antlr4::Token *tmp1 = nullptr;;
    LexOptionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LCURLY();
    antlr4::tree::TerminalNode *EQUALS();
    antlr4::tree::TerminalNode *SEMI();
    antlr4::tree::TerminalNode *RCURLY();
    std::vector<antlr4::tree::TerminalNode *> Name();
    antlr4::tree::TerminalNode* Name(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexOptionContext* lexOption();

  class  SymbolDefinition_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SymbolDefinitionContext *tmp = nullptr;;
    SymbolDefinition_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SymbolDefinitionContext *symbolDefinition();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SymbolDefinition_eofContext* symbolDefinition_eof();

  class  SymbolDefinitionContext : public antlr4::ParserRuleContext {
  public:
    antlr4::Token *tmp0 = nullptr;;
    SymbolDefinitionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    antlr4::tree::TerminalNode *Name();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SymbolDefinitionContext* symbolDefinition();

  class  Action_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ActionContext *tmp = nullptr;;
    Action_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ActionContext *action();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Action_eofContext* action_eof();

  class  ActionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::BlockStatementContext *tmp0 = nullptr;;
    ActionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<BlockStatementContext *> blockStatement();
    BlockStatementContext* blockStatement(size_t i);

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ActionContext* action();

  class  ExpressionPredicate_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionPredicateContext *tmp = nullptr;;
    ExpressionPredicate_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ExpressionPredicateContext *expressionPredicate();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ExpressionPredicate_eofContext* expressionPredicate_eof();

  class  ExpressionPredicateContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp0 = nullptr;;
    ExpressionPredicateContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ExpressionPredicateContext* expressionPredicate();

  class  MCConcept_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MCConceptContext *tmp = nullptr;;
    MCConcept_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    MCConceptContext *mCConcept();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MCConcept_eofContext* mCConcept_eof();

  class  MCConceptContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ConceptAntlrContext *tmp0 = nullptr;;
    MCConceptContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ConceptAntlrContext *conceptAntlr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MCConceptContext* mCConcept();

  class  Literal_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LiteralContext *tmp = nullptr;;
    Literal_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LiteralContext *literal();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Literal_eofContext* literal_eof();

  class  LiteralContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::NullLiteralContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::BooleanLiteralContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::CharLiteralContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::StringLiteralContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::NumericLiteralContext *tmp5 = nullptr;;
    LiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    NullLiteralContext *nullLiteral();
    BooleanLiteralContext *booleanLiteral();
    CharLiteralContext *charLiteral();
    StringLiteralContext *stringLiteral();
    NumericLiteralContext *numericLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LiteralContext* literal();

  class  SignedLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SignedLiteralContext *tmp = nullptr;;
    SignedLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SignedLiteralContext *signedLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedLiteral_eofContext* signedLiteral_eof();

  class  SignedLiteralContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::NullLiteralContext *tmp1 = nullptr;;
    Grammar_WithConceptsAntlrParser::BooleanLiteralContext *tmp2 = nullptr;;
    Grammar_WithConceptsAntlrParser::CharLiteralContext *tmp3 = nullptr;;
    Grammar_WithConceptsAntlrParser::StringLiteralContext *tmp4 = nullptr;;
    Grammar_WithConceptsAntlrParser::SignedNumericLiteralContext *tmp6 = nullptr;;
    SignedLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    NullLiteralContext *nullLiteral();
    BooleanLiteralContext *booleanLiteral();
    CharLiteralContext *charLiteral();
    StringLiteralContext *stringLiteral();
    SignedNumericLiteralContext *signedNumericLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedLiteralContext* signedLiteral();

  class  NumericLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::NumericLiteralContext *tmp = nullptr;;
    NumericLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    NumericLiteralContext *numericLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  NumericLiteral_eofContext* numericLiteral_eof();

  class  NumericLiteralContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::IntLiteralContext *tmp7 = nullptr;;
    Grammar_WithConceptsAntlrParser::LongLiteralContext *tmp8 = nullptr;;
    Grammar_WithConceptsAntlrParser::FloatLiteralContext *tmp9 = nullptr;;
    Grammar_WithConceptsAntlrParser::DoubleLiteralContext *tmp10 = nullptr;;
    NumericLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    IntLiteralContext *intLiteral();
    LongLiteralContext *longLiteral();
    FloatLiteralContext *floatLiteral();
    DoubleLiteralContext *doubleLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  NumericLiteralContext* numericLiteral();

  class  SignedNumericLiteral_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SignedNumericLiteralContext *tmp = nullptr;;
    SignedNumericLiteral_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SignedNumericLiteralContext *signedNumericLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedNumericLiteral_eofContext* signedNumericLiteral_eof();

  class  SignedNumericLiteralContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SignedIntLiteralContext *tmp11 = nullptr;;
    Grammar_WithConceptsAntlrParser::SignedLongLiteralContext *tmp12 = nullptr;;
    Grammar_WithConceptsAntlrParser::SignedFloatLiteralContext *tmp13 = nullptr;;
    Grammar_WithConceptsAntlrParser::SignedDoubleLiteralContext *tmp14 = nullptr;;
    SignedNumericLiteralContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    SignedIntLiteralContext *signedIntLiteral();
    SignedLongLiteralContext *signedLongLiteral();
    SignedFloatLiteralContext *signedFloatLiteral();
    SignedDoubleLiteralContext *signedDoubleLiteral();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SignedNumericLiteralContext* signedNumericLiteral();

  class  Type_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeContext *tmp = nullptr;;
    Type_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    TypeContext *type();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Type_eofContext* type_eof();

  class  TypeContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ComplexArrayTypeContext *tmp15 = nullptr;;
    Grammar_WithConceptsAntlrParser::PrimitiveArrayTypeContext *tmp16 = nullptr;;
    Grammar_WithConceptsAntlrParser::PrimitiveTypeContext *tmp17 = nullptr;;
    Grammar_WithConceptsAntlrParser::SimpleReferenceTypeContext *tmp18 = nullptr;;
    Grammar_WithConceptsAntlrParser::ComplexReferenceTypeContext *tmp19 = nullptr;;
    TypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ComplexArrayTypeContext *complexArrayType();
    PrimitiveArrayTypeContext *primitiveArrayType();
    PrimitiveTypeContext *primitiveType();
    SimpleReferenceTypeContext *simpleReferenceType();
    ComplexReferenceTypeContext *complexReferenceType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeContext* type();

  class  ReferenceType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ReferenceTypeContext *tmp = nullptr;;
    ReferenceType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ReferenceTypeContext *referenceType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ReferenceType_eofContext* referenceType_eof();

  class  ReferenceTypeContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SimpleReferenceTypeContext *tmp18 = nullptr;;
    Grammar_WithConceptsAntlrParser::ComplexReferenceTypeContext *tmp19 = nullptr;;
    ReferenceTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    SimpleReferenceTypeContext *simpleReferenceType();
    ComplexReferenceTypeContext *complexReferenceType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ReferenceTypeContext* referenceType();

  class  TypeArgument_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeArgumentContext *tmp = nullptr;;
    TypeArgument_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    TypeArgumentContext *typeArgument();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeArgument_eofContext* typeArgument_eof();

  class  TypeArgumentContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::WildcardTypeContext *tmp20 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp21 = nullptr;;
    TypeArgumentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    WildcardTypeContext *wildcardType();
    TypeContext *type();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeArgumentContext* typeArgument();

  class  ReturnType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ReturnTypeContext *tmp = nullptr;;
    ReturnType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ReturnTypeContext *returnType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ReturnType_eofContext* returnType_eof();

  class  ReturnTypeContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::VoidTypeContext *tmp22 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp21 = nullptr;;
    ReturnTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    VoidTypeContext *voidType();
    TypeContext *type();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ReturnTypeContext* returnType();

  class  ArrayType_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArrayTypeContext *tmp = nullptr;;
    ArrayType_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ArrayTypeContext *arrayType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayType_eofContext* arrayType_eof();

  class  ArrayTypeContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ComplexArrayTypeContext *tmp15 = nullptr;;
    Grammar_WithConceptsAntlrParser::PrimitiveArrayTypeContext *tmp16 = nullptr;;
    ArrayTypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ComplexArrayTypeContext *complexArrayType();
    PrimitiveArrayTypeContext *primitiveArrayType();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayTypeContext* arrayType();

  class  Expression_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp = nullptr;;
    Expression_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ExpressionContext *expression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Expression_eofContext* expression_eof();

  class  ExpressionContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp29 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp31 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp32 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp34 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp36 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp38 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp40 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp45 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp49 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp51 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp53 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp55 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp57 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp59 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp61 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp63 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp65 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp67 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp69 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp71 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp74 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeArgumentsContext *tmp23 = nullptr;;
    Grammar_WithConceptsAntlrParser::GenericInvocationSuffixContext *tmp24 = nullptr;;
    Grammar_WithConceptsAntlrParser::ReturnTypeContext *tmp25 = nullptr;;
    antlr4::Token *tmp26 = nullptr;;
    Grammar_WithConceptsAntlrParser::LiteralContext *tmp27 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp28 = nullptr;;
    Grammar_WithConceptsAntlrParser::CreatorContext *tmp42 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp43 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp44 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp46 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp47 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp48 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp50 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp52 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp54 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp56 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp60 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp62 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp64 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp66 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp68 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp70 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp72 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp73 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp75 = nullptr;;
    antlr4::Token *tmp30 = nullptr;;
    Grammar_WithConceptsAntlrParser::InnerCreatorContext *tmp33 = nullptr;;
    Grammar_WithConceptsAntlrParser::SuperSuffixContext *tmp35 = nullptr;;
    Grammar_WithConceptsAntlrParser::PrimaryGenericInvocationExpressionContext *tmp37 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionContext *tmp39 = nullptr;;
    Grammar_WithConceptsAntlrParser::ArgumentsContext *tmp41 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeContext *tmp58 = nullptr;;
    ExpressionContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeArgumentsContext *typeArguments();
    GenericInvocationSuffixContext *genericInvocationSuffix();
    antlr4::tree::TerminalNode *POINT();
    ReturnTypeContext *returnType();
    antlr4::tree::TerminalNode *Name();
    LiteralContext *literal();
    antlr4::tree::TerminalNode *LPAREN();
    antlr4::tree::TerminalNode *RPAREN();
    std::vector<ExpressionContext *> expression();
    ExpressionContext* expression(size_t i);
    CreatorContext *creator();
    TypeContext *type();
    antlr4::tree::TerminalNode *PLUS();
    antlr4::tree::TerminalNode *MINUS();
    antlr4::tree::TerminalNode *PLUSPLUS();
    antlr4::tree::TerminalNode *MINUSMINUS();
    antlr4::tree::TerminalNode *TILDE();
    antlr4::tree::TerminalNode *EXCLAMATIONMARK();
    antlr4::tree::TerminalNode *STAR();
    antlr4::tree::TerminalNode *SLASH();
    antlr4::tree::TerminalNode *PERCENT();
    std::vector<antlr4::tree::TerminalNode *> LT();
    antlr4::tree::TerminalNode* LT(size_t i);
    std::vector<antlr4::tree::TerminalNode *> GT();
    antlr4::tree::TerminalNode* GT(size_t i);
    antlr4::tree::TerminalNode *LTEQUALS();
    antlr4::tree::TerminalNode *GTEQUALS();
    antlr4::tree::TerminalNode *EQUALSEQUALS();
    antlr4::tree::TerminalNode *EXCLAMATIONMARKEQUALS();
    antlr4::tree::TerminalNode *AND();
    antlr4::tree::TerminalNode *ROOF();
    antlr4::tree::TerminalNode *PIPE();
    antlr4::tree::TerminalNode *ANDAND();
    antlr4::tree::TerminalNode *PIPEPIPE();
    antlr4::tree::TerminalNode *QUESTION();
    antlr4::tree::TerminalNode *COLON();
    antlr4::tree::TerminalNode *EQUALS();
    antlr4::tree::TerminalNode *PLUSEQUALS();
    antlr4::tree::TerminalNode *MINUSEQUALS();
    antlr4::tree::TerminalNode *STAREQUALS();
    antlr4::tree::TerminalNode *SLASHEQUALS();
    antlr4::tree::TerminalNode *ANDEQUALS();
    antlr4::tree::TerminalNode *PIPEEQUALS();
    antlr4::tree::TerminalNode *ROOFEQUALS();
    antlr4::tree::TerminalNode *GTGTEQUALS();
    antlr4::tree::TerminalNode *GTGTGTEQUALS();
    antlr4::tree::TerminalNode *LTLTEQUALS();
    antlr4::tree::TerminalNode *PERCENTEQUALS();
    InnerCreatorContext *innerCreator();
    SuperSuffixContext *superSuffix();
    PrimaryGenericInvocationExpressionContext *primaryGenericInvocationExpression();
    antlr4::tree::TerminalNode *LBRACK();
    antlr4::tree::TerminalNode *RBRACK();
    ArgumentsContext *arguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ExpressionContext* expression();
  ExpressionContext* expression(int precedence);
  class  Modifier_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ModifierContext *tmp = nullptr;;
    Modifier_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ModifierContext *modifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Modifier_eofContext* modifier_eof();

  class  ModifierContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::PrimitiveModifierContext *tmp76 = nullptr;;
    Grammar_WithConceptsAntlrParser::AnnotationContext *tmp77 = nullptr;;
    ModifierContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    PrimitiveModifierContext *primitiveModifier();
    AnnotationContext *annotation();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ModifierContext* modifier();

  class  TypeDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TypeDeclarationContext *tmp = nullptr;;
    TypeDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    TypeDeclarationContext *typeDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeDeclaration_eofContext* typeDeclaration_eof();

  class  TypeDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::EmptyDeclarationContext *tmp78 = nullptr;;
    Grammar_WithConceptsAntlrParser::ClassDeclarationContext *tmp79 = nullptr;;
    Grammar_WithConceptsAntlrParser::InterfaceDeclarationContext *tmp80 = nullptr;;
    Grammar_WithConceptsAntlrParser::EnumDeclarationContext *tmp81 = nullptr;;
    Grammar_WithConceptsAntlrParser::AnnotationTypeDeclarationContext *tmp82 = nullptr;;
    TypeDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    EmptyDeclarationContext *emptyDeclaration();
    ClassDeclarationContext *classDeclaration();
    InterfaceDeclarationContext *interfaceDeclaration();
    EnumDeclarationContext *enumDeclaration();
    AnnotationTypeDeclarationContext *annotationTypeDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  TypeDeclarationContext* typeDeclaration();

  class  ClassBodyDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassBodyDeclarationContext *tmp = nullptr;;
    ClassBodyDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ClassBodyDeclarationContext *classBodyDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassBodyDeclaration_eofContext* classBodyDeclaration_eof();

  class  ClassBodyDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassBlockContext *tmp83 = nullptr;;
    Grammar_WithConceptsAntlrParser::ClassMemberDeclarationContext *tmp84 = nullptr;;
    ClassBodyDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ClassBlockContext *classBlock();
    ClassMemberDeclarationContext *classMemberDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassBodyDeclarationContext* classBodyDeclaration();

  class  InterfaceBodyDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::InterfaceBodyDeclarationContext *tmp = nullptr;;
    InterfaceBodyDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    InterfaceBodyDeclarationContext *interfaceBodyDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceBodyDeclaration_eofContext* interfaceBodyDeclaration_eof();

  class  InterfaceBodyDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::InterfaceMemberDeclarationContext *tmp85 = nullptr;;
    InterfaceBodyDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    InterfaceMemberDeclarationContext *interfaceMemberDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceBodyDeclarationContext* interfaceBodyDeclaration();

  class  ClassMemberDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ClassMemberDeclarationContext *tmp = nullptr;;
    ClassMemberDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ClassMemberDeclarationContext *classMemberDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassMemberDeclaration_eofContext* classMemberDeclaration_eof();

  class  ClassMemberDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MethodDeclarationContext *tmp86 = nullptr;;
    Grammar_WithConceptsAntlrParser::ConstructorDeclarationContext *tmp87 = nullptr;;
    Grammar_WithConceptsAntlrParser::FieldDeclarationContext *tmp88 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeDeclarationContext *tmp89 = nullptr;;
    ClassMemberDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    MethodDeclarationContext *methodDeclaration();
    ConstructorDeclarationContext *constructorDeclaration();
    FieldDeclarationContext *fieldDeclaration();
    TypeDeclarationContext *typeDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ClassMemberDeclarationContext* classMemberDeclaration();

  class  MethodBody_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::MethodBodyContext *tmp = nullptr;;
    MethodBody_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    MethodBodyContext *methodBody();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MethodBody_eofContext* methodBody_eof();

  class  MethodBodyContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::JavaBlockContext *tmp90 = nullptr;;
    MethodBodyContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    JavaBlockContext *javaBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  MethodBodyContext* methodBody();

  class  ConstructorBody_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ConstructorBodyContext *tmp = nullptr;;
    ConstructorBody_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ConstructorBodyContext *constructorBody();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstructorBody_eofContext* constructorBody_eof();

  class  ConstructorBodyContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::JavaBlockContext *tmp90 = nullptr;;
    ConstructorBodyContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    JavaBlockContext *javaBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ConstructorBodyContext* constructorBody();

  class  InterfaceMemberDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::InterfaceMemberDeclarationContext *tmp = nullptr;;
    InterfaceMemberDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    InterfaceMemberDeclarationContext *interfaceMemberDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceMemberDeclaration_eofContext* interfaceMemberDeclaration_eof();

  class  InterfaceMemberDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ConstDeclarationContext *tmp91 = nullptr;;
    Grammar_WithConceptsAntlrParser::InterfaceMethodDeclarationContext *tmp92 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeDeclarationContext *tmp89 = nullptr;;
    InterfaceMemberDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ConstDeclarationContext *constDeclaration();
    InterfaceMethodDeclarationContext *interfaceMethodDeclaration();
    TypeDeclarationContext *typeDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  InterfaceMemberDeclarationContext* interfaceMemberDeclaration();

  class  VariableInitializer_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::VariableInitializerContext *tmp = nullptr;;
    VariableInitializer_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    VariableInitializerContext *variableInitializer();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  VariableInitializer_eofContext* variableInitializer_eof();

  class  VariableInitializerContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArrayInitializerContext *tmp93 = nullptr;;
    VariableInitializerContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ArrayInitializerContext *arrayInitializer();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  VariableInitializerContext* variableInitializer();

  class  AnnotationArguments_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationArgumentsContext *tmp = nullptr;;
    AnnotationArguments_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AnnotationArgumentsContext *annotationArguments();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationArguments_eofContext* annotationArguments_eof();

  class  AnnotationArgumentsContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationPairArgumentsContext *tmp94 = nullptr;;
    Grammar_WithConceptsAntlrParser::ElementValueOrExprContext *tmp95 = nullptr;;
    AnnotationArgumentsContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AnnotationPairArgumentsContext *annotationPairArguments();
    ElementValueOrExprContext *elementValueOrExpr();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationArgumentsContext* annotationArguments();

  class  ElementValue_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ElementValueContext *tmp = nullptr;;
    ElementValue_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ElementValueContext *elementValue();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ElementValue_eofContext* elementValue_eof();

  class  ElementValueContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationContext *tmp77 = nullptr;;
    Grammar_WithConceptsAntlrParser::ElementValueArrayInitializerContext *tmp96 = nullptr;;
    ElementValueContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AnnotationContext *annotation();
    ElementValueArrayInitializerContext *elementValueArrayInitializer();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ElementValueContext* elementValue();

  class  AnnotationTypeElementDeclaration_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationTypeElementDeclarationContext *tmp = nullptr;;
    AnnotationTypeElementDeclaration_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    AnnotationTypeElementDeclarationContext *annotationTypeElementDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationTypeElementDeclaration_eofContext* annotationTypeElementDeclaration_eof();

  class  AnnotationTypeElementDeclarationContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationMethodContext *tmp97 = nullptr;;
    Grammar_WithConceptsAntlrParser::AnnotationConstantContext *tmp98 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeDeclarationContext *tmp89 = nullptr;;
    AnnotationTypeElementDeclarationContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AnnotationMethodContext *annotationMethod();
    AnnotationConstantContext *annotationConstant();
    TypeDeclarationContext *typeDeclaration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  AnnotationTypeElementDeclarationContext* annotationTypeElementDeclaration();

  class  BlockStatement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::BlockStatementContext *tmp = nullptr;;
    BlockStatement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    BlockStatementContext *blockStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  BlockStatement_eofContext* blockStatement_eof();

  class  BlockStatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LocalVariableDeclarationStatementContext *tmp99 = nullptr;;
    Grammar_WithConceptsAntlrParser::TypeDeclarationContext *tmp89 = nullptr;;
    Grammar_WithConceptsAntlrParser::StatementContext *tmp100 = nullptr;;
    BlockStatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LocalVariableDeclarationStatementContext *localVariableDeclarationStatement();
    TypeDeclarationContext *typeDeclaration();
    StatementContext *statement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  BlockStatementContext* blockStatement();

  class  Statement_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::StatementContext *tmp = nullptr;;
    Statement_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    StatementContext *statement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Statement_eofContext* statement_eof();

  class  StatementContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnnotationContext *tmp77 = nullptr;;
    Grammar_WithConceptsAntlrParser::JavaBlockContext *tmp90 = nullptr;;
    Grammar_WithConceptsAntlrParser::AssertStatementContext *tmp101 = nullptr;;
    Grammar_WithConceptsAntlrParser::IfStatementContext *tmp102 = nullptr;;
    Grammar_WithConceptsAntlrParser::ForStatementContext *tmp103 = nullptr;;
    Grammar_WithConceptsAntlrParser::WhileStatementContext *tmp104 = nullptr;;
    Grammar_WithConceptsAntlrParser::DoWhileStatementContext *tmp105 = nullptr;;
    Grammar_WithConceptsAntlrParser::TryStatementContext *tmp106 = nullptr;;
    Grammar_WithConceptsAntlrParser::TryStatementWithResourcesContext *tmp107 = nullptr;;
    Grammar_WithConceptsAntlrParser::SwitchStatementContext *tmp108 = nullptr;;
    Grammar_WithConceptsAntlrParser::SynchronizedStatementContext *tmp109 = nullptr;;
    Grammar_WithConceptsAntlrParser::ReturnStatementContext *tmp110 = nullptr;;
    Grammar_WithConceptsAntlrParser::ThrowStatementContext *tmp111 = nullptr;;
    Grammar_WithConceptsAntlrParser::BreakStatementContext *tmp112 = nullptr;;
    Grammar_WithConceptsAntlrParser::ContinueStatementContext *tmp113 = nullptr;;
    Grammar_WithConceptsAntlrParser::EmptyStatementContext *tmp114 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExpressionStatementContext *tmp115 = nullptr;;
    Grammar_WithConceptsAntlrParser::ASTStatementContext *tmp116 = nullptr;;
    Grammar_WithConceptsAntlrParser::LabeledStatementContext *tmp117 = nullptr;;
    StatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AnnotationContext *annotation();
    JavaBlockContext *javaBlock();
    AssertStatementContext *assertStatement();
    IfStatementContext *ifStatement();
    ForStatementContext *forStatement();
    WhileStatementContext *whileStatement();
    DoWhileStatementContext *doWhileStatement();
    TryStatementContext *tryStatement();
    TryStatementWithResourcesContext *tryStatementWithResources();
    SwitchStatementContext *switchStatement();
    SynchronizedStatementContext *synchronizedStatement();
    ReturnStatementContext *returnStatement();
    ThrowStatementContext *throwStatement();
    BreakStatementContext *breakStatement();
    ContinueStatementContext *continueStatement();
    EmptyStatementContext *emptyStatement();
    ExpressionStatementContext *expressionStatement();
    ASTStatementContext *aSTStatement();
    LabeledStatementContext *labeledStatement();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  StatementContext* statement();

  class  ForControl_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ForControlContext *tmp = nullptr;;
    ForControl_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ForControlContext *forControl();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ForControl_eofContext* forControl_eof();

  class  ForControlContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CommonForControlContext *tmp118 = nullptr;;
    Grammar_WithConceptsAntlrParser::EnhancedForControlContext *tmp119 = nullptr;;
    ForControlContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    CommonForControlContext *commonForControl();
    EnhancedForControlContext *enhancedForControl();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ForControlContext* forControl();

  class  ForInit_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ForInitContext *tmp = nullptr;;
    ForInit_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ForInitContext *forInit();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ForInit_eofContext* forInit_eof();

  class  ForInitContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LocalVariableDeclarationContext *tmp120 = nullptr;;
    Grammar_WithConceptsAntlrParser::ForInitByExpressionsContext *tmp121 = nullptr;;
    ForInitContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LocalVariableDeclarationContext *localVariableDeclaration();
    ForInitByExpressionsContext *forInitByExpressions();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ForInitContext* forInit();

  class  ExceptionHandler_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ExceptionHandlerContext *tmp = nullptr;;
    ExceptionHandler_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ExceptionHandlerContext *exceptionHandler();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ExceptionHandler_eofContext* exceptionHandler_eof();

  class  ExceptionHandlerContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CatchExceptionsHandlerContext *tmp122 = nullptr;;
    Grammar_WithConceptsAntlrParser::FinallyBlockOnlyHandlerContext *tmp123 = nullptr;;
    ExceptionHandlerContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    CatchExceptionsHandlerContext *catchExceptionsHandler();
    FinallyBlockOnlyHandlerContext *finallyBlockOnlyHandler();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ExceptionHandlerContext* exceptionHandler();

  class  FinallyBlock_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::FinallyBlockContext *tmp = nullptr;;
    FinallyBlock_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    FinallyBlockContext *finallyBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FinallyBlock_eofContext* finallyBlock_eof();

  class  FinallyBlockContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::JavaBlockContext *tmp90 = nullptr;;
    FinallyBlockContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    JavaBlockContext *javaBlock();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  FinallyBlockContext* finallyBlock();

  class  SwitchLabel_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::SwitchLabelContext *tmp = nullptr;;
    SwitchLabel_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    SwitchLabelContext *switchLabel();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SwitchLabel_eofContext* switchLabel_eof();

  class  SwitchLabelContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ConstantExpressionSwitchLabelContext *tmp124 = nullptr;;
    Grammar_WithConceptsAntlrParser::EnumConstantSwitchLabelContext *tmp125 = nullptr;;
    Grammar_WithConceptsAntlrParser::DefaultSwitchLabelContext *tmp126 = nullptr;;
    SwitchLabelContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ConstantExpressionSwitchLabelContext *constantExpressionSwitchLabel();
    EnumConstantSwitchLabelContext *enumConstantSwitchLabel();
    DefaultSwitchLabelContext *defaultSwitchLabel();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  SwitchLabelContext* switchLabel();

  class  Creator_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::CreatorContext *tmp = nullptr;;
    Creator_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    CreatorContext *creator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Creator_eofContext* creator_eof();

  class  CreatorContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::AnonymousClassContext *tmp127 = nullptr;;
    Grammar_WithConceptsAntlrParser::ArrayCreatorContext *tmp128 = nullptr;;
    CreatorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    AnonymousClassContext *anonymousClass();
    ArrayCreatorContext *arrayCreator();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  CreatorContext* creator();

  class  ArrayDimensionSpecifier_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArrayDimensionSpecifierContext *tmp = nullptr;;
    ArrayDimensionSpecifier_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ArrayDimensionSpecifierContext *arrayDimensionSpecifier();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayDimensionSpecifier_eofContext* arrayDimensionSpecifier_eof();

  class  ArrayDimensionSpecifierContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ArrayDimensionByInitializerContext *tmp129 = nullptr;;
    Grammar_WithConceptsAntlrParser::ArrayDimensionByExpressionContext *tmp130 = nullptr;;
    ArrayDimensionSpecifierContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ArrayDimensionByInitializerContext *arrayDimensionByInitializer();
    ArrayDimensionByExpressionContext *arrayDimensionByExpression();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ArrayDimensionSpecifierContext* arrayDimensionSpecifier();

  class  Prod_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ProdContext *tmp = nullptr;;
    Prod_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ProdContext *prod();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  Prod_eofContext* prod_eof();

  class  ProdContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexProdContext *tmp131 = nullptr;;
    Grammar_WithConceptsAntlrParser::EnumProdContext *tmp132 = nullptr;;
    Grammar_WithConceptsAntlrParser::ExternalProdContext *tmp133 = nullptr;;
    Grammar_WithConceptsAntlrParser::AbstractProdContext *tmp134 = nullptr;;
    Grammar_WithConceptsAntlrParser::ParserProdContext *tmp135 = nullptr;;
    ProdContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LexProdContext *lexProd();
    EnumProdContext *enumProd();
    ExternalProdContext *externalProd();
    AbstractProdContext *abstractProd();
    ParserProdContext *parserProd();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ProdContext* prod();

  class  ParserProd_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ParserProdContext *tmp = nullptr;;
    ParserProd_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ParserProdContext *parserProd();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ParserProd_eofContext* parserProd_eof();

  class  ParserProdContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::InterfaceProdContext *tmp136 = nullptr;;
    Grammar_WithConceptsAntlrParser::ClassProdContext *tmp137 = nullptr;;
    ParserProdContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    InterfaceProdContext *interfaceProd();
    ClassProdContext *classProd();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ParserProdContext* parserProd();

  class  RuleComponent_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::RuleComponentContext *tmp = nullptr;;
    RuleComponent_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    RuleComponentContext *ruleComponent();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  RuleComponent_eofContext* ruleComponent_eof();

  class  RuleComponentContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::NonTerminalSeparatorContext *tmp138 = nullptr;;
    Grammar_WithConceptsAntlrParser::BlockContext *tmp139 = nullptr;;
    Grammar_WithConceptsAntlrParser::NonTerminalContext *tmp140 = nullptr;;
    Grammar_WithConceptsAntlrParser::TerminalContext *tmp141 = nullptr;;
    Grammar_WithConceptsAntlrParser::ConstantGroupContext *tmp142 = nullptr;;
    Grammar_WithConceptsAntlrParser::EofContext *tmp143 = nullptr;;
    Grammar_WithConceptsAntlrParser::MCAnythingContext *tmp144 = nullptr;;
    Grammar_WithConceptsAntlrParser::AnythingContext *tmp145 = nullptr;;
    Grammar_WithConceptsAntlrParser::SemanticpredicateOrActionContext *tmp146 = nullptr;;
    RuleComponentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    NonTerminalSeparatorContext *nonTerminalSeparator();
    BlockContext *block();
    NonTerminalContext *nonTerminal();
    TerminalContext *terminal();
    ConstantGroupContext *constantGroup();
    EofContext *eof();
    MCAnythingContext *mCAnything();
    AnythingContext *anything();
    SemanticpredicateOrActionContext *semanticpredicateOrAction();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  RuleComponentContext* ruleComponent();

  class  ITerminal_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::ITerminalContext *tmp = nullptr;;
    ITerminal_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    ITerminalContext *iTerminal();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ITerminal_eofContext* iTerminal_eof();

  class  ITerminalContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::TerminalContext *tmp141 = nullptr;;
    Grammar_WithConceptsAntlrParser::ConstantContext *tmp147 = nullptr;;
    ITerminalContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TerminalContext *terminal();
    ConstantContext *constant();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  ITerminalContext* iTerminal();

  class  LexComponent_eofContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexComponentContext *tmp = nullptr;;
    LexComponent_eofContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *EOF();
    LexComponentContext *lexComponent();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexComponent_eofContext* lexComponent_eof();

  class  LexComponentContext : public antlr4::ParserRuleContext {
  public:
    Grammar_WithConceptsAntlrParser::LexBlockContext *tmp148 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexCharRangeContext *tmp149 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexCharContext *tmp150 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexAnyCharContext *tmp151 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexStringContext *tmp152 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexActionOrPredicateContext *tmp153 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexNonTerminalContext *tmp154 = nullptr;;
    Grammar_WithConceptsAntlrParser::LexSimpleIterationContext *tmp155 = nullptr;;
    LexComponentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    LexBlockContext *lexBlock();
    LexCharRangeContext *lexCharRange();
    LexCharContext *lexChar();
    LexAnyCharContext *lexAnyChar();
    LexStringContext *lexString();
    LexActionOrPredicateContext *lexActionOrPredicate();
    LexNonTerminalContext *lexNonTerminal();
    LexSimpleIterationContext *lexSimpleIteration();

    virtual void enterRule(antlr4::tree::ParseTreeListener *listener) override;
    virtual void exitRule(antlr4::tree::ParseTreeListener *listener) override;
   
  };

  LexComponentContext* lexComponent();


  virtual bool sempred(antlr4::RuleContext *_localctx, size_t ruleIndex, size_t predicateIndex) override;
  bool expressionSempred(ExpressionContext *_localctx, size_t predicateIndex);

private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;


  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

