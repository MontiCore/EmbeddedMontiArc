if __name__ == "__main__":
  from migrationTool.CLI import app

  app()
